import ampl
import numpy as np
from numpy.typing import NDArray
from typing import Literal


def create_collision_system(
    convex_data: dict,
    sphere_data: dict,
) -> tuple[ampl.ColConvex, ampl.SphereBVHScene, dict[str, int]]:

    colcvx = ampl.ColConvex()
    colsph = ampl.SphereBVHScene(len(sphere_data))
    id_to_link: dict[str, int] = {}
    for idx, (name, data_vf) in enumerate(convex_data.items()):
        # mesh → convex hull + point cloud
        vertices = np.array(data_vf["vertices"], dtype=np.float32)
        faces = np.array(data_vf["faces"], dtype=np.uint32)
        cvh = ampl.VSCHf_from_mesh((vertices, faces))
        # pcd = ampl.trimesh_sampler_barycentricysplit(vertices, faces, 0, 0.005)
        colcvx.add(name, cvh_group=cvh, local_pc=None)
        colsph.set_local_tree(idx, ampl.build_sphere_tree(sphere_data[name]))
        id_to_link[name] = idx
    colsph.build_leaf_cache()
    colsph.update_poses(0, np.array([[0, 0, 0, 1, 0, 0, 0]], dtype=np.float64))
    return colcvx, colsph, id_to_link


def _configure_workspace_cvx(
    frames_to_be_considered: list[str],
    link_to_id: dict[str, int],
    col: ampl.ColConvex,
    min3=[-np.inf, -np.inf, -np.inf],
    max3=[np.inf, np.inf, np.inf],
):
    col.configure_workspace(
        frames_to_be_considered,
        [min3[0], min3[1], min3[2]],
        [max3[0], max3[1], max3[2]],
    )


def _configure_workspace_sph(
    frames_to_be_considered: list[str],
    link_to_id: dict[str, int],
    col: ampl.SphereBVHScene,
    min3=[-np.inf, -np.inf, -np.inf],
    max3=[np.inf, np.inf, np.inf],
):
    col.set_workspace(min3[0], min3[1], min3[2], max3[0], max3[1], max3[2])
    for name in link_to_id.keys():
        if name in frames_to_be_considered:
            col.set_workspace_check(link_to_id[name], True)
        else:
            col.set_workspace_check(link_to_id[name], False)


def configure_workspace(
    col: ampl.ColConvex | ampl.SphereBVHScene,
    link_to_id: dict[str, int],
    includes: list[str],
    min3=[-np.inf, -np.inf, -np.inf],
    max3=[np.inf, np.inf, np.inf],
):

    if isinstance(col, ampl.ColConvex):
        _configure_workspace_cvx(includes, link_to_id, col, min3, max3)
    elif isinstance(col, ampl.SphereBVHScene):
        _configure_workspace_sph(includes, link_to_id, col, min3, max3)
    else:
        raise TypeError(
            f"Expected ColConvex or SphereBVHScene, got {type(col).__name__}"
        )


def _update_ignore_cvx(col: ampl.ColConvex, link_to_id, ignores):
    for ignore in ignores:
        col.disable_collision(ignore[0], ignore[1])


def _update_ignore_sph(col: ampl.SphereBVHScene, link_to_id, ignores):
    """
    Translates string-based ignore lists into integer-based ACM updates
    and pushes them down to the C++ collision engine.
    """
    applied_count = 0

    for link_a, link_b in ignores:
        # Gracefully handle cases where a link in the ignore list
        # might not actually be loaded in the current scene geometry.
        if link_a not in link_to_id:
            print(f"Warning: Link '{link_a}' not found in index map. Skipping.")
            continue
        if link_b not in link_to_id:
            print(f"Warning: Link '{link_b}' not found in index map. Skipping.")
            continue

        # Get the integer IDs
        idx_a = link_to_id[link_a]
        idx_b = link_to_id[link_b]

        # Tell C++ to IGNORE this pair (False = do not check)
        col.set_acm(idx_a, idx_b, False)
        applied_count += 1
    # print(f"Successfully applied {applied_count} ignore rules to the ACM.")


def update_ignore(
    col: ampl.ColConvex | ampl.SphereBVHScene,
    link_to_id: dict[str, int],
    ignores: list[(str, str)],
):

    if isinstance(col, ampl.ColConvex):
        _update_ignore_cvx(col, link_to_id, ignores)
    elif isinstance(col, ampl.SphereBVHScene):
        _update_ignore_sph(col, link_to_id, ignores)
    else:
        raise TypeError(
            f"Expected ColConvex or SphereBVHScene, got {type(col).__name__}"
        )


def debug_col_cvx(collision_data: dict, col: ampl.ColConvex):
    vfs = []
    for name, data_vf in collision_data.items():
        vf = np.copy(np.array(data_vf["vertices"], dtype=np.float32)), np.array(
            data_vf["faces"], dtype=np.uint32
        )
        pose = col.entities[name].pose
        ampl.transform_xyz(vf[0], vf[0], pose)
        vfs.append(vf)
    VF = ampl.trimesh_concatenate(vfs)
    return VF


def debug_col_sph(
    colsph: ampl.SphereBVHScene, bvh_level: int = 0 | 1 | 2, sphere_sample: int = 64
):
    sph_data = colsph.get_spheres_at_level(bvh_level)
    sphere_data = np.array(sph_data, dtype=np.float32).reshape(-1, 4)
    colors = {
        0: [255, 0, 0, 100],  # Red for Root
        1: [0, 255, 0, 150],  # Green for Mids
        2: [0, 100, 255, 200],  # Blue for Leaves
    }
    # sphere_color = colors.get(level, [200, 200, 200, 255])
    centers = sphere_data[:, :3]
    radii = sphere_data[:, 3]

    v_sph = ampl.sample_sphere3_fibonacci(sphere_sample)
    v, f = ampl.trimesh_convexhull(v_sph)

    # print(v, f)

    # import trimesh

    tm = []
    for center, radius in zip(centers, radii):

        # sphere_mesh = trimesh.creation.icosphere(subdivisions=2, radius=radius)

        # Apply the translation to move the sphere to its world coordinate
        transform = np.eye(4)
        transform[:3, 3] = center

        v_copy = np.copy(v)
        v_copy *= radius
        v_copy[:] += center
        # sphere_mesh.apply_transform(transform)

        # Apply color
        # sphere_mesh.visual.face_colors = sphere_color
        tm.append((v_copy, np.copy(f)))
        # tm.append(sphere_mesh.copy())

    return ampl.trimesh_concatenate(tm)


def print_stats(qs_raw):
    qs_this = np.array(qs_raw)
    variations = np.diff(qs_this, axis=0)
    mean_var = np.mean(variations, axis=0)
    std_var = np.std(variations, axis=0)
    max_var = np.max(np.abs(variations), axis=0)  # Max absolute jump
    min_var = np.min(variations, axis=0)

    # Display results
    print(f"{'Joint':<10} | {'Mean Diff':<12} | {'Std Dev':<12} | {'Max Jump':<12}")
    print("-" * 55)
    for i in range(7):
        print(
            f"Joint {i+1:<4} | {mean_var[i]:>12.6f} | {std_var[i]:>12.6f} | {max_var[i]:>12.6f}"
        )


def _save_collision_gradient_lines(filename, gradients):
    """
    Saves collision gradients as explicit line segments to an OBJ file.
    Draws a line from pt_a and pt_b that perfectly meet in the middle
    based on the exact distance and normal.
    """
    if gradients is None or len(gradients) == 0:
        print("No collisions to export.")
        return

    N = gradients.shape[0]

    # 1. Slice the spatial data from the C++ matrix
    pts_a = gradients[:, 4:7]
    pts_b = gradients[:, 7:10]
    normals = gradients[:, 10:13]

    # Slice the distances. Using 13:14 keeps it as an (N, 1) matrix
    # so we can directly multiply it with the (N, 3) normal matrix!
    distances = gradients[:, 13:14]

    # 2. Compute the endpoints of the gradient lines
    # By moving exactly half the distance, A and B will perfectly touch.
    pts_a_end = pts_a + (normals * (distances / 2.25))
    pts_b_end = pts_b - (normals * (distances / 2.25))

    # 3. Build the vertices array (Shape: 4N x 3)
    verts = np.empty((N * 4, 3), dtype=np.float32)
    verts[0::4] = pts_a
    verts[1::4] = pts_a_end
    verts[2::4] = pts_b
    verts[3::4] = pts_b_end

    # 4. Build the lines topology
    lines = []
    for i in range(N):
        base_idx = i * 4
        lines.append([base_idx, base_idx + 1])  # Gradient from Link A to midpoint
        lines.append([base_idx + 2, base_idx + 3])  # Gradient from Link B to midpoint

    # 5. Call your writer function
    ampl.write_polylines(filename, verts, lines, vertex_normal=None)

    print(f"Exported {N * 2} distance-scaled gradient lines to {filename}")


def write_self_collision_gradient(
    filename: str,
    q: np.ndarray,
    kin: ampl.Kin,
    colsph: ampl.SphereBVHScene,
    distance_waring: float = 0.1,
    tf_base: ampl.Tf = None,
    top_k: int = 1,
):
    # return

    kin.update_kin(q, tf_base, False)
    colsph.update_poses(1, kin.get_fk_actuated_frame())

    if tf_base:
        colsph.update_poses(0, np.array([tf_base.as_array()], dtype=np.float64))
    pairs = colsph.compute_collisions(distance_waring)
    wall_hits = colsph.compute_wall_collisions(distance_waring)

    # for p in pairs:
    #     print(p.link_a, p.link_b, p.leaf_a, p.leaf_b)
    contacts = colsph.compute_collision_gradients(pairs, wall_hits, top_k)
    if len(pairs) == 0:
        return
    _save_collision_gradient_lines(filename, contacts)


def collision_free_sph(
    agent: ampl.Kin,
    col: ampl.SphereBVHScene,
    q: np.ndarray,
    MAGIC_DISTANCE: float = 1.5e-3,
    tf_base: ampl.Tf = None,
):

    agent.update_kin(q, tf_base)
    col.update_poses(1, agent.get_fk_actuated_frame())
    if tf_base:
        col.update_poses(0, np.array([tf_base.as_array()], dtype=np.float64))

    # poses =
    ret_workspace = col.compute_wall_collisions(0.0)

    if len(ret_workspace) > 0:
        return False
    ret = col.compute_collisions(MAGIC_DISTANCE)
    if len(ret) > 0:
        # print(ret[0].link_a)
        return False
    return True
