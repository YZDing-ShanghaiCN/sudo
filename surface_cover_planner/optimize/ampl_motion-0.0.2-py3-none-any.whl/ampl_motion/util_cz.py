import ampl
import numpy as np
from numpy.typing import NDArray
from typing import Literal
from importlib import resources
from dataclasses import dataclass, field
import json
from .types import CZKinTYpes, RobotMeta, CollisionState, CZTypes
from .common import create_collision_system, collision_free_sph

VALID_CZ: set[CZTypes] = {"cruzrs2"}


def create_default_ignore_pairs(
    rb_type: CZTypes, sorted_actuated_frames, PAD_BASE_LINK="base_link"
):
    if rb_type not in VALID_CZ:
        raise ValueError(f"cz_type must be one of {VALID_CZ}, got '{rb_type}'")
    frames = [PAD_BASE_LINK] + sorted_actuated_frames
    ignore_pairs = []
    groups = {
        "torso": [
            l for l in sorted_actuated_frames if (("lifter" in l) or ("waist" in l))
        ],
        "left_arm": [l for l in sorted_actuated_frames if "L_" in l],
        "right_arm": [l for l in sorted_actuated_frames if "R_" in l],
    }
    # IGNORE ANY COLLISION PAIR WITHIN A GROUP
    for group_name, members in groups.items():
        if group_name == "torso":
            for i in range(len(members) - 1):
                for j in range(i + 1, len(members)):
                    ignore_pairs.append((members[i], members[j]))
                    # print(ignore_pairs[-1])
        else:
            for i in range(len(members) - 1):
                ignore_pairs.append((members[i], members[i + 1]))

    if "base_link" in sorted_actuated_frames and groups["torso"]:
        ignore_pairs.append(("base_link", groups["torso"][0]))

    if groups["torso"] and groups["left_arm"]:
        ignore_pairs.append((groups["torso"][-1], groups["left_arm"][0]))
        ignore_pairs.append((groups["torso"][-1], groups["left_arm"][1]))

    if groups["torso"] and groups["right_arm"]:
        ignore_pairs.append((groups["torso"][-1], groups["right_arm"][0]))
        ignore_pairs.append((groups["torso"][-1], groups["right_arm"][1]))

    return ignore_pairs


def create_robot_system(rb_type: CZTypes):
    if rb_type not in VALID_CZ:
        raise ValueError(f"hb_type must be one of {VALID_CZ}, got '{rb_type}'")

    data_path = f"ampl_motion.data.{rb_type}"
    cvx_data = ampl.read_geometry_codec(
        resources.files(data_path).joinpath("convex_geometry.json")
    )
    sph_data = ampl.read_geometry_codec(
        resources.files(data_path).joinpath("sphere_geometry.json")
    )
    meta = RobotMeta.from_json(resources.files(data_path).joinpath("meta.json"))
    path_wbc = resources.files(data_path).joinpath("wbc.json")
    with open(path_wbc, "r") as f:
        config_wbc = json.load(f)

    kin = ampl.KinHB11(f"{rb_type}_left", f"{rb_type}_right", f"{rb_type}_torso")
    wbc = ampl.WBC277(config_wbc)
    cvx_frames = list(cvx_data.keys())
    sph_frames = list(sph_data.keys())
    kin_frames = list(kin.get_actuated_frames())

    if sph_frames != sph_frames:
        for i, (c, s) in enumerate(zip(cvx_frames, sph_frames)):
            if c != s:
                raise ValueError(
                    f"Key mismatch at index {i}: "
                    f"collision_data has '{c}', sphere_data has '{s}'"
                )
        raise ValueError(
            f"Length mismatch: collision_data has {len(cvx_frames)} keys, "
            f"sphere_data has {len(sph_frames)} keys"
        )
    missing = [f for f in kin_frames if f not in cvx_frames]
    if missing:
        raise ValueError(f"kin_frames contains frames not in collision_data: {missing}")

    frame_ids = {name: i for i, name in enumerate(cvx_frames)}
    indices = [frame_ids[f] for f in kin_frames]
    if indices != sorted(indices):
        raise ValueError(f"kin_frames order does not match collision_data order")

    colcvx, colsph, link_to_id = create_collision_system(cvx_data, sph_data)
    ignores = create_default_ignore_pairs(CZTypes, cvx_frames)

    # print(config_wbc)
    # dd = json.loads(path_wbc)

    return meta, kin, colcvx, colsph, wbc, link_to_id, ignores, cvx_data, sph_data


def _update_colcvx_agent(agent: CZKinTYpes, col: ampl.ColConvex):
    FRAMES = agent.get_actuated_frames()
    for i in range(0, agent.DOF_T):
        col.update_pose(FRAMES[i], agent._fk_T[i])
    for i in range(0, agent.DOF_A):
        col.update_pose(FRAMES[agent._I_L + i], agent._fk_L[i])
    for i in range(0, agent.DOF_A):
        col.update_pose(FRAMES[agent._I_R + +i], agent._fk_R[i])


def collision_free_cvx(
    agent: CZKinTYpes,
    col: ampl.ColConvex,
    q: np.ndarray,
    MAGIC_DISTANCE: float = 1.5e-3,
    tf_base: ampl.Tf = None,
) -> bool:
    agent.update_kin(q, tf_base)
    if tf_base:
        col.update_pose("base_link", tf_base.as_array())
    _update_colcvx_agent(agent, col)
    scene_is_collision_free = True
    if not col.is_workspace_safe():
        return False

    narrow_phase_queue = col.process_collisions()
    for ent_a, comp_a, ent_b, comp_b in narrow_phase_queue:
        # continue
        verts_a = col.get_world_vertices(ent_a, comp_a)
        verts_b = col.get_world_vertices(ent_b, comp_b)
        is_colliding = ampl.collision_check_cvx_cvx(verts_a, verts_b)
        if is_colliding < MAGIC_DISTANCE:
            # print(ent_a, ent_b)
            scene_is_collision_free = False
            break
    # print(scene_is_collision_free)
    # print(scene_is_collision_free)
    return scene_is_collision_free


def get_iks(
    rwts_tactile: np.ndarray,
    kin: CZKinTYpes,
    col: ampl.ColConvex | ampl.SphereBVHScene,
    q_ref_full: np.ndarray,
    which_iks: list[int] = [5, 7],
    which_hand: str = "left" or "right",
    nb_redundant_search: int = 128,
    range_redundant_last_joint: list[float] = [-0.2, 0.2],
    min_dist: float = 5e-3,
) -> tuple[dict[int, np.ndarray], dict[int, np.ndarray]]:
    mask_total = {}
    iks_total = {}

    for w in which_iks:
        mask_total[w] = []
        iks_total[w] = []
    frame_tool = (
        ampl.HBFrames.left_link_tactile_center
        if "left" in which_hand
        else ampl.HBFrames.right_link_tactile_center
    )
    I_START = kin._I_L if "left" in which_hand else kin._I_R
    I_END = kin._I_L_END if "left" in which_hand else kin._I_R_END
    kin.update_kin(q_ref_full)
    if isinstance(col, ampl.ColConvex):
        colfun = collision_free_cvx
    elif isinstance(col, ampl.SphereBVHScene):
        colfun = collision_free_sph
    else:
        raise ValueError(f"col must be one of ampl.ColConvex or ampl.SphereBVHScene")
    q_curr = np.copy(q_ref_full)

    for rwt in rwts_tactile:
        tf_tactile = ampl.Tf(rwt)
        dict_iks = kin.get_ik(
            tf_tactile,
            frame_tool,
            which_iks=which_iks,
            nb_redundant_search=nb_redundant_search,
            range_redundant_last_joint=range_redundant_last_joint,
        )

        for which_ik, ik_data in dict_iks.items():
            mask = ik_data[0].copy()
            qs_ik = ik_data[1].copy()

            for i_ik, q_ik in enumerate(qs_ik):
                if not mask[i_ik]:
                    continue
                # print(mask.sum())
                q_curr = np.copy(q_ref_full)
                np.copyto(q_curr[I_START:I_END], q_ik)
                if not colfun(kin, col, q_curr, min_dist):
                    mask[i_ik] = False
            mask_total[which_ik].append(mask.copy())
            iks_total[which_ik].append(qs_ik.copy())
    for w in which_iks:
        # print(w)
        iks_total[w] = np.array(iks_total[w], dtype=np.float32)
        mask_total[w] = np.array(mask_total[w], dtype=bool)
    return iks_total, mask_total


def _get_path(
    states_single_arm: NDArray[np.float32],
    mask: NDArray[np.bool_] | NDArray[np.bool],
    threshold_single_arm: NDArray[np.float32],
):
    path, min_cost = ampl.dynamicprogram_smooth_path(
        mask, states_single_arm.astype(np.float32), threshold_single_arm
    )
    return path, min_cost


def move_slerp_global(
    q_curr_full: NDArray[np.float32],
    kin: CZKinTYpes,
    col: ampl.ColConvex | ampl.SphereBVHScene,
    tfs_tactile_target: list[ampl.Tf],
    hand: str = "left" or "right",
    slerp_nb_waypoints: int = 100,
    slerp_max_joint_jump: float = 0.05,
    ik_branches: list[int] = [5, 7],
    ik_nb_redundant_search: int = 128,
    ik_range_redundant_last_joint: list[float] = [-1.4, 1.4],
    ik_min_collision_dist: float = 5e-3,
):
    kin.update_kin(q_curr_full)
    if "left" in hand:
        tf_curr = kin.get_fk(kin.Frames.left_link_tactile_center)
        I_START = kin._I_L
        I_END = kin._I_L_END
    else:
        tf_curr = kin.get_fk(kin.Frames.right_link_tactile_center)
        I_START = kin._I_R
        I_END = kin._I_R_END

    rwts = []
    tf_this = tf_curr
    for itf, tf_tactile_target in enumerate(tfs_tactile_target):
        for t in np.linspace(0.0, 1.0, slerp_nb_waypoints):
            tf_t: ampl.Tf = tf_this.slerp(t, tf_tactile_target)
            rwts.append(tf_t.rwt())
        tf_this = tfs_tactile_target[itf]

    iks_sol, iks_masks = get_iks(
        rwts,
        kin,
        col,
        q_ref_full=q_curr_full.copy(),
        which_iks=ik_branches,
        which_hand="left",
        range_redundant_last_joint=ik_range_redundant_last_joint,
        nb_redundant_search=ik_nb_redundant_search,
        min_dist=ik_min_collision_dist,
    )
    threshold = np.full(kin.DOF_A, slerp_max_joint_jump, dtype=np.float32)
    trajs_full = {}
    for branch in ik_branches:
        state = iks_sol[branch]
        state_mask = iks_masks[branch]
        path, cost = _get_path(state, state_mask, threshold)
        if cost > 100000:
            print("# NO FEASIBLE PATH")
            continue
        traj = np.array(state[np.arange(state.shape[0]), path])

        trajs_full[branch] = np.tile(q_curr_full, (len(traj), 1))
        np.copyto(trajs_full[branch][:, I_START:I_END], traj)
    return trajs_full, np.array(rwts)


def set_colsph_topology_from_wbc(wbc: ampl.WBC277, col: ampl.SphereBVHScene):
    macro_region_sph = [[]] + wbc.controller.macro_regions
    joint_to_region_sph = [s + 1 for s in wbc.controller.joint_to_region]
    joint_to_region_sph = [0] + joint_to_region_sph
    col.set_region_mapping(macro_region_sph, joint_to_region_sph)
    return


def update_self_collision_for_wbc(
    q: np.ndarray,
    wbc: ampl.WBC277,
    kin: ampl.Kin,
    colsph: ampl.SphereBVHScene,
    distance_waring: float = 0.1,
    tf_base: ampl.Tf = None,
):
    kin.update_kin(q, tf_base, True)
    np.copyto(wbc._Js, kin.get_jacobian_actuated_frame())
    np.copyto(wbc._fk, kin.get_fk_actuated_frame())
    np.copyto(wbc._q_curr, q)
    colsph.update_poses(1, wbc._fk)
    if tf_base:
        colsph.update_poses(0, np.array([tf_base.as_array()], dtype=np.float64))
    pairs = colsph.compute_collisions(distance_waring)
    if len(pairs) == 0:
        return 0

    nc = colsph.fill_contact_jacobians(
        pairs,
        wbc._Js,
        start_idx=0,
        J_cbf_out=wbc._J_cbf,
        distances_out=wbc._d_cbf,
        max_top_k=1,
        col_shift_cbf=0,
    )
    return nc


def track_tcp(
    q: np.ndarray,
    wbc: ampl.WBC277,
    kin: ampl.KinHB10 | ampl.KinHB11 | ampl.KinHB20,
    colsph: ampl.SphereBVHScene,
    distance_waring: float = 0.1,
    tf_tgt_L: ampl.Tf = None,
    tf_tgt_R: ampl.Tf = None,
    swivel_L: float = 0.0,
    swivel_R: float = 0.0,
):
    nb_contact_warning = update_self_collision_for_wbc(
        q, wbc, kin, colsph, distance_waring
    )
    # print("nb")
    # print("wbc._q_curr")
    # print(wbc._q_curr)
    q_max = np.array(wbc.joint_limits["global_joint_limits"].q_max)
    q_min = np.array(wbc.joint_limits["global_joint_limits"].q_min)
    # print(q_max)
    # print(q_min)
    wbc.joint_limits["global_joint_limits"].update(wbc._q_curr)

    if tf_tgt_L:
        tf_curr = kin.get_fk(kin.Frames.left_link_tactile_center)
        tf_diff = tf_tgt_L @ tf_curr.inv()
        wbc._v_goal_L = tf_tgt_L.position - tf_curr.position
        wbc._w_goal_L = tf_diff.log_so3()
    else:
        wbc._v_goal_L[:] = 0
        wbc._w_goal_L[:] = 0
    if tf_tgt_R:
        tf_curr = kin.get_fk(kin.Frames.right_link_tactile_center)
        tf_diff = tf_tgt_R @ tf_curr.inv()
        wbc._v_goal_R = tf_tgt_R.position - tf_curr.position
        wbc._w_goal_R = tf_diff.log_so3()

    else:
        wbc._v_goal_R[:] = 0
        wbc._w_goal_R[:] = 0

    if 1:
        wbc.linear_tasks["left_hand_linear"].update(
            wbc._Js, wbc._v_goal_L, tcp_in_base=tf_curr.position
        )
        wbc.angular_tasks["left_hand_angular"].update(wbc._Js, wbc._w_goal_L)
        ps, pe, pw = (
            wbc._fk[kin.DOF_T + 1, -3:],
            wbc._fk[kin.DOF_T + 3, -3:],
            wbc._fk[kin.DOF_T + 5, -3:],
        )
        wbc.swivel_tasks["left_elbow_swivel"].update(ps, pe, pw, wbc._Js, swivel_L)
    if 1:
        wbc.linear_tasks["right_hand_linear"].update(
            wbc._Js, wbc._v_goal_R, tcp_in_base=tf_curr.position
        )
        wbc.angular_tasks["right_hand_angular"].update(wbc._Js, wbc._w_goal_R)
        ps, pe, pw = (
            wbc._fk[1 + kin.DOF_T + kin.DOF_A, -3:],
            wbc._fk[3 + kin.DOF_T + kin.DOF_A, -3:],
            wbc._fk[5 + kin.DOF_T + kin.DOF_A, -3:],
        )
        wbc.swivel_tasks["right_elbow_swivel"].update(ps, pe, pw, wbc._Js, -swivel_R)
    D_SAFE = -1e-4
    if nb_contact_warning > 0:
        current_state = CollisionState.SAFE_TRACKING
        J_cbf = -wbc._J_cbf[:nb_contact_warning].astype(np.float64)
        d_cbf = wbc._d_cbf[:nb_contact_warning].astype(np.float64)
        min_dist = np.min(d_cbf)

        if min_dist <= D_SAFE:
            current_state = CollisionState.DANGER
        elif min_dist <= distance_waring:
            current_state = CollisionState.WARNING
        else:
            current_state = CollisionState.SAFE_TRACKING
        if current_state == CollisionState.DANGER:
            wbc.linear_tasks["left_hand_linear"].set_active(False)
        elif current_state == CollisionState.WARNING:
            track_alpha = (min_dist - D_SAFE) / (distance_waring - D_SAFE)
            wbc.linear_tasks["left_hand_linear"].set_active(True)
            wbc.linear_tasks["left_hand_linear"].set_weight(1.0 * track_alpha)
        elif current_state == CollisionState.SAFE_TRACKING:
            wbc.linear_tasks["left_hand_linear"].set_active(True)
            wbc.linear_tasks["left_hand_linear"].set_weight(1.0)

        wbc.collision_limits["self_collision"].set_active(True)
        wbc.collision_limits["self_collision"].update_direct(J_cbf, d_cbf)
    else:
        wbc.collision_limits["self_collision"].set_active(False)
        wbc.linear_tasks["left_hand_linear"].set_weight(1.0)
        wbc.linear_tasks["right_hand_linear"].set_weight(1.0)
    wbc.repulsion_tasks["self_repulsion"].set_active(False)
    # wbc.swivel_tasks["left_elbow_swivel"].set_active(False)
    # wbc.swivel_tasks["right_elbow_swivel"].set_active(False)
    # wbc.repulsion_tasks["self_repulsion"].set_active(False)
    # wbc.collision_limits["self_collision"].set_active(False)

    dq = wbc.controller.solve()
    sol_status = wbc.controller.solver_status()
    # print(sol_status)
    if sol_status >= 0:
        q = np.clip(wbc._q_curr + dq, q_min, q_max).astype(np.float64)
        wbc.reg_tasks["base_regularization"].update_history(dq)

    return q
