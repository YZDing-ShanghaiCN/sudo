from __future__ import annotations
import numpy as np
from typing import Literal
from importlib import resources
from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any
from enum import IntEnum, auto
import ampl

HBTypes = Literal["hb10", "hb11", "hb20", "loong"]
HBKinTypes = ampl.KinHB10 | ampl.KinHB11 | ampl.KinHB20 | ampl.KinLoong
CZTypes = Literal["cruzrs2"]
CZKinTYpes = ampl.KinCruzrs2
DATypes = Literal["tianji"]  # DA = Dual Arm
DAKinTypes = ampl.KinTJ


@dataclass(frozen=True, slots=True)
class Topology:
    macro_regions: list[list[list[int]]]
    joint_to_region: list[int]
    id_to_col_shift: int = 0


@dataclass(frozen=True, slots=True)
class RobotMeta:
    """Central container for all robot metadata."""

    robot_name: str
    topology: Topology

    @staticmethod
    def _parse_topology(raw: dict[str, Any]) -> Topology:
        topo_raw = raw.get("topology")
        if topo_raw is None:
            raise ValueError("Missing 'topology' in data")
        return Topology(**topo_raw)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RobotMeta:
        flat = {k: v for k, v in data.items() if k != "topology"}
        return cls(topology=cls._parse_topology(data), **flat)

    @classmethod
    def from_json(cls, path: str | Path) -> RobotMeta:
        with open(path) as f:
            data = json.load(f)
        return cls.from_dict(data)


class CollisionState(IntEnum):
    SAFE_TRACKING = auto()  # d_min > d_warn
    WARNING = auto()  # d_safe < d_min <= d_warn
    DANGER = auto()  # d_min <= d_safe
