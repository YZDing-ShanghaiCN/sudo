import ampl
import ampl_motion as am
import numpy as np
import argparse


def main():
    parser = argparse.ArgumentParser(
        description="Return self-collision status.",
        epilog="ampl-colfreetraj hb11 --file_q_full q_full.txt --save_mesh pp.ply --save_mesh_skip 10 --save_status status.txt",
    )
    parser.add_argument(
        "robot_name", type=str, help="Name of the robot (e.g., hb10, hb11, hb20)"
    )
    parser.add_argument(
        "--verbose", action="store_true", help="Print detailed planning logs"
    )
    parser.add_argument("--file_q_full", type=str, help="(num_waypoint, robot dof)")

    parser.add_argument(
        "--min_d",
        type=float,
        help="Minimal collision distance (default 1.5e-3)",
        default=1.5e-3,
    )
    parser.add_argument(
        "--proxy",
        type=str,
        help="Collision proxy = cvx or sph",
        default="cvx",
    )

    def check_ply_extension(value):
        if not value.lower().endswith(".ply"):
            raise argparse.ArgumentTypeError(
                f"Only .ply files are supported. '{value}' is invalid."
            )
        return value

    parser.add_argument(
        "--save_mesh",
        type=check_ply_extension,
        help="Save mesh file of current state. Must be .ply",
        default=None,
    )
    parser.add_argument(
        "--save_mesh_skip",
        type=int,
        help="Save mesh only every k state",
        default=1,
    )
    parser.add_argument(
        "--save_status",
        type=str,
        help="Save collision status",
        default=None,
    )

    # 2. Parse the inputs
    args = parser.parse_args()

    if args.verbose:

        print("---Verbose: Parsed Arguments---")
        for key, value in vars(args).items():
            print(f"  {key}: {value}")
        print("-------------------------------")
        print(f"Loading robot: {args.robot_name}...")

    # 3. Use the input in your code
    try:
        (
            meta,
            kin,
            colcvx,
            colsph,
            wbc,
            frame_to_id,
            ignores,
            coldata_cvx,
            coldata_sph,
        ) = am.create_robot_system(args.robot_name)
    except ValueError as e:
        print(f"Error: {e}")
        return
    am.update_ignore(colcvx, frame_to_id, ignores)
    am.update_ignore(colsph, frame_to_id, ignores)
    # print(ignores)

    # q = np.array(args.q_torso + args.q_left + args.q_right, dtype=np.float64)

    qs = np.loadtxt(args.file_q_full)
    if args.proxy == "cvx":
        colproxy = colcvx
    else:
        colproxy = colsph

    is_colfree = np.full(len(qs), fill_value=True, dtype=bool)
    for iq, q in enumerate(qs):
        is_colfree[iq] = am.collision_free_cvx(
            kin, colproxy, q, MAGIC_DISTANCE=args.min_d
        )

        # is_colfree = am.collision_free_sph(kin, colsph, q, MAGIC_DISTANCE=args.min_d)
    # print(is_colfree)

    vf_traj = []

    for iq, q_traj in enumerate(qs):
        if iq % args.save_mesh_skip == 0:
            am.collision_free_cvx(kin, colcvx, q_traj)
            vf = am.debug_col_cvx(coldata_cvx, colcvx)
            vf_traj.append(vf)

    if vf_traj:
        if args.save_mesh is not None:
            vf = ampl.trimesh_concatenate(vf_traj)
            ampl.write_trimesh(args.save_mesh, vf[0], vf[1])
    if args.save_status:
        np.savetxt(args.save_status, is_colfree)
    # if args.save_mesh is not None:
    #     if args.proxy == "cvx":
    #         vf = am.debug_col_cvx(coldata_cvx, colcvx)
    #         ampl.write_trimesh(args.save_mesh, vf[0], vf[1])
    #     if args.proxy == "sph":
    #         vf = am.debug_col_sph(colsph, bvh_level=2)
    #         ampl.write_trimesh(args.save_mesh, vf[0], vf[1])
    return


if __name__ == "__main__":

    main()
