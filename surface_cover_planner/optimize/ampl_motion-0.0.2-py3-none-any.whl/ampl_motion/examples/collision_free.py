import ampl
import ampl_motion as am
import numpy as np
import argparse


def main():
    parser = argparse.ArgumentParser(description="Plan a motion for a specific robot.")
    parser.add_argument(
        "robot_name", type=str, help="Name of the robot (e.g., hb10, hb11, hb20)"
    )
    parser.add_argument(
        "--verbose", action="store_true", help="Print detailed planning logs"
    )
    parser.add_argument(
        "--q_torso",
        nargs="+",
        type=float,
        help="Torso joint state",
        default=[0.15, 0.3],
    )
    parser.add_argument(
        "--q_left",
        nargs="+",
        type=float,
        help="Left joint state",
        default=[0.8, 0.64, 1.5, -1.65, -0.8, -0.8, 0.6],
    )
    parser.add_argument(
        "--q_right",
        nargs="+",
        type=float,
        help="Right joint state",
        default=[0.8, 0.64, 1.5, -1.65, -0.8, -0.8, 0.6],
    )
    parser.add_argument(
        "--min_d",
        type=float,
        help="Minimal collision distance (default 1.5e-3)",
        default=1.5e-3,
    )
    parser.add_argument(
        "--proxy",
        type=str,
        help="Collision proxy = cvx or sph",
        default="cvx",
    )

    def check_ply_extension(value):
        if not value.lower().endswith(".ply"):
            raise argparse.ArgumentTypeError(
                f"Only .ply files are supported. '{value}' is invalid."
            )

        return value

    parser.add_argument(
        "--save_mesh",
        type=check_ply_extension,
        help="Save mesh file of current state. Must be .ply",
        default=None,
    )

    # 2. Parse the inputs
    args = parser.parse_args()

    if args.verbose:

        print("---Verbose: Parsed Arguments---")
        for key, value in vars(args).items():
            print(f"  {key}: {value}")
        print("-------------------------------")
        print(f"Loading robot: {args.robot_name}...")

    # 3. Use the input in your code
    try:
        (
            meta,
            kin,
            colcvx,
            colsph,
            wbc,
            frame_to_id,
            ignores,
            coldata_cvx,
            coldata_sph,
        ) = am.create_robot_system(args.robot_name)
    except ValueError as e:
        print(f"Error: {e}")
        return
    am.update_ignore(colcvx, frame_to_id, ignores)
    am.update_ignore(colsph, frame_to_id, ignores)

    q = np.array(args.q_torso + args.q_left + args.q_right, dtype=np.float64)
    kin.update_kin(q)
    if args.proxy == "cvx":
        is_colfree = am.collision_free_cvx(kin, colcvx, q, MAGIC_DISTANCE=args.min_d)
    elif args.proxy == "sph":
        is_colfree = am.collision_free_sph(kin, colsph, q, MAGIC_DISTANCE=args.min_d)
    print(is_colfree)
    if args.save_mesh is not None:
        if args.proxy == "cvx":
            vf = am.debug_col_cvx(coldata_cvx, colcvx)
            ampl.write_trimesh(args.save_mesh, vf[0], vf[1])
        if args.proxy == "sph":
            vf = am.debug_col_sph(colsph, bvh_level=2)
            ampl.write_trimesh(args.save_mesh, vf[0], vf[1])
    return is_colfree


if __name__ == "__main__":

    main()
