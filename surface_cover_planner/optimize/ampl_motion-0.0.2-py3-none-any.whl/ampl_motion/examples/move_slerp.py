import ampl
import ampl_motion as am
import numpy as np
import argparse


def main():
    parser = argparse.ArgumentParser(
        description="Plan a collision-free move_ee motion for a specific robot."
    )
    parser.add_argument(
        "robot_name", type=str, help="Name of the robot (e.g., hb10, hb11, hb20)"
    )
    parser.add_argument(
        "--verbose", action="store_true", help="Print detailed planning logs"
    )
    parser.add_argument(
        "--q_torso",
        nargs="+",
        type=float,
        help="Torso joint state",
        default=[0.15, 0.3],
    )
    parser.add_argument(
        "--q_left",
        nargs="+",
        type=float,
        help="Left joint state",
        default=[0.8, 0.64, 1.5, -1.65, -0.8, -0.8, 0.6],
    )
    parser.add_argument(
        "--q_right",
        nargs="+",
        type=float,
        help="Right joint state",
        default=[0.8, 0.64, 1.5, -1.65, -0.8, -0.8, 0.6],
    )
    parser.add_argument(
        "--min_d",
        type=float,
        help="Minimal collision distance (default 1.5e-3)",
        default=1.5e-3,
    )
    parser.add_argument(
        "--proxy",
        type=str,
        help="Collision proxy = cvx or sph",
        default="cvx",
    )
    parser.add_argument(
        "--hand",
        type=str,
        choices=["left", "right"],
        required=True,
        help="Which hand to move: left or right",
    )
    parser.add_argument(
        "--target_pose",
        nargs=7,
        type=float,
        required=True,
        help="Target pose: w x y z tx ty tz (quaternion + position)",
        metavar=("W", "X", "Y", "Z", "TX", "TY", "TZ"),
    )
    parser.add_argument(
        "--waypoints",
        type=int,
        default=10,
        help="Number of waypoints for move_ee trajectory (default: 10)",
    )
    parser.add_argument(
        "--branch",
        type=int,
        default=7,
        help="IK branch (default 5 left 7 right)",
    )
    parser.add_argument(
        "--redundant",
        type=int,
        default=256,
        help="Discrete redundant search",
    )
    parser.add_argument(
        "--max_joint_jump",
        type=float,
        default=0.1,
        help="Maximum allowed joint jump between consecutive waypoints in rad (default: 0.1)",
    )

    def check_ply_extension(value):
        if not value.lower().endswith(".ply"):
            raise argparse.ArgumentTypeError(
                f"Only .ply files are supported. '{value}' is invalid."
            )
        return value

    parser.add_argument(
        "--save_mesh",
        type=check_ply_extension,
        help="Save mesh file of current trajectory. Must be .ply",
        default=None,
    )
    parser.add_argument(
        "--save_traj",
        help="Save trajectory txt",
        default=None,
    )

    # Parse the inputs
    args = parser.parse_args()

    if args.verbose:
        print("---Verbose: Parsed Arguments---")
        for key, value in vars(args).items():
            print(f"  {key}: {value}")
        print("-------------------------------")
        print(f"Loading robot: {args.robot_name}...")

    # Reconstruct target pose from the combined argument
    target_wxyz = np.array(args.target_pose[:4], dtype=float)
    target_pos = np.array(args.target_pose[4:], dtype=float)

    if args.verbose:
        print(f"Move target hand : {args.hand}")
        print(f"Target quaternion : {target_wxyz}")
        print(f"Target position   : {target_pos}")
        print(f"Waypoints         : {args.waypoints}")
        print(f"Max joint jump    : {args.max_joint_jump} rad")

    (
        meta,
        kin,
        colcvx,
        colsph,
        wbc,
        frame_to_id,
        ignores,
        coldata_cvx,
        coldata_sph,
    ) = am.create_robot_system(args.robot_name)
    am.update_ignore(colcvx, frame_to_id, ignores)
    am.update_ignore(colsph, frame_to_id, ignores)
    wbc.joint_limits["global_joint_limits"].update_limits(
        np.array(kin.get_limits()[0]),
        np.array(kin.get_limits()[1]),
        np.array(
            [
                0e-4,
                0e-5,
                6e-2,
                6e-2,
                6e-2,
                6e-2,
                6e-2,
                6e-2,
                6e-2,
                6e-2,
                6e-2,
                6e-2,
                6e-2,
                6e-2,
                6e-2,
                6e-2,
            ]
        ),
    )

    q_curr_full = np.array(args.q_torso + args.q_left + args.q_right, dtype=np.float64)
    kin.update_kin(q_curr_full)
    # q = np.array([0] * 16, dtype=np.float64)

    # if args.hand == "left":
    #     kinframe = kin.Frames.left_link_tactile_center
    # else:
    #     kinframe = kin.Frames.right_link_tactile_center

    tf_tgt = ampl.Tf(
        np.array(args.target_pose, dtype=np.float64)[[1, 2, 3, 0, 4, 5, 6]]
    )  # kin.get_fk(kinframe)

    ik_colfree_trajs, rwts_tgt = am.move_slerp_global(
        q_curr_full,
        kin,
        colsph,
        [tf_tgt],
        args.hand,
        args.waypoints,
        args.max_joint_jump,
        ik_nb_redundant_search=args.redundant,
        ik_range_redundant_last_joint=[
            kin.get_limits()[0][-1],
            kin.get_limits()[1][-1],
        ],
        ik_branches=[args.branch],
    )
    vf_traj = []

    id = args.branch
    for q_traj in ik_colfree_trajs[id]:
        am.collision_free_cvx(kin, colcvx, q_traj)
        vf = am.debug_col_cvx(coldata_cvx, colcvx)
        vf_traj.append(vf)

    if vf_traj:
        if args.save_mesh is not None:
            vf = ampl.trimesh_concatenate(vf_traj)
            ampl.write_trimesh(args.save_mesh, vf[0], vf[1])
        if args.save_traj:
            np.savetxt(args.save_traj, ik_colfree_trajs[id])


if __name__ == "__main__":
    main()
