import numpy as np
from typing import Tuple, Union, List
import math

DTypeVerticesFaces = Tuple[np.ndarray, np.ndarray]
DTypeListVertices = List[np.ndarray]
DTypeVertices = np.ndarray
DTypeConvex = Union[DTypeVerticesFaces, DTypeListVertices]
DTypeState = np.ndarray
DTypeFloat = np.float32
DTypeDouble = np.float64
DTypeIndex = np.uint32
DTypeBool = np.bool_
EPS_CONVEX_COLLISION = 2e-3
INF_FLOAT = float("inf")
import ampl


class CollisionSceneBase:
    def __init__(self):
        return


class AgentBase:
    def __init__(self, bounds: np.ndarray = None):
        self.dim = 0
        if bounds:
            self.bounds = bounds
        else:
            self.bounds = DTypeState([0.0] * self.dim)
        return

    def set_base(self, pose: np.ndarray):
        return

    def collision_free(self, q: DTypeState, env: CollisionSceneBase) -> bool:
        return False

    def collision_free_trajectory(
        self,
        q_start: DTypeState,
        q_end: DTypeState,
        env: CollisionSceneBase,
        num: int = 12,
        include_start=False,
        include_end=True,
    ) -> bool:
        return False

    def collision_free_trajectory_no_attach(
        self,
        q_start: DTypeState,
        q_end: DTypeState,
        env: CollisionSceneBase,
        num: int = 16,
        include_start=True,
        include_end=True,
    ) -> bool:
        return False

    def collision_free_trajectory_attach(
        self,
        q_start: DTypeState,
        q_end: DTypeState,
        env: CollisionSceneBase,
        num: int = 16,
        include_start=True,
        include_end=True,
    ) -> bool:
        return False

    def sample_state(self) -> DTypeState:
        return np.random.uniform(self.bounds[0], self.bounds[1])


class MotionPlannerBase:
    def __init__(self, agent: AgentBase = None, env: CollisionSceneBase = None):
        self.agent: AgentBase = agent
        self.env: CollisionSceneBase = env
        return

    def solve_feasible(
        self, state_init: DTypeState, state_goal: DTypeState
    ) -> Tuple[bool, DTypeState]:
        return False, np.array([], dtype=DTypeFloat)

    def shortcut(
        self, trajectory_feasible: DTypeState, nb_subdivision_internal: int = 1
    ) -> DTypeState:

        graph, graph_waypoints = ampl.graph_from_polyline(
            trajectory_feasible, nb_subdivision_internal
        )
        nb_node = len(graph_waypoints)
        for i in range(0, nb_node - (nb_subdivision_internal + 1)):
            for j in range(i + (nb_subdivision_internal + 1), nb_node, 3):
                if self.agent.collision_free_trajectory(
                    graph_waypoints[i].copy(),
                    graph_waypoints[j].copy(),
                    self.env,
                    12,
                    True,
                    True,
                ):
                    wij = np.linalg.norm(
                        graph_waypoints[j].copy() - graph_waypoints[i].copy()
                    )
                    graph[i].append((j, wij))
        new_path_len, new_path = ampl.graph_dijkstra_single(
            graph, nb_node, 0, nb_node - 1
        )
        return graph_waypoints[new_path].copy()
