import ampl
import numpy as np
from ..common import AgentBase
from ..arm import WrapperArm6

from ..util import create_obb3
from ..common import *
from ..collision import CollisionScene
from ..util import sample_trajectory_trivial

class ArmIndudstrial(AgentBase):
    def __init__(self, name="elfin", arm_type:ampl.ArmType=ampl.ArmType.Industrial6, dim:int=6):
        super().__init__()
        self.name:str = name
        self.dim:int = dim
        self.arm:WrapperArm6 = WrapperArm6(self.name,arm_type, self.dim)
        self.bounds = self.arm.bounds
        self.d_safe = 0.0        
        self._wall = np.array([0.0, -0.3, 0.7, 100, 1.5, 1.4], dtype=DTypeFloat)
        self.arm_xyzr:list[np.ndarray] = []
        self.rng = ampl.RNG6()
        self.rng.set_range(np.array(self.bounds[0]), np.array(self.bounds[1]))
        self._pose_base = np.array([0,0,0,1,0,0,0], dtype=np.float64)
        self.which_iks:list[int] = [0,1,2,3,4,5,6,7]
        self.q_ref = np.array([-0.223, 0.76, 1.959, -1.603, -0.725, -0.585, 0.906])
        self.COLLISION_CHECK_LINK_RANGE:list[int] = [2, 6]
        self.wall = np.array([-100, -100, -100, 100, 100, 100], dtype=DTypeFloat)
        # for _, v in DICT_PACKED_SPHERES.items():
        #     self.arm_xyzr.append(np.array(v, dtype=np.float32).reshape((-1, 4)))
        #self.arm.set_collision_arm(self.arm_xyzr)
        
        #self.obb3_torso = create_obb3(OBB3_TORSO)
        # self.tf_base_arm_base = TF44_HILLBOT_LEFT_IN_BASE_LINK.copy()
        
        #self.arm.set_base(TF44_HILLBOT_LEFT_IN_BASE_LINK)
        
        # self.global_map=None
        #self.solutions_dark = []
        

        # print(self.obb3_torso)

    @property
    def pose_base(self):
        return self._pose_base

    @pose_base.setter
    def pose_base(self, rwt: np.ndarray):
        np.copyto(dst=self._pose_base, src=rwt)
        self.arm.set_base(ampl.qt7_to_tf44(self._pose_base))

    @property
    def wall(self):
        return self._wall

    @wall.setter
    def wall(self, wall_in_base: np.ndarray):
        np.copyto(dst=self._wall, src=wall_in_base.astype(DTypeFloat))
        self.arm.set_base(ampl.qt7_to_tf44(self._pose_base))

    
    def ik_tool0(self, pose_tool0:Union[np.ndarray,tuple]) -> np.ndarray:        
        if isinstance(pose_tool0,np.ndarray):
            if (len(pose_tool0.shape)==2):
                ikstatus = self.arm.solver.ik(pose_tool0, self.arm.q8)
                return self.arm.q8, ikstatus
            else:
                tf_ik=ampl.qt7_to_tf44(pose_tool0)
                ikstatus = self.arm.solver.ik(tf_ik, self.arm.q8)
                return self.arm.q8, ikstatus
        elif isinstance(pose_tool0,tuple):
            tf_ik=ampl.wxyz_t_to_tf44(pose_tool0[0],pose_tool0[1])
            
            ikstatus = self.arm.solver.ik(tf_ik.astype(np.float64), self.arm.q8)
            
            return self.arm.q8, ikstatus
        