import ampl
import numpy as np
from ..common import AgentBase
from ..arm import WrapperArm7
import heapq
from .collision_data_hillbot import OBB3_HILLBOT_TORSO_VLA as OBB3_TORSO
from .collision_data_hillbot import (
    DICT_PACKED_SPHERES_HILLBOT_LEFT as DICT_PACKED_SPHERES,
)
from .collision_data_hillbot import TF44_HILLBOT_LEFT_IN_BASE_LINK
from .collision_data_hillbot import TF44_HILLBOT_RIGHT_IN_BASE_LINK
from ..util import create_obb3
from ..common import *
from ..collision import CollisionScene
from ..util import sample_trajectory_trivial

# from planner_ampl import RRTConnect


class HillbotLeft(AgentBase):
    def __init__(self, name="hillbot_left", dim=7):
        super().__init__()

        self.name = name
        self.dim = dim
        self.arm = WrapperArm7(self.name, self.dim)
        self.bounds = self.arm.bounds
        self.d_safe = 0.0
        # self.wall = np.array([-100, -100, -100, 100, 100, 100], dtype=np.float32)
        self._wall = np.array([0.0, -0.3, 0.7, 100, 1.5, 1.4], dtype=DTypeFloat)
        self.arm_xyzr = []
        for _, v in DICT_PACKED_SPHERES.items():
            self.arm_xyzr.append(np.array(v, dtype=np.float32).reshape((-1, 4)))
        self.arm.set_collision_arm(self.arm_xyzr)
        self.rng = ampl.RNG7()
        self.rng.set_range(np.array(self.bounds[0]), np.array(self.bounds[1]))
        self.obb3_torso = create_obb3(OBB3_TORSO)
        # self.tf_base_arm_base = TF44_HILLBOT_LEFT_IN_BASE_LINK.copy()
        self._pose_base = ampl.tf44_to_qt7(TF44_HILLBOT_LEFT_IN_BASE_LINK)
        self.arm.set_base(TF44_HILLBOT_LEFT_IN_BASE_LINK)
        self.which_iks = [5, 6, 7]
        self.q_ref = np.array([-0.223, 0.76, 1.959, -1.603, -0.725, -0.585, 0.906])
        # self.global_map=None
        self.solutions_dark = []
        self.COLLISION_CHECK_LINK_RANGE = [2, 7]

        # print(self.obb3_torso)

    @property
    def pose_base(self):
        return self._pose_base

    @pose_base.setter
    def pose_base(self, rwt: np.ndarray):
        np.copyto(dst=self._pose_base, src=rwt)
        self.arm.set_base(ampl.qt7_to_tf44(self._pose_base))

    @property
    def wall(self):
        return self._wall

    @wall.setter
    def wall(self, wall_in_base: np.ndarray):
        np.copyto(dst=self._wall, src=wall_in_base.astype(DTypeFloat))
        self.arm.set_base(ampl.qt7_to_tf44(self._pose_base))

    def collision_free(self, q: DTypeState, env: CollisionScene) -> bool:

        self.arm.solver.fk_links(q, self.arm.qtLink)
        for iq, rwt in enumerate(self.arm.qtLink):
            if iq < self.COLLISION_CHECK_LINK_RANGE[0]:
                continue
            if iq >= self.COLLISION_CHECK_LINK_RANGE[1]:
                continue
            ampl.collision_transform_object(self.arm.sphs, self.arm.sphs_mov, iq, rwt)
            if ampl.collision_check_obb_vsph(
                self.obb3_torso, self.arm.sphs_mov, iq, self.wall
            ):
                return False
            if ampl.collision_check_df_vsph(
                env.df, self.arm.sphs_mov, iq, self.d_safe, self.wall
            ):
                return False
        return True

    def sample_state(self) -> DTypeState:
        x = np.array([0] * 7, dtype=np.float64)
        self.rng.next(x, 1)
        return x.astype(DTypeFloat)

    def collision_free_trajectory(
        self,
        q_start: np.array,
        q_end: np.array,
        env: CollisionSceneBase,
        num: int = 12,
        include_start=False,
        include_end=True,
    ) -> bool:
        trajectory = sample_trajectory_trivial(
            q_start, q_end, num, include_start, include_end
        )
        for q in trajectory[0:-1:2]:
            if not self.collision_free(q, env):
                return False
        for q in trajectory[1:-1:2]:
            if not self.collision_free(q, env):
                return False
        return True

    # def eefk(self, q: np.array) -> np.array:
    #     self.arm.solver.fk_links(q, self.arm.qtLink)
    #     return self.arm.qtLink[-1]

    # def eeik(self, tf_tool0, q_last) -> np.array:
    #     self.arm.q8[:, -1] = q_last
    #     ikstatus = self.arm.solver.ik(tf_tool0, self.arm.q8)
    #     return self.arm.q8, ikstatus

    # def collision_free_ik_q7_batch(
    #     self, tf44_ee_target: np.array, NB_Q_SEARCH: int = 64
    # ):
    #     q_search = np.linspace(
    #         self.bounds[0][-1], self.bounds[1][-1], NB_Q_SEARCH + 1, True
    #     )
    #     iks_batch = np.zeros((len(q_search), 8), dtype=bool)
    #     ikq_batch = np.zeros((len(q_search), 8, self.arm.dof), dtype=np.float32)
    #     for which_ik in self.which_iks:
    #         for iq, ql in enumerate(q_search):
    #             self.arm.q8[:, -1] = ql
    #             ikstatus = self.arm.solver.ik(tf44_ee_target, self.arm.q8)
    #             if (ikstatus >> which_ik) & 1:
    #                 iks_batch[iq, which_ik] = True
    #                 ikq_batch[iq, which_ik] = self.arm.q8[which_ik].copy()
    #     return ikq_batch, iks_batch

    def collision_free_wall_torso(self, q: np.array, LINK_ID_COLLISION_START=2) -> bool:
        self.arm.solver.fk_links(q, self.arm.qtLink)
        for iq, rwt in enumerate(self.arm.qtLink):
            if iq < LINK_ID_COLLISION_START:
                continue
            ampl.collision_transform_object(self.arm.sphs, self.arm.sphs_mov, iq, rwt)
            if ampl.collision_check_obb_vsph(
                self.obb3_torso, self.arm.sphs_mov, iq, self.wall
            ):
                return False
                # if ampl.collision_check_df_vsph(
                #     self.df, self.arm.sphs_mov, iq, self.d_safe, self.wall
                # ):
                return False
        return True

    def collision_free_ik_q7(self, tf44_ee_target: np.array, NB_Q_SEARCH: int = 128):
        q_search = np.linspace(
            self.bounds[0][-1], self.bounds[1][-1], NB_Q_SEARCH + 1, True
        )
        # print(self.which_iks)
        # q_mid = (np.array(self.bounds[0]) + np.array(self.bounds[1])) * (0.5)
        # which_iks = [0, 1, 2, 3, 4, 5, 6, 7
        # print(self.which_iks)

        SCORE_MAX = 100000.0
        score_best = SCORE_MAX
        pq = [SCORE_MAX, None]
        for which_ik in self.which_iks:
            for ql in q_search:
                self.arm.q8[:, -1] = ql
                ikstatus = self.arm.solver.ik(tf44_ee_target, self.arm.q8)
                # print(ikstatus)

                if (ikstatus >> which_ik) & 1:
                    solution = self.arm.q8[which_ik].copy()
                    if self.collision_free_wall_torso(solution):
                        # if 1:
                        score = np.linalg.norm(self.q_ref - solution)
                        if score < score_best:
                            pq[0] = score
                            pq[1] = solution.copy()
                            score_best = score
                            # SCORE_MAX = score
                        # \\return [self.q_ref]
                        # heapq.heappush(pq, (score, (solution, which_ik)))

        # if len(pq) == 0:
        #     return []
        # priority, task = heapq.heappop(pq)
        # # print(task)
        # return [task[0].copy()]
        # print(SCORE_MAX)

        if pq[0] == 100000.0:
            return []
        # print(score_best, pq[1].tolist())
        return [pq[1]]

    def collision_free_ik(
        self,
        q_ref: np.array,
        xyz_target: np.array,
        NB_Q_SEARCH: int = 64,
        NB_ROTZ_SEARCH: int = 48,
        MAX_ANGLE_Z: float = 8.0 / 180.0 * np.pi,
        MIN_ANGLE_Z: float = 2.0 / 180.0 * np.pi,
        DELTA_THETA_Z: float = 2.0 / 180.0 * np.pi,
    ):

        q_search = np.linspace(
            -np.pi / 2 * 0.99, np.pi / 2 * 0.99, NB_Q_SEARCH + 1, True
        )
        self.arm.solver.fk_links(q_ref, self.arm.qtLink)  # update fk ref
        tf44_ee_ref = ampl.qt7_to_tf44(self.arm.qtLink[-1])
        self.arm.q8[:, -1] = q_ref[-1]
        ikstatus = self.arm.solver.ik(tf44_ee_ref, self.arm.q8)
        q_lo, q_hi = self.arm.solver.joint_limits()
        q_mid = (np.array(q_lo) + np.array(q_hi)) * (0.5)
        R_ee_ref = tf44_ee_ref[:3, :3]
        gripper_y_in_base = np.array(R_ee_ref[:, 1].flatten(), dtype=np.float64)
        tf44_ee_target = np.eye(4, dtype=np.float64)
        tf44_ee_target[:3, 3] = xyz_target.flatten()
        pq = []
        for theta_z in np.linspace(
            MIN_ANGLE_Z,
            MAX_ANGLE_Z,
            int((MAX_ANGLE_Z - MIN_ANGLE_Z) / DELTA_THETA_Z) + 1,
            endpoint=True,
        ):
            unit_z = np.array([0, np.sin(theta_z), np.cos(theta_z)], dtype=np.float64)
            R_rectify = ampl.SO3_align(gripper_y_in_base, unit_z) @ R_ee_ref
            for theta in np.linspace(-np.pi, np.pi, NB_ROTZ_SEARCH, endpoint=True):
                tf44_ee_target[:3, :3] = ampl.so3_upexp(unit_z * theta) @ R_rectify
                tf44_ee_target[:3, 3] = xyz_target.flatten()
                # print(tf44_ee_target[:3, :3] @ np.array([0, 1, 0]))
                for which_ik in self.which_iks:
                    for ql in q_search:
                        self.arm.q8[:, -1] = ql
                        ikstatus = self.arm.solver.ik(tf44_ee_target, self.arm.q8)
                        if (ikstatus >> which_ik) & 1:
                            solution = self.arm.q8[which_ik].copy()
                            if self.collision_free(solution):
                                score = np.linalg.norm(q_mid - solution)
                                heapq.heappush(pq, (score, (solution, which_ik)))

            # print(theta_z / np.pi * 180)
            # if len(pq) > 0:
            # break
        if len(pq) == 0:
            return []
        priority, task = heapq.heappop(pq)
        return [task[0].copy()]

    def shortcut(self, traj_feasible, nb_subdivision_internal: int = 1):
        graph, graph_waypoints = ampl.graph_from_polyline(
            traj_feasible, nb_subdivision_internal
        )
        nb_node = len(graph_waypoints)
        for i in range(0, nb_node - (nb_subdivision_internal + 1)):
            for j in range(i + (nb_subdivision_internal + 1), nb_node, 3):
                if self.collision_free_trajectory(
                    graph_waypoints[i].copy(), graph_waypoints[j].copy(), 12, True, True
                ):
                    wij = np.linalg.norm(
                        graph_waypoints[j].copy() - graph_waypoints[i].copy()
                    )
                    graph[i].append((j, wij))

        new_path_len, new_path = ampl.graph_dijkstra_single(
            graph, nb_node, 0, nb_node - 1
        )
        return graph_waypoints[new_path].copy()


class HillbotRight(HillbotLeft):
    # def __init__(self, name="hillbot_left", dim=7):
    def __init__(self, name="hillbot_right", dim=7):
        super().__init__(name=name, dim=dim)
        self.wall = np.array([-100, -100, -100, 100, 100, 100], dtype=np.float32)
        self.arm_xyzr = []
        for _, v in DICT_PACKED_SPHERES.items():
            self.arm_xyzr.append(np.array(v, dtype=np.float32).reshape((-1, 4)))
        self.arm.set_collision_arm(self.arm_xyzr)
        self.rng = ampl.RNG7()
        self.rng.set_range(np.array(self.bounds[0]), np.array(self.bounds[1]))
        self.obb3_torso = create_obb3(OBB3_TORSO)
        self.tf_base_arm_base = TF44_HILLBOT_RIGHT_IN_BASE_LINK.copy()
        self.arm.set_base(self.tf_base_arm_base)
        self.which_iks = [5]
        self.q_ref = np.array(
            [
                6.187089960425906643e-01,
                1.530489328339613264e00,
                1.279188138351160742e00,
                -1.361644177777129316e00,
                -5.597590017009494989e-01,
                -1.074245838775617523e00,
                5.612031249999998028e-01,
            ]
        )
