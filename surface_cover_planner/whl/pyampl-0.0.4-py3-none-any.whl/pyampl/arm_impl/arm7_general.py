import ampl
import numpy as np


from ..arm import AgentArmConfig
from .collision_data_hillbot import OBB3_HILLBOT_TORSO_VLA as OBB3_TORSO
from .collision_data_hillbot import DICT_PACKED_SPHERES_HILLBOT_LEFT
from .collision_data_hillbot import (
    TF44_HILLBOT_LEFT_IN_BASE_LINK,
    # TF44_HILLBOT_LEFT_IN_BASE_LINK_TILT as TF44_HILLBOT_LEFT_IN_BASE_LINK,
)
from .collision_data_hillbot import TF44_HILLBOT_RIGHT_IN_BASE_LINK
from ..common import *


def create_single_arm_config(name: str = "franka_fr3", dim: int = 7) -> AgentArmConfig:
    config = AgentArmConfig()
    config.name = name
    config.dim = dim

    # print(name)

    if name == "franka_fr3":
        from .collision_data_franka_fr3 import (
            DICT_PACKED_SPHERES_FRANKA_FR3,
            OBB3_BASE_LINK_FRANKA_FR3,
        )

        config.default_obb3_torso = OBB3_BASE_LINK_FRANKA_FR3
        config.default_which_iks = [5]
        config.default_link_range = [2, 7]
        config.default_wall = np.array([-2, -2, -2, 2, 2, 2]).astype(DTypeFloat)
        config.default_base = np.array([0, 0, 0, 1, 0, 0, 0], dtype=DTypeDouble)
        for _, v in DICT_PACKED_SPHERES_FRANKA_FR3.items():
            config.default_arm_sph_xyzr.append(
                np.array(v, dtype=DTypeFloat).reshape((-1, 4))
            )
        config.default_state_ref = np.array(
            [0, 0, 0, -np.pi / 2, 0, np.pi / 2, 0], dtype=DTypeDouble
        )
    if name == "abb_irb6700_150_320":
        from .collision_data_arm6 import (
            DICT_PACKED_SPHERES_ABB_IRB6700_150_320,
            OBB3_BASE_LINK_ABB_IRB6700_150_320,
        )

        config.default_obb3_torso = OBB3_BASE_LINK_ABB_IRB6700_150_320
        config.default_which_iks = [2]
        config.default_link_range = [2, 6]
        config.default_wall = np.array([-2, -2, -1, 2, 2, 3]).astype(DTypeFloat)
        config.default_base = np.array([0, 0, 0, 1, 0, 0, 0], dtype=DTypeDouble)
        for _, v in DICT_PACKED_SPHERES_ABB_IRB6700_150_320.items():
            config.default_arm_sph_xyzr.append(
                np.array(v, dtype=DTypeFloat).reshape((-1, 4))
            )
        config.default_state_ref = np.array([0, 0, 0, 0, 0, 0], dtype=DTypeDouble)

    if name == "extern_tzrx":
        config.default_obb3_torso = OBB3_BASE_LINK_FRANKA_FR3
        config.default_which_iks = [0]
        config.default_link_range = [0, 2]
        config.default_wall = np.array([-2, -2, -2, 2, 2, 2]).astype(DTypeFloat)
        config.default_base = np.array([0, 0, 0, 1, 0, 0, 0], dtype=DTypeDouble)
        config.default_state_ref = np.array([0.15, 0.3], dtype=DTypeDouble)

    return config


def create_default_arm_config(
    name: str = "hillbot_left", dim: int = 7
) -> AgentArmConfig:
    config = AgentArmConfig()
    config.name = name
    config.dim = dim
    if name == "hillbot_left":
        config.default_obb3_torso = OBB3_TORSO
        config.default_which_iks = [5]  # [4, 5, 6, 7]
        config.default_link_range = [2, 7]
        config.default_wall = np.array([0.0, -0.3, 0.7, 100, 1.5, 2]).astype(DTypeFloat)
        config.default_base = ampl.tf44_to_qt7(
            np.array(TF44_HILLBOT_LEFT_IN_BASE_LINK, dtype=DTypeDouble)
        )
        for _, v in DICT_PACKED_SPHERES_HILLBOT_LEFT.items():
            config.default_arm_sph_xyzr.append(
                np.array(v, dtype=DTypeFloat).reshape((-1, 4))
            )
        config.default_state_ref = np.array([0.8, 0.64, 1.5, -1.65, -0.8, -0.8, 0.6])
    if name == "hillbot_right":
        config.default_obb3_torso = OBB3_TORSO
        config.default_which_iks = [4, 6]
        config.default_link_range = [2, 7]
        config.default_wall = np.array([0.0, -1.5, 0.7, 100, 0.3, 2]).astype(DTypeFloat)
        config.default_base = ampl.tf44_to_qt7(
            np.array(TF44_HILLBOT_RIGHT_IN_BASE_LINK, dtype=DTypeDouble)
        )
        for _, v in DICT_PACKED_SPHERES_HILLBOT_LEFT.items():
            config.default_arm_sph_xyzr.append(
                np.array(v, dtype=DTypeFloat).reshape((-1, 4))
            )
        config.default_state_ref = np.array([0.8, 0.64, 1.5, -1.65, -0.8, -0.8, 0.6])
    if name == "amal_left":
        from .collision_data_amal_left import DICT_PACKED_SPHERES_AMAL_LEFT

        config.default_obb3_torso = OBB3_TORSO
        config.default_which_iks = [5]  # [4, 5, 6, 7]
        config.default_link_range = [2, 7]
        config.default_wall = np.array([0.0, -0.3, 0.7, 100, 1.5, 2]).astype(DTypeFloat)
        config.default_base = ampl.tf44_to_qt7(
            np.array(TF44_HILLBOT_LEFT_IN_BASE_LINK, dtype=DTypeDouble)
        )
        for _, v in DICT_PACKED_SPHERES_AMAL_LEFT.items():
            config.default_arm_sph_xyzr.append(
                np.array(v, dtype=DTypeFloat).reshape((-1, 4))
            )
        config.default_state_ref = np.array([0.8, 0.64, 1.5, -1.65, -0.8, -0.8, 0.6])
    if name == "hillbot_realman":
        from .collision_data_hillbot_realman import DICT_PACKED_SPHERES_HILLBOT_REALMAN

        config.default_obb3_torso = OBB3_TORSO
        config.default_which_iks = [7]
        config.default_link_range = [3, 7]
        config.default_wall = np.array([0.0, -1.5, 0.7, 100, 0.3, 1.5]).astype(
            DTypeFloat
        )
        config.default_base = ampl.tf44_to_qt7(
            np.array(TF44_HILLBOT_RIGHT_IN_BASE_LINK, dtype=DTypeDouble)
        )
        for _, v in DICT_PACKED_SPHERES_HILLBOT_REALMAN.items():
            config.default_arm_sph_xyzr.append(
                np.array(v, dtype=DTypeFloat).reshape((-1, 4))
            )
        config.default_state_ref = np.array(
            [0.49899, 0.96952, -1.59919, -0.93890, -1.46816, -1.24153, 1.77852]
        )
    if name == "tianji_left":
        from .collision_data_tianji import (
            DICT_PACKED_SPHERES_TIANJI_LEFT,
            TF44_TIANJI_LEFT_IN_BASE_LINK,
            OBB3_TIANJI_TORSO,
        )

        config.default_obb3_torso = OBB3_TIANJI_TORSO
        config.default_which_iks = [6]  # [4, 5, 6, 7]
        config.default_link_range = [2, 7]
        config.default_wall = np.array([0.0, -0.3, -0.5, 100, 1.5, 1.5]).astype(
            DTypeFloat
        )
        config.default_base = ampl.tf44_to_qt7(
            np.array(TF44_TIANJI_LEFT_IN_BASE_LINK, dtype=DTypeDouble)
        )
        for _, v in DICT_PACKED_SPHERES_TIANJI_LEFT.items():
            config.default_arm_sph_xyzr.append(
                np.array(v, dtype=DTypeFloat).reshape((-1, 4))
            )
        config.default_state_ref = np.array(
            [
                0.8755427,
                -1.14451654,
                -1.38980156,
                -1.89217761,
                -0.46954548,
                0.75794405,
                -0.08590312,
            ]
        )
    if name == "tianji_right":
        from .collision_data_tianji import (
            DICT_PACKED_SPHERES_TIANJI_LEFT,
            TF44_TIANJI_RIGHT_IN_BASE_LINK,
            OBB3_TIANJI_TORSO,
        )

        config.default_obb3_torso = OBB3_TIANJI_TORSO
        config.default_which_iks = [5, 6, 7]  # [4, 5, 6, 7]
        config.default_link_range = [2, 7]
        config.default_wall = np.array([-2, -2, -2, 2, 2, 2]).astype(DTypeFloat)
        config.default_base = ampl.tf44_to_qt7(
            np.array(TF44_TIANJI_RIGHT_IN_BASE_LINK, dtype=DTypeDouble)
        )
        for _, v in DICT_PACKED_SPHERES_TIANJI_LEFT.items():
            config.default_arm_sph_xyzr.append(
                np.array(v, dtype=DTypeFloat).reshape((-1, 4))
            )
        config.default_state_ref = np.array(
            [
                0.8755427,
                -1.14451654,
                -1.38980156,
                -1.89217761,
                -0.46954548,
                0.75794405,
                -0.08590312,
            ]
        )
    if name == "openarm":
        from .collision_data_tianji import (
            # DICT_PACKED_SPHERES_TIANJI_LEFT,
            TF44_TIANJI_LEFT_IN_BASE_LINK,
            OBB3_TIANJI_TORSO,
        )
        from .collision_data_openarm import DICT_PACKED_SPHERES_OPENARM

        config.default_obb3_torso = OBB3_TIANJI_TORSO
        config.default_which_iks = [4]  # [4, 5, 6, 7]
        config.default_link_range = [2, 7]
        config.default_wall = np.array([0.0, -0.3, -0.5, 100, 1.5, 1.5]).astype(
            DTypeFloat
        )
        config.default_base = ampl.tf44_to_qt7(
            np.array(TF44_TIANJI_LEFT_IN_BASE_LINK, dtype=DTypeDouble)
        )
        for _, v in DICT_PACKED_SPHERES_OPENARM.items():
            config.default_arm_sph_xyzr.append(
                0.001 * np.array(v, dtype=DTypeFloat).reshape((-1, 4))
            )
        config.default_state_ref = np.array(
            [
                1.66294098,
                -0.21498725,
                -0.82551791,
                1.61166388,
                0.30750592,
                0.15685449,
                -0.35588354,
            ]
        )

    return config


# class HillbotLeft(AgentArm):
#     def __init__(self):
#         super().__init__(name="hillbot_left", dim=7)
