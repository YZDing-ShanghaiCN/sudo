import numpy as np
import ampl
from .collision import CollisionScene
from typing import Dict
from .common import EPS_CONVEX_COLLISION


def convex_scene_make_collision_free(scene: CollisionScene, pose_sample_fun):
    names = [key for key in scene.cvhs.keys()]
    rwt_rnd = pose_sample_fun()
    scene.update_pose(names[0], rwt_rnd)
    names_left = names[1:]
    names_added = [names[0]]
    while len(names_left) > 0:
        keep_sample = True
        name_curr = names_left[0]
        while keep_sample:
            rwt_rnd = pose_sample_fun()
            scene.update_pose(name_curr, rwt_rnd)
            keep_sample = False
            for name_added in names_added:
                ret = ampl.collision_check_vcvh_vcvh(
                    scene.cvhs[name_curr].entity_move,
                    scene.cvhs[name_added].entity_move,
                )

                keep_sample = ret < EPS_CONVEX_COLLISION
                if keep_sample:
                    break
        names_left.pop(0)
        names_added.append(name_curr)


def convex_scene_generate_container_from_sequence(
    scene: CollisionScene,
    rwt_base: np.ndarray,
    pose_sample_fun,
    name_container: str = "basket",
    name_sequence_item: list[str] = [],
    nb_max_samples: int = 100,
):
    if name_container not in scene.cvhs.keys():
        return None

    names_added = [name_container]
    names_left = []
    for name_to_be_add in name_sequence_item:
        if (name_to_be_add) in scene.cvhs.keys():
            names_left.append(name_to_be_add)
    scene.update_pose(name_container, rwt_base)
    nb_samples_try = 0
    plane_first = next(iter(scene.planes.values()))
    
    while len(names_left) > 0:
        if nb_samples_try > nb_max_samples:
            break
        keep_sample = True
        name_curr = names_left[0]
        while keep_sample:
            rwt_rnd = pose_sample_fun()
            rwt_rnd = np.array(ampl.rwtmul(rwt_base, rwt_rnd))
            scene.update_pose(name_curr, rwt_rnd)
            keep_sample = False
            nb_samples_try += 1
            for name_added in names_added:
                ret = ampl.collision_check_plane_vcvh(
                    plane_first.entity_move,
                    scene.cvhs[name_curr].entity_move, 
                )
                keep_sample = ret < EPS_CONVEX_COLLISION
                if keep_sample:
                    break
                ret = ampl.collision_check_vcvh_vcvh(
                    scene.cvhs[name_curr].entity_move,
                    scene.cvhs[name_added].entity_move,
                )
                keep_sample = ret < EPS_CONVEX_COLLISION
                if keep_sample:
                    break
        names_left.pop(0)
        names_added.append(name_curr)
    return names_added


def convex_scene_slice_pose(
    scene: CollisionScene,
    pose_format: str = "rwt7",
    names: list[str] = [],
    dtype=np.float32,
) -> Dict[str, np.ndarray]:
    dict_pose = {}

    names_all = scene.cvhs.keys()
    names_slice = []
    if len(names) > 0:
        for name in names:
            if name in names_all:
                names_slice.append(name)
    else:
        names_slice = names_all
    if pose_format == "rwt7":
        for name in names_slice:
            dict_pose[name] = scene.cvhs[name].pose.astype(dtype)
    if pose_format == "wxyz4t3":
        for name in names_slice:
            co = scene.cvhs[name]
            dict_pose[name] = (
                co.pose[[3, 0, 1, 2]].astype(dtype),
                co.pose[-3:].astype(dtype),
            )
    if pose_format == "tf44":
        for name in names_slice:
            co = scene.cvhs[name]
            dict_pose[name] = ampl.qt7_to_tf44(co.pose.astype(np.float64)).astype(dtype)
    return dict_pose
