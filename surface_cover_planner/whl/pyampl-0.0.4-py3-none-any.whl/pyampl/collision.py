import numpy as np
import ampl
from typing import Dict
from .common import *
from .util import pointcloud_from_mesh, convex_from_mesh, EPS_CONVEX_COLLISION


class CollisionObjectBase:
    def __init__(self):
        self.entity = None
        self.entity_move = None
        self._pose = np.array([0, 0, 0, 1, 0, 0, 0], dtype=DTypeFloat)
        self.active = False

    def update_parameter(self):
        return

    @property
    def pose(self):
        return self._pose

    @pose.setter
    def pose(self, rwt: np.ndarray):
        np.copyto(dst=self._pose, src=rwt)


class CollisionObjectPlane(CollisionObjectBase):
    def __init__(
        self,
        center: DTypeVertices = np.array([0, 0, 0], dtype=DTypeFloat),
        normal: DTypeVertices = np.array([0, 0, 1], dtype=DTypeFloat),
    ):
        super().__init__()
        self.entity = ampl.Plane3()

        ampl.collision_initialize_object(
            plane_center=center.astype(DTypeFloat),
            plane_normal=normal.astype(DTypeFloat),
            plane_obj=self.entity,
            extent_consider_large=10.0,
        )
        self.entity_move = ampl.Plane3(self.entity)

    # plane
    # ampl.collision_initialize_object(self.entity,)

    def update_parameter(self, center: DTypeVertices, normal: DTypeVertices):
        ampl.collision_initialize_object(
            plane_center=center.astype(DTypeFloat),
            plane_normal=normal.astype(DTypeFloat),
            plane_obj=self.entity,
            extent_consider_large=10.0,
        )
        self.entity_move = ampl.Plane3(self.entity)
        return

    @property
    def pose(self):
        return super().pose

    @pose.setter
    def pose(self, rwt: np.ndarray):
        np.copyto(dst=self._pose, src=rwt)
        # ampl.collision_transform_object(self.entity, self.entity_move, self._pose)


class CollisionObjectConvex(CollisionObjectBase):
    def __init__(self, convex: DTypeConvex):
        super().__init__()
        self.entity = convex_from_mesh(convex)
        self.entity_move = ampl.VCvhf(self.entity)

    def update_parameter(self, convex: DTypeConvex):
        self.entity = convex_from_mesh(convex)
        self.entity_move = ampl.VCvhf(self.entity)
        return

    @property
    def pose(self):
        return super().pose

    @pose.setter
    def pose(self, rwt: np.ndarray):
        np.copyto(dst=self._pose, src=rwt)
        ampl.collision_transform_object(self.entity, self.entity_move, self._pose)


class CollisionObjectPointcloud(CollisionObjectBase):
    def __init__(self, convex: DTypeConvex, dx: float = 2e-3):
        super().__init__()
        self.entity = pointcloud_from_mesh(convex, dx=dx)
        self.entity_move = np.zeros_like(self.entity)
        np.copyto(src=self.entity, dst=self.entity_move)

    def update_parameter(self, convex: DTypeConvex, dx: float):
        self.entity = pointcloud_from_mesh(convex, dx=dx)
        self.entity_move = np.zeros_like(self.entity)
        np.copyto(src=self.entity, dst=self.entity_move)
        return

    @property
    def pose(self):
        return super().pose

    @pose.setter
    def pose(self, rwt: np.ndarray):
        np.copyto(dst=self._pose, src=rwt)
        ampl.transform_xyz(self.entity, self.entity_move, self._pose)


class CollisionScene(CollisionSceneBase):
    def __init__(self):
        super().__init__()
        self.cvhs: Dict[str, CollisionObjectConvex] = {}
        self.pcds: Dict[str, CollisionObjectPointcloud] = {}
        self.df = ampl.DistanceField()
        self.planes: Dict[str, CollisionObjectPlane] = {}

    def insert_convex(
        self,
        name: str,
        convex: DTypeConvex,
        create_pcd: bool = False,
        pcd_dx: float = 2e-3,
    ):
        self.cvhs[name] = CollisionObjectConvex(convex)
        if create_pcd:
            self.pcds[name] = CollisionObjectPointcloud(convex, pcd_dx)

    def insert_plane(self, name: str, center: DTypeVertices, normal: DTypeVertices):
        self.planes[name] = CollisionObjectPlane(center, normal)

    def remove_convex(self, name: str):
        if name in self.cvhs:
            del self.cvhs[name]
        if name in self.pcds:
            del self.pcds[name]

    def remove_plane(self, name: str):
        if name in self.planes:
            del self.planes[name]

    def update_pose(self, name: str, rwt: np.ndarray) -> bool:
        if name in self.cvhs:
            self.cvhs[name].pose = rwt
            return True
        return False

    def update_poses_pcd_from_convex(self):
        for name in self.cvhs.keys():

            if name in self.pcds:
                # print("update_pose", name, self.cvhs[name].pose)
                self.pcds[name].pose = self.cvhs[name].pose

    def get_pointcloud(self, names: list[str] = []) -> np.ndarray:
        xyzs = []
        names_all = self.cvhs.keys()
        names_slice = []
        if len(names) > 0:
            for name in names:
                if name in names_all:
                    names_slice.append(name)
        else:
            names_slice = names_all
        for name in names_slice:
            xyzs.append(self.pcds[name].entity_move)
        return np.vstack(xyzs, dtype=DTypeFloat)

    def enable_collision(self, name: str, status: bool = True):
        if name in self.cvhs:
            self.cvhs[name].active = status
        if name in self.pcds:
            self.pcds[name].active = status

    def collision_free_external(
        self, external: CollisionObjectConvex, rwts: np.ndarray
    ) -> np.ndarray:
        cvhs = self.cvhs.values()
        planes = self.planes.values()
        mask = [True] * len(rwts)
        for i, rwt in enumerate(rwts):
            external.pose = rwt
            is_collision_free = True
            for plane in planes:
                # print("plane", plane.entity.center)
                ret = ampl.collision_check_plane_vcvh(
                    plane.entity,
                    external.entity_move,
                )
                if ret < EPS_CONVEX_COLLISION:
                    mask[i] = False
                    is_collision_free = False

                    break
            if not is_collision_free:
                break
            for cvh in cvhs:
                if not cvh.active:
                    continue
                ret = ampl.collision_check_vcvh_vcvh(
                    external.entity_move, cvh.entity_move
                )
                # print("ret", ret)
                # if 1:
                #     wa = np.array([0, 0, 0], dtype=np.float32)
                #     wb = np.array([0, 0, 0], dtype=np.float32)
                #     dist = ampl.collision_distance_vcvh_vcvh(
                #         external.entity_move, cvh.entity_move, wa, wb
                #     )
                #     #print(dist)

                # else:
                #     mask[i] = False
                if ret < EPS_CONVEX_COLLISION * 1.5:
                    mask[i] = False
                    break
        return mask

    def update_df_from_pcd(
        self,
        xyz_world: np.ndarray,
        xyz_min: np.ndarray = None,
        xyz_max: np.ndarray = None,
        side=2.5e-3,
        voxel_padding: int = 4,
    ):
        corner_min = np.min(xyz_world, axis=0) if xyz_min is None else xyz_min
        corner_max = np.max(xyz_world, axis=0) if xyz_max is None else xyz_max
        corner_min[2] -= side * voxel_padding
        corner_max[2] += side * voxel_padding
        shape = np.array((corner_max - corner_min) / side, dtype=DTypeIndex)
        self.df.clear()
        self.df.origin = corner_min.tolist()
        self.df.shape = shape.tolist()
        self.df.side = side
        self.df.allocate_buffer()
        ampl.collision_initialize_object(xyz_world, self.df, 4)

    def __str__(self):
        return "{" + ", ".join([key for key in self.cvhs.keys()]) + "}"
