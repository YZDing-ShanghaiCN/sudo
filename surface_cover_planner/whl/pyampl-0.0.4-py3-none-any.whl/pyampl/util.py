import numpy as np
import ampl
from typing import Tuple, Union, List
from .common import *
import time
from contextlib import contextmanager

import time


@contextmanager
def tictoc(comment: str = ""):
    start = time.perf_counter()
    try:
        yield
    finally:
        end = time.perf_counter()
        duration = end - start
        print(f"# [TIMER] CODE BLOCK = {duration:.4f} SECONDS BY {comment}")


def get_traj_length_from_waypoints(path: np.ndarray):
    return np.linalg.norm(path[:-1] - path[1:], axis=1).sum()


def find_smoothest_path(grid: np.ndarray, grid_q: np.ndarray, lp_norm: int = 1):
    rows, cols = len(grid), len(grid[0])
    prev_dp = np.full((cols, cols), np.inf)
    all_parents = []
    for c_prev in range(cols):
        if grid[0, c_prev] == 1:
            for c_curr in range(cols):
                if grid[1, c_curr] == 1 and abs(c_curr - c_prev) <= 1:
                    prev_dp[c_prev, c_curr] = 0  # 初始代价为0

    if lp_norm == 1:
        for r in range(2, rows):
            curr_dp = np.full((cols, cols), np.inf)
            parent_r = [[None for _ in range(cols)] for _ in range(cols)]
            for c_last in range(cols):
                if grid[r - 1, c_last] == 1:
                    for c_curr in range(max(0, c_last - 1), min(cols, c_last + 2)):
                        if grid[r, c_curr] == 1:
                            min_cost = float("inf")
                            best_c_prev_prev = None
                            for c_prev_prev in range(
                                max(0, c_last - 1), min(cols, c_last + 2)
                            ):
                                if grid[r - 2, c_prev_prev] == 1:
                                    if prev_dp[c_prev_prev, c_last] != np.inf:
                                        cost = prev_dp[c_prev_prev, c_last]
                                        cost += np.linalg.norm(
                                            2 * grid_q[r - 1, c_last, :]
                                            - grid_q[r, c_curr, :]
                                            - grid_q[r - 2, c_prev_prev, :]
                                        )
                                        cost += np.linalg.norm(
                                            (
                                                grid_q[r, c_curr, :]
                                                - grid_q[r - 1, c_last, :]
                                            )
                                        )
                                        if cost < min_cost:
                                            min_cost = cost
                                            best_c_prev_prev = c_prev_prev
                            if min_cost != np.inf:
                                curr_dp[c_last, c_curr] = min_cost
                                parent_r[c_last][c_curr] = best_c_prev_prev
            prev_dp = curr_dp
            all_parents.append(parent_r)
    elif lp_norm == 2:
        for r in range(2, rows):
            curr_dp = np.full((cols, cols), np.inf)
            parent_r = [[None for _ in range(cols)] for _ in range(cols)]
            for c_last in range(cols):
                if grid[r - 1, c_last] == 1:
                    for c_curr in range(max(0, c_last - 1), min(cols, c_last + 2)):
                        if grid[r, c_curr] == 1:
                            min_cost = float("inf")
                            best_c_prev_prev = None
                            for c_prev_prev in range(
                                max(0, c_last - 1), min(cols, c_last + 2)
                            ):
                                if grid[r - 2, c_prev_prev] == 1:
                                    if prev_dp[c_prev_prev, c_last] != np.inf:
                                        cost = prev_dp[c_prev_prev, c_last]
                                        cost += (
                                            np.linalg.norm(
                                                2 * grid_q[r - 1, c_last, :]
                                                - grid_q[r, c_curr, :]
                                                - grid_q[r - 2, c_prev_prev, :]
                                            )
                                            ** 2
                                        )
                                        cost += (
                                            np.linalg.norm(
                                                (
                                                    grid_q[r, c_curr, :]
                                                    - grid_q[r - 1, c_last, :]
                                                )
                                            )
                                            ** 2
                                        )
                                        if cost < min_cost:
                                            min_cost = cost
                                            best_c_prev_prev = c_prev_prev
                            if min_cost != np.inf:
                                curr_dp[c_last, c_curr] = min_cost
                                parent_r[c_last][c_curr] = best_c_prev_prev
            prev_dp = curr_dp
            all_parents.append(parent_r)

    min_cost = np.min(prev_dp)
    if min_cost == np.inf:
        return None
    c_last_end, c_curr_end = np.unravel_index(np.argmin(prev_dp), prev_dp.shape)
    path = [(rows - 1, c_curr_end), (rows - 2, c_last_end)]
    last_c, curr_c = c_last_end, c_curr_end
    for r in range(rows - 1, 1, -1):
        parent_r = all_parents[r - 2]
        prev_prev_c = parent_r[last_c][curr_c]

        if prev_prev_c is None:
            return None
        path.append((r - 2, prev_prev_c))
        curr_c = last_c
        last_c = prev_prev_c

    path.reverse()
    return path


def connected_components_1d(mask):
    components = []
    start_index = -1

    for i in range(len(mask)):
        if mask[i] == 1:
            if start_index == -1:  # Start of a new component
                start_index = i
        elif mask[i] == 0 and start_index != -1:  # End of a component
            components.append((start_index, i))
            start_index = -1
    if start_index != -1:
        components.append((start_index, len(mask)))
    return components


def find_minimal_deviation_path(
    grid: np.ndarray, grid_q: np.ndarray, max_col_neighbour: int = 1
):
    rows, cols = len(grid), len(grid[0])
    dp = np.zeros_like(grid, dtype=np.float32)
    dp[:, :] = float("inf")
    parent = [[None] * cols for _ in range(rows)]
    for c in range(cols):
        if grid[0, c] == 1:
            dp[0, c] = 0
    N = max_col_neighbour
    for r in range(1, rows):
        for c in range(cols):
            if grid[r, c] == 1:
                prev_points = [c - N, c, c + N]
                for pc in prev_points:
                    if 0 <= pc < cols and grid[r - 1, pc] == 1:
                        cost_move = np.linalg.norm(
                            grid_q[r - 1, pc, :-1] - grid_q[r, c, :-1]
                        )  # abs(c - pc)
                        # if r>1:
                        #     np.linalg.norm((grid_q[r-1,pc,:-1]-grid_q[r,c,:-1])-(grid_q[r-1,pc,:-1]-grid_q[r,c,:-1]))

                        # if  (grid_q[r-1,pc,:-1]-grid_q[r,c,:-1])
                        cost = dp[r - 1, pc] + cost_move
                        if cost < dp[r, c]:
                            dp[r, c] = cost
                            parent[r][c] = (r - 1, pc)
    min_cost = float("inf")
    end_point = None
    for c in range(cols):
        if grid[rows - 1, c] == 1 and dp[rows - 1, c] < min_cost:
            min_cost = dp[rows - 1, c]
            end_point = (rows - 1, c)
    if end_point is None:
        return None
    path = []
    current = end_point
    while current:
        path.append(current)
        current = parent[current[0]][current[1]]
    path.reverse()
    return path


def crop_pcd(
    pcd: np.ndarray,
    x_min=None,
    y_min=None,
    z_min=None,
    x_max=None,
    y_max=None,
    z_max=None,
):
    xyz_min = np.array([-100000, -100000, -100000], dtype=pcd.dtype)
    xyz_max = np.array([100000, 100000, 100000], dtype=pcd.dtype)
    mask = np.ones(len(pcd), dtype=bool)
    if x_min is not None:
        mask = mask & (pcd[:, 0] > x_min)
        xyz_min[0] = x_min
    if y_min is not None:
        mask = mask & (pcd[:, 1] > y_min)
        xyz_min[1] = y_min
    if z_min is not None:
        mask = mask & (pcd[:, 2] > z_min)
        xyz_min[2] = z_min
    if x_max is not None:
        mask = mask & (pcd[:, 0] < x_max)
        xyz_max[0] = x_max
    if y_max is not None:
        mask = mask & (pcd[:, 1] < y_max)
        xyz_max[1] = y_max
    if z_max is not None:
        mask = mask & (pcd[:, 2] < z_max)
        xyz_max[2] = z_max

    return mask, xyz_min, xyz_max


def refine_trajectory_trivial(traj_shortcut: DTypeState, nb_refine: int = 64):
    return ampl.sample_polyline_uniform(traj_shortcut, nb_refine).copy()


def sample_trajectory_trivial(
    q_start: np.array,
    q_end: np.array,
    n: int = 5,
    include_start=False,
    inclue_end=True,
) -> np.array:
    return np.linspace(q_start, q_end, n + 2, endpoint=True)[
        not include_start : n + 2 - (not inclue_end)
    ]


def convex_from_mesh(vf: DTypeConvex) -> ampl.VCvhf:
    if isinstance(vf, Tuple):
        v = vf[0]
        f = vf[1]
        fccs = ampl.trimesh_connected_components(f.astype(np.uint32))
        vs = [
            v[np.unique(f[fcc].flatten())].astype(np.float32)
            for _, fcc in enumerate(fccs)
        ]
    elif isinstance(vf, List):
        vs = [v.astype(np.float32) for v in vf]
    else:
        return None
    cvh = ampl.VCvhf()
    ampl.collision_initialize_object(vs, cvh)
    return cvh


def pointcloud_from_mesh(vf: DTypeVerticesFaces, dx: float = 2e-3) -> DTypeVertices:
    if isinstance(vf, Tuple):
        v = vf[0]
        f = vf[1]
        xyz = ampl.trimesh_sampler_barycentricysplit(
            v.astype(np.float32), f.astype(np.uint32), 1, sample_distance_expect=dx
        )
        return xyz
    elif isinstance(vf, List):
        xyzs = []
        for v in vf:
            v_cvh, f_cvh = ampl.trimesh_convexhull(v.astype(np.float32))
            xyz_cvh = xyz = ampl.trimesh_sampler_barycentricysplit(
                v_cvh, f_cvh, 1, sample_distance_expect=dx
            )
            xyzs.append(xyz_cvh)
        return np.vstack(xyzs, dtype=np.float32)
    return None


def rwtmul(rwt1, rwt2):
    return ampl.tf44_to_qt7(ampl.qt7_to_tf44(rwt1) @ ampl.qt7_to_tf44(rwt2))


def create_obb3(
    center: np.array, half_extents: np.array, u: np.array, v: np.array, w: np.array
) -> ampl.OBB3:
    obb3 = ampl.OBB3()
    obb3.center = [center[0], center[1], center[2]]
    obb3.half_extents = [half_extents[0], half_extents[1], half_extents[2]]
    obb3.u = [u[0], u[1], u[2]]
    obb3.v = [v[0], v[1], v[2]]
    obb3.w = [w[0], w[1], w[2]]
    return obb3


def create_obb3(dict_obb3: dict) -> ampl.OBB3:
    obb3 = ampl.OBB3()
    obb3.center = dict_obb3["center"]
    obb3.half_extents = dict_obb3["half_extents"]
    obb3.u = dict_obb3["u"]
    obb3.v = dict_obb3["v"]
    obb3.w = dict_obb3["w"]
    return obb3


def visualize_df(df: ampl.DistanceField):
    v, f = ampl.collision_visualize_object(df, df.side * 2)
    return v, f


def tic(print_cmd: bool = False, message: str = ""):
    global timer_global
    timer_global = time.perf_counter_ns()
    if print_cmd:
        print(f"# TIC {message}")


def toc(print_cmd: bool = True, message: str = ""):
    global timer_global
    delta = (float(time.perf_counter_ns()) - timer_global) / 1e6
    if print_cmd:
        print(f"# TOC = {delta} MS BY {message}")
    return delta


if __name__ == "__main__":
    vf = ampl.read_trimesh("/home/czhou/Data/arm/convex/01/basket.ply")
    xyz = pointcloud_from_mesh(vf)
    ampl.write_pointcloud("/home/czhou/Data/arm/convex/01/basket_xyz.ply", xyz)

    v = vf[0]
    f = vf[1]
    fccs = ampl.trimesh_connected_components(f.astype(np.uint32))
    vs = [
        v[np.unique(f[fcc].flatten())].astype(np.float32) for _, fcc in enumerate(fccs)
    ]
    xyz_ = pointcloud_from_mesh(vs, 1e-2)
    ampl.write_pointcloud("/home/czhou/Data/arm/convex/01/basket_xyz_.ply", xyz_)
