import numpy as np
import ampl
from typing import Tuple, Union, List
from .common import *
from .common import AgentBase
from .collision import CollisionScene, CollisionObjectConvex
from .util import (
    sample_trajectory_trivial,
    convex_from_mesh,
    connected_components_1d,
    find_minimal_deviation_path,
    find_smoothest_path,
)


class WrapperArm7:
    def __init__(self, name: str, dof: int):
        self.dof = dof
        self.q8 = np.zeros((8, dof), dtype=np.float64)
        self.qtLink: np.ndarray = np.zeros((dof + 1, 7), dtype=np.float64)
        if "left" in name or "right" in name or "openarm" in name or "realman" in name:
            self.solver = ampl.ArmBase(name, ampl.ArmType.Humanoid7, dof)
        elif "franka" in name:
            self.solver = ampl.ArmBase(name, ampl.ArmType.FR7, dof)
        self.sphs = ampl.VSphG8f()
        self.sphs_mov = ampl.VSphG8f()
        self.bounds = self.solver.joint_limits()
        self.cvh_tool = None
        self.cvh_tool_mov = None

    def set_base(self, tf):
        self.solver.set_base(tf)

    def set_collision_arm(self, xyzr: List[np.ndarray]):
        offset = [len(a) for a in xyzr]
        xyzr = np.vstack(xyzr)
        offset = np.array(offset, dtype=np.uint32)
        ampl.collision_initialize_object(xyzr, offset, self.sphs)
        ampl.collision_initialize_object(xyzr, offset, self.sphs_mov)

    def set_collision_tool(
        self, convex: Union[Tuple[np.ndarray, np.ndarray], List[np.ndarray]]
    ):
        self.cvh_tool = convex_from_mesh(convex)
        if self.cvh_tool is not None:
            self.cvh_tool_mov = ampl.VCvhf(self.cvh_tool)

    def visualize_state(self, q: np.ndarray) -> DTypeVerticesFaces:
        self.solver.fk_links(q, self.qtLink)
        for iq, rwt in enumerate(self.qtLink):
            ampl.collision_transform_object(self.sphs, self.sphs_mov, iq, rwt)
        V_sph_fk, F_sph_fk = ampl.collision_visualize_object(self.sphs_mov, 128)
        return V_sph_fk, F_sph_fk


class WrapperArm6:
    def __init__(self, name: str, arm_type: ampl.ArmType, dof: int = 6):
        self.dof = dof
        self.q8 = np.zeros((8, dof), dtype=np.float64)
        self.qtLink = np.zeros((dof + 1, 7), dtype=np.float64)
        self.solver = ampl.ArmBase(name, arm_type, dof)
        self.sphs = ampl.VSphG8f()
        self.sphs_mov = ampl.VSphG8f()
        self.bounds = self.solver.joint_limits()
        self.cvh_tool = None
        self.cvh_tool_mov = None

    def set_base(self, tf):
        self.solver.set_base(tf)

    def set_collision_arm(self, xyzr: List[np.ndarray]):
        offset = [len(a) for a in xyzr]
        xyzr = np.vstack(xyzr)
        offset = np.array(offset, dtype=np.uint32)
        ampl.collision_initialize_object(xyzr, offset, self.sphs)
        ampl.collision_initialize_object(xyzr, offset, self.sphs_mov)

    def set_collision_tool(
        self, convex: Union[Tuple[np.ndarray, np.ndarray], List[np.ndarray]]
    ):
        self.cvh_tool = convex_from_mesh(convex)
        if self.cvh_tool is not None:
            self.cvh_tool_mov = ampl.VCvhf(self.cvh_tool)

    def visualize_state(self, q: np.ndarray) -> DTypeVerticesFaces:
        self.solver.fk_links(q, self.qtLink)
        for iq, rwt in enumerate(self.qtLink):
            ampl.collision_transform_object(self.sphs, self.sphs_mov, iq, rwt)
        V_sph_fk, F_sph_fk = ampl.collision_visualize_object(self.sphs_mov, 128)
        return V_sph_fk, F_sph_fk


class WrapperExtern2:
    def __init__(self, name: str, dof: int = 2):
        self.dof = dof
        self.q8 = np.zeros((2, dof), dtype=np.float64)
        self.nb_tcp: int = 2
        self.qtLink = np.zeros((dof + self.nb_tcp, 7), dtype=np.float64)
        self.solver = ampl.ArmBase(name, ampl.ArmType.Extern_TZRX, dof)
        self.bounds = self.solver.joint_limits()

    def set_base(self, tf):
        self.solver.set_base(tf)

    # def set_collision_arm(self, xyzr: List[np.ndarray]):
    #     offset = [len(a) for a in xyzr]
    #     xyzr = np.vstack(xyzr)
    #     offset = np.array(offset, dtype=np.uint32)
    #     ampl.collision_initialize_object(xyzr, offset, self.sphs)
    #     ampl.collision_initialize_object(xyzr, offset, self.sphs_mov)


class AgentArmConfig:
    def __init__(self):
        self.name: str = ""
        self.dim: int = 0
        self.default_obb3_torso: dict = {}
        self.default_which_iks: list = []
        self.default_arm_sph_xyzr: List[np.ndarray] = []
        self.default_base = np.ndarray
        self.default_wall: np.ndarray = None
        self.default_link_range = []
        self.default_state_ref: DTypeState = None


class AgentArm(AgentBase):
    def __init__(
        self,
        name: str = "hillbot_left",
        dim: int = 7,
        default_config: AgentArmConfig = None,
    ):
        super().__init__()

        self._name = name
        self._pose_base = np.array([0, 0, 0, 1, 0, 0, 0], dtype=DTypeDouble)
        self._arm = None
        self._wall = np.array([0.0, -0.3, 0.7, 100, 1.5, 1.4], dtype=DTypeFloat)
        self._state_sample = np.array([0] * dim, dtype=DTypeDouble)
        self._state_ref = np.array([0] * dim, dtype=DTypeDouble)
        self._which_iks = [4, 5, 6, 7]
        self._obb3_torso: ampl.OBB3 = ampl.OBB3()
        self._link_range: List[int] = [2, dim]
        self._iq_redundant = -1
        self._q_min_max_redundant = None
        self._state_bounds = None
        self._dim = dim

        self._cvh_attach: CollisionObjectConvex = None
        self._pose_attach: np.ndarray = np.array(
            [0, 0, 0, 1, 0, 0, 0], dtype=DTypeFloat
        )

        if dim == 7:
            if "tianji" in self.name:
                self._arm = WrapperArm7("tianji_left", 7)
            else:
                self._arm = WrapperArm7(self.name, 7)
            self._rng = ampl.RNG7()
            self._iq_redundant = 6
            if self._arm is not None:
                self._state_bounds = self._arm.bounds
                self.bounds = (
                    self._arm.bounds
                )  # TODO: THIS IS ONLY FOR BACKWARD COMPATIBILITY
            if self.joint_limits is not None:
                self._q_min_max_redundant = [
                    self.joint_limits[0][self.iq_redundant],
                    self.joint_limits[1][self.iq_redundant],
                ]
        if dim == 6:
            self._arm = WrapperArm6(self.name, ampl.ArmType.Industrial6, 6)
            self._rng = ampl.RNG6()
            self._iq_redundant = -1
            if self._arm is not None:
                self._state_bounds = self._arm.bounds
                self.bounds = (
                    self._arm.bounds
                )  # TODO: THIS IS ONLY FOR BACKWARD COMPATIBILITY\
        if dim == 2:
            self._arm = WrapperExtern2(self.name, 2)
            self._iq_redundant = -1
            if self._arm is not None:
                self._state_bounds = self._arm.bounds
                self.bounds = (
                    self._arm.bounds
                )  # TODO: THIS IS ONLY FOR BACKWARD COMPATIBILITY
        if default_config is not None:
            self.obb3_torso = default_config.default_obb3_torso
            self.which_iks = default_config.default_which_iks
            self.wall = default_config.default_wall
            self.link_range = default_config.default_link_range
            self.pose_base = default_config.default_base
            self.state_ref = default_config.default_state_ref
            if len(default_config.default_arm_sph_xyzr) >= self.dim:
                self._arm.set_collision_arm(default_config.default_arm_sph_xyzr)

    @property
    def name(self):
        return self._name

    @property
    def dof(self):
        return self._arm.dof

    @property
    def dim(self):
        return self._dim

    @dim.setter
    def dim(self, dim_set: int):
        self._dim = dim_set

    @property
    def joint_limits(self):
        return self._state_bounds

    @property
    def iq_redundant(self):
        return self._iq_redundant

    @property
    def range_redundant(self):
        return self._q_min_max_redundant

    @property
    def pose_base(self):
        return self._pose_base

    @pose_base.setter
    def pose_base(self, rwt: np.ndarray):
        np.copyto(dst=self._pose_base, src=rwt)
        self._arm.set_base(ampl.qt7_to_tf44(self.pose_base))

    @property
    def wall(self):
        return self._wall

    @wall.setter
    def wall(self, wall_in_base: np.ndarray):
        np.copyto(dst=self._wall, src=wall_in_base)

    @property
    def cvh_attach(self):
        return self._cvh_attach

    @cvh_attach.setter
    def cvh_attach(self, cvh: CollisionObjectConvex):
        self._cvh_attach = cvh

    @property
    def pose_attach(self) -> np.ndarray:
        return self._pose_attach

    @pose_attach.setter
    def pose_attach(
        self,
        rwt_tcp_cvh: np.ndarray = np.array([0, 0, 0, 1, 0, 0, 0], dtype=np.float32),
    ):
        np.copyto(dst=self._pose_attach, src=rwt_tcp_cvh)

    @property
    def state_ref(self):
        return self._state_ref

    @state_ref.setter
    def state_ref(self, state_ref: DTypeState):
        np.copyto(dst=self._state_ref, src=state_ref)

    @property
    def which_iks(self):
        return self._which_iks

    @which_iks.setter
    def which_iks(self, list_of_indices: List[int]):
        self._which_iks = list_of_indices

    @property
    def link_range(self):
        return self._link_range

    @link_range.setter
    def link_range(self, min_and_max_inclusive: List[int]):
        self._link_range[0] = int(min_and_max_inclusive[0])
        self._link_range[1] = int(min_and_max_inclusive[1])

    @property
    def obb3_torso(self) -> dict:
        if self._obb3_torso is not None:
            return {
                "center": self._obb3_torso.center,
                "half_extents": self._obb3_torso.half_extents,
                "u": self._obb3_torso.u,
                "v": self._obb3_torso.v,
                "w": self._obb3_torso.w,
            }
        else:
            return {}

    @obb3_torso.setter
    def obb3_torso(self, dict_obb3: dict):
        self._obb3_torso.center = dict_obb3["center"]
        self._obb3_torso.half_extents = dict_obb3["half_extents"]
        self._obb3_torso.u = dict_obb3["u"]
        self._obb3_torso.v = dict_obb3["v"]
        self._obb3_torso.w = dict_obb3["w"]

    @property
    def fk_rwt(self):
        return self._arm.qtLink

    @fk_rwt.setter
    def fk_rwt(self, state: DTypeState):
        self._arm.solver.fk_links(state.astype(DTypeDouble), self._arm.qtLink)

    def validate(self):
        print("# [VALIDATE ARM] NAME ".ljust(60, "#"))
        print(self.name)
        print("# [VALIDATE ARM] SPHERE LOADED ".ljust(60, "#"))
        print(self._arm.sphs.nb_offset)
        print(self._arm.sphs.nb_sph)
        print("# [VALIDATE ARM] TORSO OBB ".ljust(60, "#"))
        for item, amount in self.obb3_torso.items():
            print(f" - {item}: {amount}")
        # print(self.obb3_torso)
        print("# [VALIDATE ARM] WHICH IK ".ljust(60, "#"))
        print(self.which_iks)
        print("# [VALIDATE ARM] WALL ".ljust(60, "#"))
        print(self.wall)
        print("# [VALIDATE ARM] LINK RANGE FOR COLLISION (0-INDEX) ".ljust(60, "#"))
        print(self.link_range)
        print("# [VALIDATE ARM] JOINT LIMITS ".ljust(60, "#"))
        print(self.joint_limits[0])
        print(self.joint_limits[1])
        print("# [VALIDATE ARM] REDUNDANT JOINT ID (0-INDEX) ".ljust(60, "#"))
        print(self.iq_redundant)
        print("# [VALIDATE ARM] REDUNDANT RANGE ".ljust(60, "#"))
        print(self.range_redundant)
        print("# [VALIDATE ARM] STATE REFERENCE ".ljust(60, "#"))
        print(self.state_ref)

    # def sample_state(self) -> DTypeState:
    #     self._rng.next(self._state_sample, 1)
    def sample_state(self) -> DTypeState:
        return np.random.uniform(self._state_bounds[0], self._state_bounds[1])

    #     return self._state_sample.astype(DTypeFloat)

    def collision_free_wall_torso(self, q: np.array) -> bool:
        self._arm.solver.fk_links(q, self._arm.qtLink)
        for iq, rwt in enumerate(self._arm.qtLink):
            if iq < self._link_range[0]:
                continue
            ampl.collision_transform_object(self._arm.sphs, self._arm.sphs_mov, iq, rwt)
            if ampl.collision_check_obb_vsph(
                self._obb3_torso, self._arm.sphs_mov, iq, self._wall
            ):
                return False
        return True

    def collision_free_wall_torso_df(self, q: DTypeState, env: CollisionScene) -> bool:
        self._arm.solver.fk_links(q, self._arm.qtLink)
        for iq, rwt in enumerate(self._arm.qtLink):
            if iq < self._link_range[0] or iq >= self._link_range[1]:
                continue
            ampl.collision_transform_object(self._arm.sphs, self._arm.sphs_mov, iq, rwt)
            if ampl.collision_check_obb_vsph(
                self._obb3_torso, self._arm.sphs_mov, iq, self._wall
            ):
                return False
            if ampl.collision_check_df_vsph(env.df, self._arm.sphs_mov, iq, 0.0):
                return False
        return True

    def ik_redundant_wall_torso(
        self,
        tf44_tool0: np.ndarray,
        state_ref: DTypeState,
        nb_redundant_search: int = 256,
    ):
        qs_search = np.linspace(
            self._q_min_max_redundant[0],
            self._q_min_max_redundant[1],
            nb_redundant_search + 1,
            True,
            dtype=DTypeDouble,
        )
        score_best = INF_FLOAT
        solution_best = np.array([0] * self.dof, dtype=DTypeDouble)
        score = INF_FLOAT
        ik_best = -1
        solution = np.array([0] * self.dof, dtype=DTypeDouble)
        for which_ik in self._which_iks:
            for q_redundant in qs_search:
                self._arm.q8[:, -1] = q_redundant
                ik_status = self._arm.solver.ik(tf44_tool0, self._arm.q8)
                if (ik_status >> which_ik) & 1:
                    np.copyto(solution, self._arm.q8[which_ik])
                    if self.collision_free_wall_torso(solution):
                        score = np.linalg.norm(state_ref - solution)
                        if score < score_best:
                            score_best = score
                            np.copyto(solution_best, solution)
                            ik_best = which_ik

        if score_best == INF_FLOAT:
            return []

        return [solution_best]

    def ik_redundant_wall_torso_df(
        self,
        tf44_tool0: np.ndarray,
        state_ref: DTypeState,
        nb_redundant_search: int = 256,
        env: CollisionScene = None,
    ):
        qs_search = np.linspace(
            self._q_min_max_redundant[0],
            self._q_min_max_redundant[1],
            nb_redundant_search + 1,
            True,
            dtype=DTypeDouble,
        )
        score_best = INF_FLOAT
        solution_best = np.array([0] * self.dof, dtype=DTypeDouble)
        score = INF_FLOAT
        solution = np.array([0] * self.dof, dtype=DTypeDouble)
        ik_best = -1
        for which_ik in self._which_iks:
            for q_redundant in qs_search:
                self._arm.q8[:, -1] = q_redundant
                ik_status = self._arm.solver.ik(tf44_tool0, self._arm.q8)
                if (ik_status >> which_ik) & 1:
                    np.copyto(solution, self._arm.q8[which_ik])
                    if self.collision_free_wall_torso_df(solution, env):
                        score = np.linalg.norm(state_ref[:5] - solution[:5])
                        if score < score_best:
                            score_best = score
                            np.copyto(solution_best, solution)
                            ik_best = which_ik

        if score_best == INF_FLOAT:
            return []

        return [solution_best]

    def collision_free_trajectory(
        self,
        q_start: DTypeState,
        q_end: DTypeState,
        env: CollisionScene,
        num: int = 16,
        include_start=True,
        include_end=True,
    ) -> bool:

        return False

    def collision_free_trajectory_no_attach(
        self,
        q_start: DTypeState,
        q_end: DTypeState,
        env: CollisionScene,
        num: int = 16,
        include_start=True,
        include_end=True,
    ) -> bool:
        trajectory = sample_trajectory_trivial(
            q_start, q_end, num, include_start, include_end
        )

        for q in trajectory[0:-1:2]:
            if not self.collision_free_wall_torso_df(q, env):
                return False
        for q in trajectory[1:-1:2]:
            if not self.collision_free_wall_torso_df(q, env):
                return False
        return True

    def collision_free_trajectory_attach(
        self,
        q_start: DTypeState,
        q_end: DTypeState,
        env: CollisionScene,
        num: int = 16,
        include_start=True,
        include_end=True,
    ) -> bool:
        trajectory = sample_trajectory_trivial(
            q_start, q_end, num, include_start, include_end
        )
        rwt_tcp_obj = self.pose_attach.astype(np.float32)

        for q in trajectory[0:-1:2]:
            if not self.collision_free_wall_torso_df(q, env):
                return False
            self.fk_rwt = q
            rwt_base_obj = ampl.rwtmul(
                self._arm.qtLink[-1].astype(np.float32), rwt_tcp_obj
            )
            # self.cvh_attach.pose = rwt_base_obj

            # ret_obj = not env.collision_free_external(self._cvh_attach, [rwt_base_obj])
            if not env.collision_free_external(self._cvh_attach, [rwt_base_obj])[0]:
                return False
            # ampl.conv self._cvh_attach

        for q in trajectory[1:-1:2]:
            if not self.collision_free_wall_torso_df(q, env):
                return False
            # self.fk_rwt = q
            rwt_base_obj = ampl.rwtmul(
                self._arm.qtLink[-1].astype(np.float32), rwt_tcp_obj
            )
            # self.cvh_attach.pose = rwt_base_obj
            if not env.collision_free_external(self._cvh_attach, [rwt_base_obj])[0]:
                return False
        return True

    def ik_redundant_wall_torso_batch(
        self, tf44_tool0: np.ndarray, nb_redundant_search: int = 128
    ):
        qs_search = np.linspace(
            self._q_min_max_redundant[0],
            self._q_min_max_redundant[1],
            nb_redundant_search + 1,
            True,
            dtype=DTypeDouble,
        )
        iks_batch = np.zeros((len(qs_search), 8), dtype=DTypeBool)
        ikq_batch = np.zeros((len(qs_search), 8, self.dof), dtype=DTypeFloat)
        for which_ik in self.which_iks:
            for iq, ql in enumerate(qs_search):
                self._arm.q8[:, -1] = ql
                ik_status = self._arm.solver.ik(tf44_tool0, self._arm.q8)
                if (ik_status >> which_ik) & 1:
                    if self.collision_free_wall_torso(self._arm.q8[which_ik]):
                        iks_batch[iq, which_ik] = True
                        np.copyto(ikq_batch[iq, which_ik], self._arm.q8[which_ik])
        return ikq_batch, iks_batch

    def mov_linear(
        self,
        state: DTypeState,
        xyz_incremental: np.ndarray,
        nb_subdivision: int = 32,
        nb_redundant_search: int = 64,
    ):
        self._arm.solver.fk_links(state, self._arm.qtLink)
        tf_tool0_start = ampl.qt7_to_tf44(self._arm.qtLink[-1])
        len_incremental = np.linalg.norm(xyz_incremental)
        ray_incremental = xyz_incremental / len_incremental
        len_samples = np.linspace(0, len_incremental, nb_subdivision, endpoint=True)
        nb_samples = len(len_samples)

        global_iks = np.zeros((nb_samples, nb_redundant_search + 1, 8), dtype=bool)
        global_ikq = np.zeros((nb_samples, nb_redundant_search + 1, 8, 7))
        for i, l in enumerate(len_samples):
            tf_tool0 = tf_tool0_start.copy()
            tf_tool0[:3, 3] += l * ray_incremental
            ikq_batch, iks_batch = self.ik_redundant_wall_torso_batch(
                tf_tool0, nb_redundant_search
            )
            np.copyto(global_iks[i], iks_batch)
            np.copyto(global_ikq[i], ikq_batch)
        for I_IK in self.which_iks:
            ik_feasible_mask = global_iks[:, :, I_IK].sum(axis=1)
            ik_feasible_intervals = connected_components_1d(ik_feasible_mask > 0)
            interval_dp = max(
                np.array(ik_feasible_intervals), key=lambda row: row[-1] - row[0]
            )
            matrix = global_iks[interval_dp[0] : interval_dp[1], :, I_IK]

            matrix_value = (
                global_ikq[interval_dp[0] : interval_dp[1], :, I_IK, :]
                .squeeze()
                .astype(np.float32)
            )
            min_id_start = np.argmin(np.linalg.norm(matrix_value[0] - state, axis=1))
            matrix[0][:] = False
            matrix[0][min_id_start] = True
            # found_path = find_smoothest_path(matrix,matrix_value,lp_norm=2)
            # found_path = find_minimal_deviation_path(
            #     matrix, matrix_value, max_col_neighbour=1
            # )
            found_path = find_smoothest_path(matrix, matrix_value, lp_norm=2)
            if found_path == None:
                return None
            if len(found_path) == 0:
                return None
            print(
                f"# [   INFO] IK arrangement {I_IK} subintervals = ",
                ik_feasible_intervals,
            )
            ik_q_found = np.zeros((len(global_iks), self.dof), dtype=np.float32)
            ik_m_found = np.zeros(len(global_iks), dtype=DTypeBool)
            if found_path:
                for point in found_path:
                    # path_ik.append(global_ikq[point[0]+interval_dp[0],point[1],I_IK,:])
                    ik_q_found[point[0] + interval_dp[0], :] = global_ikq[
                        point[0] + interval_dp[0], point[1], I_IK, :
                    ]
                    ik_m_found[point[0] + interval_dp[0]] = True
            # print(ik_q_found)
        # print(ik_m_found)
        return np.array(ik_q_found[ik_m_found])
        # import cv2

        # for which_ik in self.which_iks:

        #     cv2.imshow(
        #         f"{which_ik}", (global_iks[:, :, which_ik] * 255).astype(np.uint8)
        #     )

        # cv2.waitKey(0)
