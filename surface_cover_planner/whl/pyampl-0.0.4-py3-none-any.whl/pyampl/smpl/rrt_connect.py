import numpy as np
from .common import Tree
from .rrt_base import RRTBase
from typing import Type, Tuple
from ..common import AgentBase, CollisionSceneBase


class RRTConnect(RRTBase):
    def __init__(
        self,
        agent: AgentBase,
        env: CollisionSceneBase,
        max_edge_length: float,
        q_init: np.ndarray,
        q_goal: np.ndarray,
        max_samples: int = 500,
        edge_discrete_resolution: int = 12,
        prc: float = 0.01,
    ):
        super().__init__(
            agent,
            env,
            max_edge_length,
            q_init,
            q_goal,
            max_samples,
            edge_discrete_resolution,
            prc,
        )
        
        self.swapped = False
        self.x_nearest_np = np.array(q_init)
        self.x_rand_np = np.array(q_init)
        self.x_new_np = np.array(q_init)

    def swap_trees(self):
        self.trees[0], self.trees[1] = self.trees[1], self.trees[0]
        self.swapped = not self.swapped

    def unswap(self):
        if self.swapped:
            self.swap_trees()

    def extend(
        self, tree: Tree, x_rand: Tuple[float, ...]
    ) -> Tuple[Tuple[float, ...], RRTBase.Status]:
        x_nearest = self.get_nearest(tree, x_rand)
        self.x_nearest_np = np.array(x_nearest)
        self.x_rand_np = np.array(x_rand)
        x_new = RRTBase.steer(x_nearest, x_rand, self.max_edge_length)
        self.x_new_np = np.array(x_new)
        diff_len = np.linalg.norm(self.x_new_np - self.x_rand_np)
        if self.connect_to_point(tree, x_nearest, x_new):
            if diff_len < self.EPSILON_REACH:
                return x_new, RRTBase.Status.REACHED
            return x_new, RRTBase.Status.ADVANCED
        return x_new, RRTBase.Status.TRAPPED

    def connect(
        self, tree: Tree, x: Tuple[float, ...]
    ) -> Tuple[Tuple[float, ...], RRTBase.Status]:
        S = RRTBase.Status.ADVANCED
        while S == RRTBase.Status.ADVANCED:
            x_new, S = self.extend(tree, x)
        return x_new, S

    def rrt_connect(self):
        self.add_vertex(0, self.x_init)
        self.add_edge(0, self.x_init, None)
        self.add_tree()
        self.add_vertex(1, self.x_goal)
        self.add_edge(1, self.x_goal, None)
        while self.samples_taken < self.max_samples:
            x_rand = tuple(self.agent.sample_state())
            x_new, status = self.extend(0, x_rand)
            if status != RRTBase.Status.TRAPPED:
                x_new, connect_status = self.connect(1, x_new)
                if connect_status == RRTBase.Status.REACHED:
                    self.unswap()
                    first_part = self.reconstruct_path(
                        0, self.x_init, self.get_nearest(0, x_new)
                    )
                    second_part = self.reconstruct_path(
                        1, self.x_goal, self.get_nearest(1, x_new)
                    )
                    second_part.reverse()
                    return first_part[:-1] + second_part
            if self.trees[0].V_count > self.trees[1].V_count:
                self.swap_trees()
            self.samples_taken += 1

        return []
