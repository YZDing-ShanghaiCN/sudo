import enum
from typing import Type, Tuple, List
import numpy as np
from .common import Tree
from ..common import AgentBase, CollisionSceneBase, MotionPlannerBase


class RRTBase(MotionPlannerBase):
    class Status(enum.Enum):
        FAILED = 1
        TRAPPED = 2
        ADVANCED = 3
        REACHED = 4

    def __init__(
        self,
        agent: AgentBase,
        env: CollisionSceneBase,
        max_edge_length: float,
        q_init: np.ndarray,
        q_goal: np.ndarray,
        max_samples: int = 500,
        edge_discrete_resolution: int = 12,
        prc: float = 0.01,
    ):
        super().__init__(agent=agent, env=env)
        self.samples_taken = 0
        self.max_samples = max_samples
        self.max_edge_length = max_edge_length
        self.edge_discrete_resolution = edge_discrete_resolution
        self.prc = prc
        self.x_init = tuple(q_init.tolist())
        self.x_goal = tuple(q_goal.tolist())
        self.trees: List[Tree] = []
        self.add_tree()
        self.EPSILON_REACH = 5e-2

    @staticmethod
    def steer(
        start: Tuple[float, ...], goal: Tuple[float, ...], d_max: float
    ) -> Tuple[float, ...]:
        start, end = np.array(start), np.array(goal)
        v = end - start
        norm_v = np.linalg.norm(v)
        u = v / norm_v
        steered_point = start + u * min(norm_v, d_max)
        return tuple(steered_point)

    def add_tree(self):
        self.trees.append(Tree(self.agent.dim))

    def add_vertex(self, tree, v: Tuple[float, ...]):
        self.trees[tree].V.insert(0, v + v, v)  # since its tuple so v+v
        self.trees[tree].V_count += 1  # increment number of vertices in tree
        self.samples_taken += 1  # increment number of samples taken

    def add_edge(self, tree, child, parent):
        self.trees[tree].E[child] = parent

    def nearby(self, tree, x: Tuple[float, ...], n: int) -> Tuple[float, ...]:
        return self.trees[tree].V.nearest(x, num_results=n, objects="raw")

    def get_nearest(self, tree, x: Tuple[float, ...]) -> Tuple[float, ...]:
        return next(self.nearby(tree, x, 1))

    # def new_and_near(self, tree):
    #     x_rand = tuple(self.X.sample_state())
    #     x_nearest = self.get_nearest(tree, x_rand)
    #     x_new = RRTBase.steer(
    #         x_nearest,
    #         x_rand,
    #         min(
    #             self.max_edge_length,
    #             np.linalg.norm(np.array(x_nearest) - np.array(x_rand)),
    #         ),
    #     )
    #     # check if new point is in X_free and not already in V
    #     self.samples_taken += 1
    #     if not self.trees[0].V.count(x_new) == 0 or not self.agent.obstacle_free(x_new):
    #         return None, None
    #     return x_new, x_nearest

    def connect_to_point(self, tree, x_a: Tuple[float, ...], x_b: Tuple[float, ...]):
        if self.trees[tree].V.count(x_b) == 0 and self.agent.collision_free_trajectory(
            np.array(x_a),
            np.array(x_b),
            self.env,
            self.edge_discrete_resolution,
            False,
            True,
        ):
            self.add_vertex(tree, x_b)
            self.add_edge(tree, x_b, x_a)
            return True
        return False

    def reconstruct_path(
        self, tree, x_init: Tuple[float, ...], x_goal: Tuple[float, ...]
    ):
        path = [x_goal]
        current = x_goal
        if x_init == x_goal:
            return path
        while not self.trees[tree].E[current] == x_init:
            path.append(self.trees[tree].E[current])
            current = self.trees[tree].E[current]
        path.append(x_init)
        path.reverse()
        return path
