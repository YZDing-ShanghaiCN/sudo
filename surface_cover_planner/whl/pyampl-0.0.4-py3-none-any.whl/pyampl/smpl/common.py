from rtree import index
from typing import Dict, Tuple


DTypeRTreeNode = Tuple[float, ...]


class Tree:
    def __init__(self, dim: int):
        p = index.Property()
        p.dimension = dim
        self.V: index.Index = index.Index(interleaved=True, properties=p)
        self.V_count: int = 0
        self.E: Dict[DTypeRTreeNode, DTypeRTreeNode] = {}  # E[child] = parent
