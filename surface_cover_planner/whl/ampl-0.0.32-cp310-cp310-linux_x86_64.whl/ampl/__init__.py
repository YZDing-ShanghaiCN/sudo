"""
AMPL = Another Motion Planning Library
"""

__all__ = [
    "version",
    "ArmBase",
    "read_trimesh",
    "write_trimesh",
    "write_pointcloud",
    "read_pointcloud",
    "write_polylines",
    "read_polylines",
    "transform_xyz",
    "DistanceField",
]

from ._core import version as version
from ._core import ArmBase as ArmBase
from ._core import ControlReactive as ControlReactive
from ._core import ArmType as ArmType
from ._core import ControlType as ControlType
from ._core import OcTreedEntityType as OcTreedEntityType
from ._core import RNG3 as RNG3
from ._core import RNG6 as RNG6
from ._core import RNG7 as RNG7
from ._core import OBB3 as OBB3
from ._core import COBB3 as COBB3
from ._core import AAABB3 as AAABB3
from ._core import Plane3 as Plane3
from ._core import VCvhf as VCvhf
from ._core import Octreed as Octreed
from ._core import TrajBC6 as TrajBC6
from ._core import TrajBC7 as TrajBC7
from ._core import TrajBC3 as TrajBC3
from ._core import ICP as ICP
from ._core import ICPType as ICPType
from ._core import DynamicTree3D as DynamicTree3D
from ._core import Sphere3D as Sphere3D
from ._core import AABB3D as AABB3D
from ._core import get_gjk_collision_pairs as get_gjk_collision_pairs
from ._core import RTree as RTree
from ._core import Tf as Tf
from ._core import top_k as top_k
from ._core import spatial_to_mixed_linear as spatial_to_mixed_linear
from ._core import spatial_to_mixed_linear as spatial_to_mixed_linear

from ._core import SphereNode8, SphereTree, SphereBVHScene


# from ._core import TrajCubic3 as TrajCubic3
from ._core import CurveBSpline as CurveBSpline

from ._core import DistanceField as DistanceField
from ._core import VSphG8f as VSphG8f
from ._core import VSCHf as VSCHf

# from ._core import get_gjk_collision_pairs as get_gjk_collision_pairs

from ._core import get_arm6_presets as get_arm6_presets
from ._core import get_arm7_presets as get_arm7_presets

from ._core import collision_initialize_object as collision_initialize_object
from ._core import (
    collision_transform_object_inplace as collision_transform_object_inplace,
)
from ._core import collision_transform_object as collision_transform_object
from ._core import collision_visualize_object as collision_visualize_object
from ._core import collision_check_df_vsph as collision_check_df_vsph
from ._core import collision_check_xyzwall_vsph as collision_check_xyzwall_vsph
from ._core import collision_check_obb_vsph as collision_check_obb_vsph
from ._core import collision_check_cobb_vsph as collision_check_cobb_vsph
from ._core import collision_check_cvx_cvx as collision_check_cvx_cvx
from ._core import collision_check_vcvh_vcvh as collision_check_vcvh_vcvh
from ._core import collision_check_plane_vcvh as collision_check_plane_vcvh
from ._core import collision_distance_vcvh_vcvh as collision_distance_vcvh_vcvh
from ._core import collision_gradient_df_vsph as collision_gradient_df_vsph
from ._core import collision_gradient_obb_vsph as collision_gradient_obb_vsph
from ._core import collision_gradient_obb_vsph_pd as collision_gradient_obb_vsph_pd
from ._core import collision_check_vsph_vsph as collision_check_vsph_vsph
from ._core import collision_check_aaabb_vsph as collision_check_aaabb_vsph
from ._core import collision_debug_object as collision_debug_object
from ._core import collision_detail as collision_detail
from ._core import collision_check_aaabb3_vsch as collision_check_aaabb3_vsch
from ._core import collision_gradient_aaabb_vsph_pd as collision_gradient_aaabb_vsph_pd
from ._core import (
    collision_gradient_df_vsph_trilinear as collision_gradient_df_vsph_trilinear,
)
from ._core import collision_check_sphtree_sphtree as collision_check_sphtree_sphtree
from ._core import get_stl_data as get_stl_data
from ._core import splat_swept_capsule as splat_swept_capsule
from ._utils.io import read_trimesh as read_trimesh
from ._utils.io import write_trimesh as write_trimesh
from ._utils.io import write_pointcloud as write_pointcloud
from ._utils.io import read_pointcloud as read_pointcloud
from ._utils.io import write_polylines as write_polylines
from ._utils.io import read_polylines as read_polylines
from ._utils.io import read_geometry_codec as read_geometry_codec
from ._utils.misc import trimesh_grid2mesh as trimesh_grid_to_mesh
from ._core import trimesh_vhacd as trimesh_vhacd
from ._core import trimesh_raycast as trimesh_raycast
from ._core import (
    trimesh_sampler_barycentricysplit as trimesh_sampler_barycentricysplit,
)
from ._core import trimesh_connected_components as trimesh_connected_components
from ._core import trimesh_convexhull as trimesh_convexhull
from ._utils.io import trimesh_concatenate as trimesh_concatenate
from ._core import pointcloud_subsample_octree as pointcloud_subsample_octree
from ._core import pointcloud_segment as pointcloud_segment

from ._core import graph_dijkstra_single as graph_dijkstra_single
from ._core import graph_distance_matrix_l2 as graph_distance_matrix_l2
from ._core import graph_from_polyline as graph_from_polyline
from ._core import optim_qp as optim_qp
from ._core import distancefield_xyz2occ as distancefield_xyz2occ
from ._core import distancefield_occ2edf as distancefield_occ2edf
from ._core import distancefield_xyz2edf as distancefield_xyz2edf
from ._core import distancefield_df2trimesh as distancefield_df2trimesh

from ._core import sample_polyline_uniform as sample_polyline_uniform
from ._core import sample_sphere3_fibonacci
from ._utils.misc import rpy_to_tf33 as rpy_to_tf33
from ._utils.misc import xyzrpy_to_tf44 as xyzrpy_to_tf44
from ._utils.misc import quatmul as quatmul
from ._utils.misc import VSCHf_from_mesh
from ._utils.misc import build_sphere_tree
from ._utils.misc import match_obb3 as SE3_align_obb3
from ._core import dynamicprogram_minimum_deviation as dynamicprogram_minimum_deviation
from ._core import dynamicprogram_smooth_path as dynamicprogram_smooth_path
from ._core import tf44_to_qt7 as tf44_to_qt7
from ._core import qt7_to_tf44 as qt7_to_tf44
from ._core import rwtmul as rwtmul
from ._core import rwtinv as rwtinv
from ._core import euler_to_rw as euler_to_rw
from ._core import wxyz_t_to_tf44 as wxyz_t_to_tf44
from ._core import algo_debug as algo_debug

from ._core import bounding_obb_point2 as bounding_obb_point2
from ._core import bounding_obb_point3 as bounding_obb_point3
from ._core import bounding_sphere_point3 as bounding_sphere_point3

from ._core import frame3_contact as frame3_contact
from ._core import SO3_align as SO3_align
from ._core import estimate_plane as estimate_plane
from ._core import ransac_plane3 as ransac_plane3

from ._core import image_roi as image_roi
from ._core import image_depth_to_xyz as image_depth_to_xyz
from ._core import image_apriltags as image_apriltags
from ._core import image_apriltags_create_grid as image_apriltags_create_grid
from ._core import image_xyz_to_normal as image_xyz_to_normal
from ._core import warp_pixel_to_xyz as warp_pixel_to_xyz

from ._core import transform_so3_upexp as transform_so3_upexp
from ._core import transform_se3_upexp as transform_se3_upexp
from ._core import transform_so3_downlog as transform_so3_downlog
from ._core import transform_se3_downlog as transform_se3_downlog
from ._core import transform_xyz as transform_xyz

from ._core import so3_upexp as so3_upexp


from ._utils.base import Kin, FrameEnumT, MP, Traj, Col, WBC
from ._utils.col import ColConvex
from ._utils.kin import (
    HBFrames,
    KinHB20,
    Cruzrs2Frames,
    TJFrames,
    KinCruzrs2,
    KinHB11,
    KinHB10,
    KinTJ,
    KinLoong,
)

from ._utils.mp import MPRRTC
from ._utils.traj import TrajLinear


from ._core import KinematicBlock

from ._core import (
    DAQPSolver7,
    Controller7,
    JointRegularizationTask7,
    LinearVelTask7,
    AngularVelTask7,
    SwivelVelTask7,
    ContactRepTask7,
    LinearVelConstraint7,
    CollisionBarrierConstraint7,
    JointVelocityLimitConstraint7,
)
from ._core import (
    DAQPSolver14,
    Controller14,
    JointRegularizationTask14,
    LinearVelTask14,
    AngularVelTask14,
    SwivelVelTask14,
    ContactRepTask14,
    LinearVelConstraint14,
    CollisionBarrierConstraint14,
    JointVelocityLimitConstraint14,
)
from ._core import (
    DAQPSolver16,
    Controller16,
    JointRegularizationTask16,
    LinearVelTask16,
    AngularVelTask16,
    SwivelVelTask16,
    ContactRepTask16,
    LinearVelConstraint16,
    CollisionBarrierConstraint16,
    JointVelocityLimitConstraint16,
)
from ._core import (
    DAQPSolver18,
    Controller18,
    JointRegularizationTask18,
    LinearVelTask18,
    AngularVelTask18,
    SwivelVelTask18,
    ContactRepTask18,
    LinearVelConstraint18,
    CollisionBarrierConstraint18,
    JointVelocityLimitConstraint18,
)
from ._core import (
    DAQPSolver19,
    Controller19,
    JointRegularizationTask19,
    LinearVelTask19,
    AngularVelTask19,
    SwivelVelTask19,
    ContactRepTask19,
    LinearVelConstraint19,
    CollisionBarrierConstraint19,
    JointVelocityLimitConstraint19,
)

WBCDAQPSolver = DAQPSolver7 | DAQPSolver14 | DAQPSolver16 | DAQPSolver18 | DAQPSolver19
WBCController = Controller7 | Controller14 | Controller16 | Controller18 | Controller19
WBCLinearVelTask = (
    LinearVelTask7
    | LinearVelTask14
    | LinearVelTask16
    | LinearVelTask18
    | LinearVelTask19
)
WBCAngularVelTask = (
    AngularVelTask7
    | AngularVelTask14
    | AngularVelTask16
    | AngularVelTask18
    | AngularVelTask19
)
WBCJointRegularizationTask = (
    JointRegularizationTask7
    | JointRegularizationTask14
    | JointRegularizationTask16
    | JointRegularizationTask18
    | JointRegularizationTask19
)
WBCSwivelVelTask = (
    SwivelVelTask7
    | SwivelVelTask14
    | SwivelVelTask16
    | SwivelVelTask18
    | SwivelVelTask19
)
WBCJointVelocityLimitConstraint = (
    JointVelocityLimitConstraint7
    | JointVelocityLimitConstraint14
    | JointVelocityLimitConstraint16
    | JointVelocityLimitConstraint18
    | JointVelocityLimitConstraint19
)
WBCLinearVelConstraint = (
    LinearVelConstraint7
    | LinearVelConstraint14
    | LinearVelConstraint16
    | LinearVelConstraint18
    | LinearVelConstraint19
)
WBCCollisionBarrierConstraint = (
    CollisionBarrierConstraint7
    | CollisionBarrierConstraint14
    | CollisionBarrierConstraint16
    | CollisionBarrierConstraint18
    | CollisionBarrierConstraint19
)
WBCContactRepTask = (
    ContactRepTask7
    | ContactRepTask14
    | ContactRepTask16
    | ContactRepTask18
    | ContactRepTask19
)

from ._utils.wbc import WBIK, WBC277, WBCT77
