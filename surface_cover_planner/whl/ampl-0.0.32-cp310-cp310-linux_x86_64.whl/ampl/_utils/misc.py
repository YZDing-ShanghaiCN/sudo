import numpy as np
import ampl


def spatial_to_mixed_linear_fast(J_spatial, p_world):
    J_mixed = np.copy(J_spatial, order="F")
    px, py, pz = p_world.flatten()
    J_mixed[:3] += -1.0 * (
        np.array([[0, -pz, py], [pz, 0, -px], [-py, px, 0]]) @ J_mixed[3:]
    )
    return J_mixed


# from typing import Tuple, Union, List, Dict
def create_xyzr_offset(vs: list[list[float]]):
    xyzr = [np.array(v, dtype=np.float32).reshape((-1, 4)) for v in vs]
    offset = [len(a) for a in xyzr]
    xyzr = np.vstack(xyzr)
    offset = np.array(offset, dtype=np.uint32)
    return xyzr, offset


def rpy_to_tf33(rpy_radian: np.ndarray, dtype=np.float64) -> np.ndarray:
    roll, pitch, yaw = rpy_radian.tolist()
    Rx = np.array(
        [[1, 0, 0], [0, np.cos(roll), -np.sin(roll)], [0, np.sin(roll), np.cos(roll)]],
        dtype=dtype,
    )
    Ry = np.array(
        [
            [np.cos(pitch), 0, np.sin(pitch)],
            [0, 1, 0],
            [-np.sin(pitch), 0, np.cos(pitch)],
        ],
        dtype=dtype,
    )
    Rz = np.array(
        [[np.cos(yaw), -np.sin(yaw), 0], [np.sin(yaw), np.cos(yaw), 0], [0, 0, 1]],
        dtype=dtype,
    )
    R = Rz @ Ry @ Rx
    return R


def quatmul(q1: np.ndarray, q2: np.ndarray) -> np.ndarray:
    x1, y1, z1, w1 = q1
    x2, y2, z2, w2 = q2
    w = w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2
    x = w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2
    y = w1 * y2 - x1 * z2 + y1 * w2 + z1 * x1
    z = w1 * z2 + x1 * y2 - y1 * x1 + z1 * w2
    return np.array([x, y, z, w], dtype=q1.dtype)


def xyzrpy_to_tf44(xyz: np.ndarray, rpy: np.ndarray, dtype=np.float64) -> np.ndarray:
    T = np.eye(4, dtype=dtype)
    T[:3, :3] = rpy_to_tf33(rpy, dtype)
    T[:3, 3:] = np.array(xyz).reshape(3, 1)
    return T


def trimesh_grid2mesh(vertices: np.ndarray, rows: int, cols: int):
    """
    Converts a structured 2D grid of points into a triangle mesh.

    Args:
        vertices (np.ndarray): A 3D numpy array of shape (rows, cols, 3)
                               representing the grid points.
        rows (int): The number of rows in the grid.
        cols (int): The number of columns in the grid.

    Returns:
        tuple: A tuple containing:
            - flat_vertices (np.ndarray): A 1D array of vertex coordinates.
            - triangle_indices (np.ndarray): A 1D array of triangle indices.
    """
    # 1. Flatten the vertex list
    # The vertices are already in a flat C-contiguous array if created with np.zeros,
    # but we ensure it here. The index of vertex (i, j) is i * cols + j.
    flat_vertices = vertices.reshape(-1, 3)

    # 2. Generate triangle indices
    triangle_indices = []
    # We iterate through each quad, defined by its top-left corner (i, j)
    for i in range(rows - 1):
        for j in range(cols - 1):
            # Calculate the indices for the four corners of the current quad
            idx_A = i * cols + j
            idx_B = i * cols + (j + 1)
            idx_C = (i + 1) * cols + (j + 1)
            idx_D = (i + 1) * cols + j

            # Create two triangles for the quad (Method 1: A-B-C diagonal)
            # Triangle 1: A, B, C
            triangle_indices.append([idx_C, idx_B, idx_A])
            # Triangle 2: A, C, D
            triangle_indices.append([idx_D, idx_C, idx_A])

    return flat_vertices, np.array(triangle_indices, dtype=np.int32)


# def make_uv_mesh(grid_rows, grid_cols, range_x, range_y):
#     x = np.linspace(range_x[0], range_x[1], grid_cols)
#     y = np.linspace(range_y[0], range_y[1], grid_rows)
#     X, Y = np.meshgrid(x, y)
#     vertices = np.zeros((grid_rows, grid_cols, 3), dtype=np.float32)
#     vertices[:, :, 0] = X
#     vertices[:, :, 1] = Y
#     vertices[:, :, 2] *= 0.0
#     vertices[:, :, 2] = 1.4
#     V, F = trimesh_grid2mesh(vertices, grid_rows, grid_cols)
#     return V, F


def VSCHf_from_mesh(vf: tuple[np.ndarray, np.ndarray] | list[np.ndarray]) -> ampl.VSCHf:
    if isinstance(vf, tuple):
        v = vf[0]
        f = vf[1]
        fccs = ampl.trimesh_connected_components(f.astype(np.uint32))
        vs = [
            v[np.unique(f[fcc].flatten())].astype(np.float32)
            for _, fcc in enumerate(fccs)
        ]
        # print(len(fccs))
    elif isinstance(vf, list):
        vs = [v.astype(np.float32) for v in vf]
    else:
        return None
    cvh = ampl.VSCHf()
    ampl.collision_initialize_object(vs, cvh)
    return cvh


def match_obb3(obbA: tuple, obbB: tuple):
    R_180 = [
        np.array([[1, 0, 0], [0, -1, 0], [0, 0, -1]])
        # 180-degree rotation around Y-axis
        ,
        np.array([[-1, 0, 0], [0, 1, 0], [0, 0, -1]]),
        # 180-degree rotation around Z-axis
        np.array([[-1, 0, 0], [0, -1, 0], [0, 0, 1]]),
    ]
    c_A, extents_A, R_A = obbA
    c_B, extents_B, R_B = obbB
    axes_A = [R_A[:, 0], R_A[:, 1], R_A[:, 2]]
    axes_B = [R_B[:, 0], R_B[:, 1], R_B[:, 2]]

    sort_idx_A = np.argsort(extents_A)
    sort_idx_B = np.argsort(extents_B)

    U_A_prime = np.column_stack(
        (axes_A[sort_idx_A[0]], axes_A[sort_idx_A[1]], axes_A[sort_idx_A[2]])
    )

    U_B_prime = np.column_stack(
        (axes_B[sort_idx_B[0]], axes_B[sort_idx_B[1]], axes_B[sort_idx_B[2]])
    )

    R = U_B_prime @ U_A_prime.T

    if np.linalg.det(R) < 0:

        U_B_prime[:, 2] = -U_B_prime[:, 2]

        R = U_B_prime @ U_A_prime.T

    t = c_B - R @ c_A
    tf = np.eye(4)
    tf[:3, :3] = R
    tf[:3, 3] = t.flatten()

    return tf


def build_sphere_tree(parsed_data: dict):
    geometry = parsed_data["geometry"]
    cpp_tree = ampl.SphereTree()

    # 1. Set Root Sphere
    root_data = np.array(geometry["root"])[0]
    cpp_tree.root_sphere = np.array(root_data[1:5], dtype=np.float32)

    # 2. Allocate exactly 9 C++ nodes
    cpp_nodes = [ampl.SphereNode8() for _ in range(9)]

    # 3. Populate Node 0 (The Mid-Spheres)
    mid_node = cpp_nodes[0]

    # Temporary lists to hold the data before writing to C++
    m_x, m_y, m_z, m_r = [0.0] * 8, [0.0] * 8, [0.0] * 8, [0.0] * 8
    m_child = [0] * 8
    m_valid = 0

    for idx, row in enumerate(np.array(geometry["mid"])):
        m_x[idx] = float(row[1])
        m_y[idx] = float(row[2])
        m_z[idx] = float(row[3])
        m_r[idx] = float(row[4])

        m_valid |= 1 << idx
        m_child[idx] = idx + 1

    # WRITE TO C++ MEMORY
    mid_node.x = m_x
    mid_node.y = m_y
    mid_node.z = m_z
    mid_node.r = m_r
    mid_node.child_idx = m_child
    mid_node.valid_mask = m_valid

    # 4. Populate Nodes 1 through 8 (The Leaf-Spheres)
    current_block_idx = 1

    for mid_id, leaf_ids in parsed_data["relations"]["mid_to_leaf"].items():
        leaf_node = cpp_nodes[current_block_idx]

        l_x, l_y, l_z, l_r = [0.0] * 8, [0.0] * 8, [0.0] * 8, [0.0] * 8
        l_child = [0] * 8
        l_valid, l_leaf = 0, 0
        gl = np.array(geometry["leaves"])
        for slot, leaf_id in enumerate(leaf_ids):
            # Find geometry for this leaf_id
            leaf_row = gl[gl[:, 0] == leaf_id][0]

            l_x[slot] = float(leaf_row[1])
            l_y[slot] = float(leaf_row[2])
            l_z[slot] = float(leaf_row[3])
            l_r[slot] = float(leaf_row[4])

            l_valid |= 1 << slot
            l_leaf |= 1 << slot
            l_child[slot] = int(leaf_id)

        # WRITE TO C++ MEMORY
        leaf_node.x = l_x
        leaf_node.y = l_y
        leaf_node.z = l_z
        leaf_node.r = l_r
        leaf_node.child_idx = l_child
        leaf_node.valid_mask = l_valid
        leaf_node.leaf_mask = l_leaf

        current_block_idx += 1

    # Finally, write the list of nodes to the tree
    cpp_tree.nodes = cpp_nodes
    return cpp_tree
