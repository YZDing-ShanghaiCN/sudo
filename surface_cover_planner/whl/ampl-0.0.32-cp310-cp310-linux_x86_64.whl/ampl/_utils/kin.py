import numpy as np
import ampl
from ampl import Tf
from enum import Enum, auto
from abc import abstractmethod
from typing import Generic
from .base import Kin, FrameEnumT
import numpy.typing as npt


class KinA7A7(Kin, Generic[FrameEnumT]):
    """
    Zero-overhead base class. All dependent parameters are cached in __init__.
    """

    DOF_A = 7

    def _init_arm(self, name: str) -> tuple:
        """Allocates memory and kinematics engine for a 7-DoF arm."""
        kin = ampl.ArmBase(name, ampl.ArmType.Humanoid7, self.DOF_A)

        # Fetch limits once
        limits = kin.joint_limits()
        redundant = [limits[0][6], limits[1][6]]
        # Allocate contiguous math buffers
        q8 = np.zeros((8, self.DOF_A), dtype=np.float64)
        fk = np.zeros((self.DOF_A + 1, 7), dtype=np.float64)
        Js = np.zeros((6, self.DOF_A), order="F", dtype=np.float64)
        q = np.zeros(self.DOF_A, dtype=np.float64)
        return kin, q8, redundant, fk, Js, q

    @property
    @abstractmethod
    def Frames(self) -> type[FrameEnumT]:
        """
        Forces the specific robot to provide its static Enum class.
        """
        pass

    def __init__(self, name_arm_left: str, name_arm_right: str):
        # 1. Fetch the specific robot's Torso DoF exactly once

        # 2. Pre-compute total DoF
        self.DOF_TOTAL = 2 * self.DOF_A

        # 3. Pre-compute EXACT array slice indices for the kinematic chains
        self._I_L = 0
        self._I_L_END = self.DOF_A
        self._I_R = self._I_L_END
        self._I_R_END = self._I_L_END + self.DOF_A

        (
            self._kin_L,
            self._q8_L,
            self._redundant_L,
            self._fk_L,
            self._Js_L,
            self._q_L,
        ) = self._init_arm(name_arm_left)
        (
            self._kin_R,
            self._q8_R,
            self._redundant_R,
            self._fk_R,
            self._Js_R,
            self._q_R,
        ) = self._init_arm(name_arm_right)

        self._FRAMES_ACTUATED = self._define_q_to_frame()
        self._tf_arm_base_L, self._tf_arm_base_R = self._init_torso()
        self._kin_L.set_base(
            self._tf_arm_base_L.matrix.astype(np.float64).copy(order="C")
        )
        self._kin_R.set_base(
            self._tf_arm_base_R.matrix.astype(np.float64).copy(order="C")
        )

    @abstractmethod
    def _init_torso(self) -> tuple[ampl.Tf, ampl.Tf]:
        pass

    @abstractmethod
    def _define_q_to_frame(self) -> list[str]:
        """Specific robots must provide their ordered joint names."""
        pass

    # @abstractmethod
    # def _define_special_frames(self) -> list[str]:
    #     """Returns a list of arbitrary frame names (e.g., 'camera_link')."""
    #     pass

    def get_limits(self):
        return (
            self._kin_L.joint_limits()[0] + self._kin_R.joint_limits()[0],
            self._kin_L.joint_limits()[1] + self._kin_R.joint_limits()[1],
        )

    def get_fk_actuated_frame(self) -> np.ndarray:
        return np.vstack([self._fk_L[: self.DOF_A], self._fk_R[: self.DOF_A]])

    def get_jacobian_actuated_frame(self) -> np.ndarray:
        return np.hstack([self._Js_L[: self.DOF_A], self._Js_R[: self.DOF_A]])

    @abstractmethod
    def get_ik(self, frame: FrameEnumT):
        pass

    def get_base(self) -> Tf:
        return None

    def get_actuated_frames(self) -> list[str]:
        return self._FRAMES_ACTUATED

    def update_kin(
        self, q: np.ndarray, pose_base: Tf = None, update_jacobian: bool = False
    ) -> None:
        if pose_base is not None:
            self._kin_L.set_base(
                (pose_base @ self._tf_arm_base_L)
                .matrix.astype(np.float64)
                .copy(order="C")
            )
            self._kin_R.set_base(
                (pose_base @ self._tf_arm_base_R)
                .matrix.astype(np.float64)
                .copy(order="C")
            )

        self._q_L = q[self._I_L : self._I_L_END].astype(np.float64)
        self._q_R = q[self._I_R : self._I_R_END].astype(np.float64)
        # print(self._q_T.shape)
        # print(self._q_L.shape)
        # print(self._q_R.shape)

        # self._kin_L.set_base(ampl.qt7_to_tf44(self._fk_T[-2]))
        # self._kin_R.set_base(ampl.qt7_to_tf44(self._fk_T[-1]))
        # print(self._fk_T.shape)
        self._kin_L.fk_links(self._q_L, self._fk_L)
        self._kin_R.fk_links(self._q_R, self._fk_R)
        if not update_jacobian:
            return

        self._kin_L.jacobian(self._fk_L, self._Js_L)
        self._kin_R.jacobian(self._fk_R, self._Js_R)

    @abstractmethod
    def get_fk(self, frame: FrameEnumT) -> Tf:
        pass

    @abstractmethod
    def get_jacobian(self, frame: FrameEnumT):
        pass


class KinTA7A7(Kin, Generic[FrameEnumT]):
    """
    Zero-overhead base class. All dependent parameters are cached in __init__.
    """

    DOF_A = 7

    def _init_arm(self, name: str) -> tuple:
        """Allocates memory and kinematics engine for a 7-DoF arm."""
        kin = ampl.ArmBase(name, ampl.ArmType.Humanoid7, self.DOF_A)

        # Fetch limits once
        limits = kin.joint_limits()
        redundant = [limits[0][6], limits[1][6]]
        # Allocate contiguous math buffers
        q8 = np.zeros((8, self.DOF_A), dtype=np.float64)
        fk = np.zeros((self.DOF_A + 1, 7), dtype=np.float64)
        Js = np.zeros((6, self.DOF_A), order="F", dtype=np.float64)
        q = np.zeros(self.DOF_A, dtype=np.float64)
        return kin, q8, redundant, fk, Js, q

    @property
    @abstractmethod
    def Frames(self) -> type[FrameEnumT]:
        """
        Forces the specific robot to provide its static Enum class.
        """
        pass

    def __init__(self, name_arm_left: str, name_arm_right: str, name_torso: str):
        # 1. Fetch the specific robot's Torso DoF exactly once
        self.DOF_T = self._define_torso_dof()

        # 2. Pre-compute total DoF
        self.DOF_TOTAL = self.DOF_T + (2 * self.DOF_A)

        # 3. Pre-compute EXACT array slice indices for the kinematic chains
        self._I_L = self.DOF_T
        self._I_L_END = self.DOF_T + self.DOF_A
        self._I_R = self._I_L_END
        self._I_R_END = self._I_L_END + self.DOF_A
        self._tf_base = ampl.Tf()

        (
            self._kin_L,
            self._q8_L,
            self._redundant_L,
            self._fk_L,
            self._Js_L,
            self._q_L,
        ) = self._init_arm(name_arm_left)
        (
            self._kin_R,
            self._q8_R,
            self._redundant_R,
            self._fk_R,
            self._Js_R,
            self._q_R,
        ) = self._init_arm(name_arm_right)
        (
            self._kin_T,
            self._q2_T,
            self._fk_T,
            self._Js_T,
            self._q_T,
        ) = self._init_torso(name_torso)
        self._FRAMES_ACTUATED = self._define_q_to_frame()
        # self._FRAMES_SPECIAL = self._define_special_frames()

    @abstractmethod
    def _define_torso_dof(self) -> int:
        """Specific robots must implement this to return their Torso DoF."""
        pass

    @abstractmethod
    def _init_torso(self, name_torso: str):
        pass

    @abstractmethod
    def _define_q_to_frame(self) -> list[str]:
        """Specific robots must provide their ordered joint names."""
        pass

    # @abstractmethod
    # def _define_special_frames(self) -> list[str]:
    #     """Returns a list of arbitrary frame names (e.g., 'camera_link')."""
    #     pass
    def get_base(self) -> Tf:
        return self._tf_base

    def get_limits(self):
        return (
            self._kin_T.joint_limits()[0]
            + self._kin_L.joint_limits()[0]
            + self._kin_R.joint_limits()[0],
            self._kin_T.joint_limits()[1]
            + self._kin_L.joint_limits()[1]
            + self._kin_R.joint_limits()[1],
        )

    def get_fk_actuated_frame(self) -> np.ndarray:
        return np.vstack(
            [
                self._fk_T[: self.DOF_T],
                self._fk_L[: self.DOF_A],
                self._fk_R[: self.DOF_A],
            ]
        )

    def get_jacobian_actuated_frame(self) -> np.ndarray:
        return np.hstack(
            [
                self._Js_T[:, : self.DOF_T],
                self._Js_L[:, : self.DOF_A],
                self._Js_R[:, : self.DOF_A],
            ]
        )

    @abstractmethod
    def get_ik(self, frame: FrameEnumT):
        pass

    def get_actuated_frames(self) -> list[str]:
        return self._FRAMES_ACTUATED

    def update_kin(
        self, q: np.ndarray, pose_base: Tf = None, update_jacobian: bool = False
    ) -> None:
        if pose_base is not None:
            self._tf_base = pose_base
            self._kin_T.set_base(pose_base.matrix.astype(np.float64).copy(order="C"))

        self._q_T = q[0 : self.DOF_T].astype(np.float64)
        self._q_L = q[self._I_L : self._I_L_END].astype(np.float64)
        self._q_R = q[self._I_R : self._I_R_END].astype(np.float64)
        # print(self._q_T.shape)
        # print(self._q_L.shape)
        # print(self._q_R.shape)
        self._kin_T.fk_links(self._q_T, self._fk_T)

        self._kin_L.set_base(ampl.qt7_to_tf44(self._fk_T[-2]))
        self._kin_R.set_base(ampl.qt7_to_tf44(self._fk_T[-1]))
        # print(self._fk_T.shape)
        self._kin_L.fk_links(self._q_L, self._fk_L)
        self._kin_R.fk_links(self._q_R, self._fk_R)
        if not update_jacobian:
            return
        self._kin_T.jacobian(self._fk_T, self._Js_T)
        self._kin_L.jacobian(self._fk_L, self._Js_L)
        self._kin_R.jacobian(self._fk_R, self._Js_R)

    @abstractmethod
    def get_fk(self, frame: FrameEnumT) -> Tf:
        pass


class Cruzrs2Frames(Enum):
    L_sixforce_link = auto()
    R_sixforce_link = auto()


class TJFrames(Enum):
    left_tool0 = auto()
    right_tool0 = auto()


class HBFrames(Enum):
    left_link_tactile_center = auto()
    right_link_tactile_center = auto()


class KinTJ(KinA7A7[TJFrames]):
    @property
    def Frames(self) -> type[TJFrames]:
        return TJFrames

    def get_fk(self, frame: FrameEnumT) -> Tf:
        if frame == self.Frames.left_tool0:
            return Tf(self._fk_L[-1])
        if frame == self.Frames.right_tool0:
            return Tf(self._fk_R[-1])
        return None

    def get_jacobian(self, frame: FrameEnumT) -> npt.NDArray[np.float64]:
        if frame == self.Frames.left_tool0:
            return self._Js_L
        if frame == self.Frames.right_tool0:
            return self._Js_R

    def __init__(self, name_arm_left: str, name_arm_right: str):
        super().__init__(name_arm_left, name_arm_right)

    # def _define_torso_dof(self) -> int:
    #     return 5

    def _init_torso(self) -> tuple:
        tf_L = ampl.Tf(
            xyz=np.array([0.0, 0.037, 0.14]), rpy=np.array([-np.pi / 2, 0, 0])
        )
        tf_R = ampl.Tf(
            xyz=np.array([0.0, -0.037, 0.14]), rpy=np.array([np.pi / 2, 0, 0])
        )
        return tf_L, tf_R

    def _define_q_to_frame(self) -> list[str]:
        return [
            "left_link_1",
            "left_link_2",
            "left_link_3",
            "left_link_4",
            "left_link_5",
            "left_link_6",
            "left_link_7",
            "right_link_1",
            "right_link_2",
            "right_link_3",
            "right_link_4",
            "right_link_5",
            "right_link_6",
            "right_link_7",
        ]

    def get_ik(
        self,
        tf_target: Tf,
        frame: FrameEnumT,
        nb_redundant_search: int = 256,
        range_redundant_last_joint: list | np.ndarray = None,
        which_iks: list[int] = [4, 5, 6, 7],
    ):

        tf44_tool0 = tf_target.matrix.copy(order="C")
        ik_result = {}
        if frame == self.Frames.left_tool0:
            q8 = self._q8_L
            if range_redundant_last_joint is None:
                rlo = self._redundant_L[0]
                rhi = self._redundant_L[1]
            else:
                rlo = range_redundant_last_joint[0]
                rhi = range_redundant_last_joint[1]
            kin = self._kin_L

        elif frame == self.Frames.right_tool0:
            q8 = self._q8_R
            if range_redundant_last_joint is None:
                rlo = self._redundant_R[0]
                rhi = self._redundant_R[1]
            else:
                rlo = range_redundant_last_joint[0]
                rhi = range_redundant_last_joint[1]
            kin = self._kin_R
        else:
            return {}

        qs_search = np.linspace(
            rlo, rhi, nb_redundant_search + 1, True, dtype=np.float64
        )

        for which_ik in which_iks:
            ikq_batch = np.zeros((len(qs_search), self.DOF_A), dtype=np.float64)
            iks_batch = np.zeros(len(qs_search), dtype=bool)
            # print(which_ik)
            for iq, ql in enumerate(qs_search):
                q8[:, -1] = ql
                ik_status = kin.ik(tf44_tool0, q8)
                if (ik_status >> which_ik) & 1:
                    iks_batch[iq] = True
                    np.copyto(ikq_batch[iq], q8[which_ik])
            ik_result[which_ik] = (iks_batch.copy(), ikq_batch.copy())
        return ik_result


class KinHB20(KinTA7A7[HBFrames]):
    @property
    def Frames(self) -> type[HBFrames]:
        return HBFrames

    def get_fk(self, frame: FrameEnumT) -> Tf:
        if frame == self.Frames.left_link_tactile_center:
            return Tf(self._fk_L[-1])
        if frame == self.Frames.right_link_tactile_center:
            return Tf(self._fk_R[-1])
        return None

    def get_jacobian(self, frame: FrameEnumT) -> npt.NDArray[np.float64]:
        if frame == self.Frames.left_link_tactile_center:
            return self._Js_L
        if frame == self.Frames.right_link_tactile_center:
            return self._Js_R

    def __init__(self, name_arm_left: str, name_arm_right: str, name_torso: str):
        super().__init__(name_arm_left, name_arm_right, name_torso)

    def _define_torso_dof(self) -> int:
        return 5

    def _init_torso(self, name: str) -> tuple:
        kin = ampl.ArmBase(name, ampl.ArmType.Torso5, self.DOF_T)
        q2 = np.zeros((8, self.DOF_T), dtype=np.float64)
        fk = np.zeros((self.DOF_T + 2, 7), dtype=np.float64)
        Js = np.zeros((6, self.DOF_T), order="F", dtype=np.float64)
        q = np.zeros(self.DOF_T, dtype=np.float64)
        return kin, q2, fk, Js, q

    def _define_q_to_frame(self) -> list[str]:
        return [
            "link_waist_1",
            "link_waist_2",
            "link_waist_3",
            "link_waist_4",
            "link_waist_5",
            "left-link_arm_1",
            "left-link_arm_2",
            "left-link_arm_3",
            "left-link_arm_4",
            "left-link_arm_5",
            "left-link_arm_6",
            "left-link_arm_7",
            "right-link_arm_1",
            "right-link_arm_2",
            "right-link_arm_3",
            "right-link_arm_4",
            "right-link_arm_5",
            "right-link_arm_6",
            "right-link_arm_7",
        ]

    def get_ik(
        self,
        tf_target: Tf,
        frame: FrameEnumT,
        nb_redundant_search: int = 256,
        range_redundant_last_joint: list | np.ndarray = None,
        which_iks: list[int] = [4, 5, 6, 7],
    ):

        tf44_tool0 = tf_target.matrix.copy(order="C")
        ik_result = {}
        if frame == self.Frames.left_link_tactile_center:
            q8 = self._q8_L
            if range_redundant_last_joint is None:
                rlo = self._redundant_L[0]
                rhi = self._redundant_L[1]
            else:
                rlo = range_redundant_last_joint[0]
                rhi = range_redundant_last_joint[1]
            kin = self._kin_L

        elif frame == self.Frames.right_link_tactile_center:
            q8 = self._q8_R
            if range_redundant_last_joint is None:
                rlo = self._redundant_R[0]
                rhi = self._redundant_R[1]
            else:
                rlo = range_redundant_last_joint[0]
                rhi = range_redundant_last_joint[1]
            kin = self._kin_R
        else:
            return {}

        qs_search = np.linspace(
            rlo, rhi, nb_redundant_search + 1, True, dtype=np.float64
        )

        for which_ik in which_iks:

            ikq_batch = np.zeros((len(qs_search), self.DOF_A), dtype=np.float64)
            iks_batch = np.zeros(len(qs_search), dtype=bool)
            for iq, ql in enumerate(qs_search):
                q8[:, -1] = ql
                ik_status = kin.ik(tf44_tool0, q8)
                if (ik_status >> which_ik) & 1:
                    iks_batch[iq] = True
                    np.copyto(ikq_batch[iq], q8[which_ik])
            ik_result[which_ik] = (iks_batch.copy(), ikq_batch.copy())
        return ik_result


class KinHB11(KinTA7A7[HBFrames]):
    @property
    def Frames(self) -> type[HBFrames]:
        return HBFrames

    def get_fk(self, frame: FrameEnumT) -> Tf:
        if frame == self.Frames.left_link_tactile_center:
            return Tf(self._fk_L[-1])
        if frame == self.Frames.right_link_tactile_center:
            return Tf(self._fk_R[-1])
        return None

    def get_jacobian(self, frame: FrameEnumT) -> npt.NDArray[np.float64]:
        if frame == self.Frames.left_link_tactile_center:
            return self._Js_L
        if frame == self.Frames.right_link_tactile_center:
            return self._Js_R

    def __init__(self, name_arm_left: str, name_arm_right: str, name_torso: str):
        super().__init__(name_arm_left, name_arm_right, name_torso)

    def _define_torso_dof(self) -> int:
        return 2

    def _init_torso(self, name: str) -> tuple:
        kin = ampl.ArmBase(name, ampl.ArmType.Extern_TZRX, self.DOF_T)
        q2 = np.zeros((8, self.DOF_T), dtype=np.float64)
        fk = np.zeros((self.DOF_T + 2, 7), dtype=np.float64)
        Js = np.zeros((6, self.DOF_T), order="F", dtype=np.float64)
        q = np.zeros(self.DOF_T, dtype=np.float64)
        return kin, q2, fk, Js, q

    def _define_q_to_frame(self) -> list[str]:
        return [
            "link_torso_1",
            "link_torso_2",
            "left-link_arm_1",
            "left-link_arm_2",
            "left-link_arm_3",
            "left-link_arm_4",
            "left-link_arm_5",
            "left-link_arm_6",
            "left-link_arm_7",
            "right-link_arm_1",
            "right-link_arm_2",
            "right-link_arm_3",
            "right-link_arm_4",
            "right-link_arm_5",
            "right-link_arm_6",
            "right-link_arm_7",
        ]

    def get_ik(
        self,
        tf_target: Tf,
        frame: FrameEnumT,
        nb_redundant_search: int = 256,
        range_redundant_last_joint: list | np.ndarray = None,
        which_iks: list[int] = [4, 5, 6, 7],
    ):

        tf44_tool0 = tf_target.matrix.copy(order="C")
        ik_result = {}
        if frame == self.Frames.left_link_tactile_center:
            q8 = self._q8_L
            if range_redundant_last_joint is None:
                rlo = self._redundant_L[0]
                rhi = self._redundant_L[1]
            else:
                rlo = range_redundant_last_joint[0]
                rhi = range_redundant_last_joint[1]
            kin = self._kin_L

        elif frame == self.Frames.right_link_tactile_center:
            q8 = self._q8_R
            if range_redundant_last_joint is None:
                rlo = self._redundant_R[0]
                rhi = self._redundant_R[1]
            else:
                rlo = range_redundant_last_joint[0]
                rhi = range_redundant_last_joint[1]
            kin = self._kin_R
        else:
            return {}

        qs_search = np.linspace(
            rlo, rhi, nb_redundant_search + 1, True, dtype=np.float64
        )

        for which_ik in which_iks:
            ikq_batch = np.zeros((len(qs_search), self.DOF_A), dtype=np.float64)
            iks_batch = np.zeros(len(qs_search), dtype=bool)
            for iq, ql in enumerate(qs_search):
                q8[:, -1] = ql
                ik_status = kin.ik(tf44_tool0, q8)
                if (ik_status >> which_ik) & 1:
                    iks_batch[iq] = True
                    np.copyto(ikq_batch[iq], q8[which_ik])
            ik_result[which_ik] = (iks_batch.copy(), ikq_batch.copy())
        return ik_result


KinHB10 = KinHB11


class KinLoong(KinTA7A7[HBFrames]):
    @property
    def Frames(self) -> type[HBFrames]:
        return HBFrames

    def get_fk(self, frame: FrameEnumT) -> Tf:
        if frame == self.Frames.left_link_tactile_center:
            return Tf(self._fk_L[-1])
        if frame == self.Frames.right_link_tactile_center:
            return Tf(self._fk_R[-1])
        return None

    def get_jacobian(self, frame: FrameEnumT) -> npt.NDArray[np.float64]:
        if frame == self.Frames.left_link_tactile_center:
            return self._Js_L
        if frame == self.Frames.right_link_tactile_center:
            return self._Js_R

    def __init__(self, name_arm_left: str, name_arm_right: str, name_torso: str):
        super().__init__(name_arm_left, name_arm_right, name_torso)

    def _define_torso_dof(self) -> int:
        return 2

    def _init_torso(self, name: str) -> tuple:
        kin = ampl.ArmBase(name, ampl.ArmType.Extern_TZRX, self.DOF_T)
        q2 = np.zeros((8, self.DOF_T), dtype=np.float64)
        fk = np.zeros((self.DOF_T + 2, 7), dtype=np.float64)
        Js = np.zeros((6, self.DOF_T), order="F", dtype=np.float64)
        q = np.zeros(self.DOF_T, dtype=np.float64)
        return kin, q2, fk, Js, q

    def _define_q_to_frame(self) -> list[str]:
        return [
            "waist_vertical",
            "waist_horizontal",
            "left_arm_1",
            "left_arm_2",
            "left_arm_3",
            "left_arm_4",
            "left_arm_5",
            "left_arm_6",
            "left_arm_7",
            "right_arm_1",
            "right_arm_2",
            "right_arm_3",
            "right_arm_4",
            "right_arm_5",
            "right_arm_6",
            "right_arm_7",
        ]

    def get_ik(
        self,
        tf_target: Tf,
        frame: FrameEnumT,
        nb_redundant_search: int = 256,
        range_redundant_last_joint: list | np.ndarray = None,
        which_iks: list[int] = [4, 5, 6, 7],
    ):

        tf44_tool0 = tf_target.matrix.copy(order="C")
        ik_result = {}
        if frame == self.Frames.left_link_tactile_center:
            q8 = self._q8_L
            if range_redundant_last_joint is None:
                rlo = self._redundant_L[0]
                rhi = self._redundant_L[1]
            else:
                rlo = range_redundant_last_joint[0]
                rhi = range_redundant_last_joint[1]
            kin = self._kin_L

        elif frame == self.Frames.right_link_tactile_center:
            q8 = self._q8_R
            if range_redundant_last_joint is None:
                rlo = self._redundant_R[0]
                rhi = self._redundant_R[1]
            else:
                rlo = range_redundant_last_joint[0]
                rhi = range_redundant_last_joint[1]
            kin = self._kin_R
        else:
            return {}

        qs_search = np.linspace(
            rlo, rhi, nb_redundant_search + 1, True, dtype=np.float64
        )

        for which_ik in which_iks:
            ikq_batch = np.zeros((len(qs_search), self.DOF_A), dtype=np.float64)
            iks_batch = np.zeros(len(qs_search), dtype=bool)
            for iq, ql in enumerate(qs_search):
                q8[:, -1] = ql
                ik_status = kin.ik(tf44_tool0, q8)
                if (ik_status >> which_ik) & 1:
                    iks_batch[iq] = True
                    np.copyto(ikq_batch[iq], q8[which_ik])
            ik_result[which_ik] = (iks_batch.copy(), ikq_batch.copy())
        return ik_result


class KinCruzrs2(KinTA7A7[Cruzrs2Frames]):
    @property
    def Frames(self) -> type[Cruzrs2Frames]:
        return Cruzrs2Frames

    def get_fk(self, frame: FrameEnumT) -> Tf:
        if frame == self.Frames.L_sixforce_link:
            return Tf(self._fk_L[-1])
        if frame == self.Frames.R_sixforce_link:
            return Tf(self._fk_R[-1])
        return None

    def get_jacobian(self, frame: FrameEnumT) -> npt.NDArray[np.float64]:
        if frame == self.Frames.L_sixforce_link:
            return self._Js_L
        if frame == self.Frames.R_sixforce_link:
            return self._Js_R

    def __init__(self, name_arm_left: str, name_arm_right: str, name_torso: str):
        super().__init__(name_arm_left, name_arm_right, name_torso)

    def _define_torso_dof(self) -> int:
        return 4

    def _init_torso(self, name: str) -> tuple:
        kin = ampl.ArmBase(name, ampl.ArmType.Torso4, self.DOF_T)
        q2 = np.zeros((8, self.DOF_T), dtype=np.float64)
        fk = np.zeros((self.DOF_T + 2, 7), dtype=np.float64)
        Js = np.zeros((6, self.DOF_T), order="F", dtype=np.float64)
        q = np.zeros(self.DOF_T, dtype=np.float64)
        return kin, q2, fk, Js, q

    def _define_q_to_frame(self) -> list[str]:
        return [
            # Torso (4 DoF)
            "lifter_pitch_1_link",
            "lifter_pitch_2_link",
            "lifter_pitch_3_link",
            "waist_yaw_link",
            # Left Arm (7 DoF)
            "L_shoulder_pitch_link",
            "L_shoulder_roll_link",
            "L_shoulder_yaw_link",
            "L_elbow_roll_link",
            "L_elbow_yaw_link",
            "L_wrist_pitch_link",
            "L_wrist_roll_link",
            # Right Arm (7 DoF)
            "R_shoulder_pitch_link",
            "R_shoulder_roll_link",
            "R_shoulder_yaw_link",
            "R_elbow_roll_link",
            "R_elbow_yaw_link",
            "R_wrist_pitch_link",
            "R_wrist_roll_link",
        ]

    def get_ik(
        self,
        tf_target: Tf,
        frame: FrameEnumT,
        nb_redundant_search: int = 256,
        range_redundant_last_joint: list | np.ndarray = None,
        which_iks: list[int] = [4, 5, 6, 7],
    ):

        tf44_tool0 = tf_target.matrix.copy(order="C")
        ik_result = {}
        if frame == self.Frames.L_sixforce_link:
            q8 = self._q8_L
            if range_redundant_last_joint is None:
                rlo = self._redundant_L[0]
                rhi = self._redundant_L[1]
            else:
                rlo = range_redundant_last_joint[0]
                rhi = range_redundant_last_joint[1]
            kin = self._kin_L

        elif frame == self.Frames.R_sixforce_link:
            q8 = self._q8_R
            if range_redundant_last_joint is None:
                rlo = self._redundant_R[0]
                rhi = self._redundant_R[1]
            else:
                rlo = range_redundant_last_joint[0]
                rhi = range_redundant_last_joint[1]
            kin = self._kin_R
        else:
            return {}

        qs_search = np.linspace(
            rlo, rhi, nb_redundant_search + 1, True, dtype=np.float64
        )

        for which_ik in which_iks:
            ikq_batch = np.zeros((len(qs_search), self.DOF_A), dtype=np.float64)
            iks_batch = np.zeros(len(qs_search), dtype=bool)
            for iq, ql in enumerate(qs_search):
                q8[:, -1] = ql
                ik_status = kin.ik(tf44_tool0, q8)
                if (ik_status >> which_ik) & 1:
                    iks_batch[iq] = True
                    np.copyto(ikq_batch[iq], q8[which_ik])
            ik_result[which_ik] = (iks_batch.copy(), ikq_batch.copy())
        return ik_result

    # def _define_special_frames(self) -> list[str]:
    #     return ["L_sixforce_link", "R_sixforce_link"]
