from .base import ColObj
import numpy as np

DTypeF = np.float32
DTypeUI = np.uint32
DTypeVert = np.ndarray
import ampl
from .misc import create_xyzr_offset


class CoObjAABB(ColObj):
    def __init__(
        self,
        xyz_min: np.ndarray = np.array([-2, -2, 0], dtype=DTypeF),
        xyz_max: np.ndarray = np.array([2, 2, 3], dtype=DTypeF),
    ):
        super().__init__()
        self.entity_move = ampl.AAABB3()
        self.entity_move.xyz_max = np.array(xyz_max).astype(DTypeF).tolist()
        self.entity_move.xyz_min = np.array(xyz_min).astype(DTypeF).tolist()

    def update_parameter(self, xyz_min: np.ndarray, xyz_max: np.ndarray):
        self.entity_move.xyz_max = np.array(xyz_max).astype(DTypeF).tolist()
        self.entity_move.xyz_min = np.array(xyz_min).astype(DTypeF).tolist()
        return

    @property
    def pose(self):
        return super().pose

    @property
    def xyz_min(self):
        return self.entity_move.xyz_min

    @property
    def xyz_max(self):
        return self.entity_move.xyz_max

    @pose.setter
    def pose(self, rwt: np.ndarray):
        np.copyto(dst=self._pose, src=rwt)


class CoObjOBB(ColObj):
    def __init__(
        self,
        center: np.ndarray,
        half_extents: np.ndarray,
        u: np.ndarray,
        v: np.ndarray,
        w: np.ndarray,
    ):
        super().__init__()
        self.entity = ampl.OBB3()
        self.entity_move = ampl.OBB3()

        self.entity.center = center
        self.entity.half_extents = half_extents
        self.entity.u = u
        self.entity.v = v
        self.entity.w = w
        self.entity_move.center = center
        self.entity_move.half_extents = half_extents
        self.entity_move.u = u
        self.entity_move.v = v
        self.entity_move.w = w

    def update_parameter(
        self,
        center: np.ndarray,
        half_extents: np.ndarray,
        u: np.ndarray,
        v: np.ndarray,
        w: np.ndarray,
    ):
        self.entity.center = center
        self.entity.half_extents = half_extents
        self.entity.u = u
        self.entity.v = v
        self.entity.w = w
        self.entity_move = ampl.OBB3(self.entity)
        return

    @property
    def pose(self):
        return super().pose

    @pose.setter
    def pose(self, rwt: np.ndarray):
        np.copyto(dst=self._pose, src=rwt)
        ampl.collision_transform_object(self.entity, self.entity_move, self._pose)


class ColObjAAABB(ColObj):
    def __init__(
        self,
        xyz_min: np.ndarray = np.array([-2, -2, 0], dtype=DTypeF),
        xyz_max: np.ndarray = np.array([2, 2, 3], dtype=DTypeF),
    ):
        super().__init__()
        self.entity_move = ampl.AAABB3()
        self.entity_move.xyz_max = np.array(xyz_max).astype(DTypeF).tolist()
        self.entity_move.xyz_min = np.array(xyz_min).astype(DTypeF).tolist()

    def update_parameter(self, xyz_min: np.ndarray, xyz_max: np.ndarray):
        self.entity_move.xyz_max = np.array(xyz_max).astype(DTypeF).tolist()
        self.entity_move.xyz_min = np.array(xyz_min).astype(DTypeF).tolist()
        return

    @property
    def pose(self):
        return super().pose

    @property
    def xyz_min(self):
        return self.entity_move.xyz_min

    @property
    def xyz_max(self):
        return self.entity_move.xyz_max

    @pose.setter
    def pose(self, rwt: np.ndarray):
        np.copyto(dst=self._pose, src=rwt)


class ColObjVSph(ColObj):
    def __init__(self, list_xyzr: list[list[float]]):
        super().__init__()
        xyzr, offset = create_xyzr_offset(list_xyzr)
        self.entity = ampl.VSphG8f()
        self.entity_move = ampl.VSphG8f()
        ampl.collision_initialize_object(xyzr, offset, self.entity)
        ampl.collision_initialize_object(xyzr, offset, self.entity_move)
        self.centers = np.zeros((self.entity.nb_sph, 3), dtype=DTypeF)
        self.grads = np.zeros((self.entity.nb_sph, 3), dtype=DTypeF)
        self.dists = np.zeros(self.entity.nb_sph, dtype=DTypeF)
        self.labels = np.zeros(self.entity.nb_sph, dtype=DTypeUI)

    def set_pose(self, rwt: np.ndarray, ids_row_rwt: list[int]):
        for i_rwt in ids_row_rwt:
            ampl.collision_transform_object(
                self.entity, self.entity_move, i_rwt, rwt[i_rwt].astype(DTypeF)
            )
