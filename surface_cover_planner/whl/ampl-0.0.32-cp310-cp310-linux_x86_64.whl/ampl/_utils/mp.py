import numpy as np
from typing import Callable, List, Tuple, Optional, Dict
import ampl
from .base import MP
from .rrt import RRTTree, RRTNode, ExtendStatus


def sample_trajectory_trivial(
    q_start: np.ndarray,
    q_end: np.ndarray,
    n: int = 5,
    include_start=False,
    inclue_end=True,
) -> np.ndarray:
    return np.linspace(q_start, q_end, n + 2, endpoint=True)[
        not include_start : n + 2 - (not inclue_end)
    ]


class MPRRTC(MP):
    def __init__(
        self,
        bounds: list[tuple[float, float]],
        collision_fn: Callable[[np.ndarray], bool],
        step_size: float = 0.1,
        max_extend_dist=0.5,
        frozen_dofs: Optional[Dict[int, float]] = None,
    ):
        self.full_bounds = np.array(bounds)
        self.full_dim = len(bounds)
        self.collision_fn = collision_fn
        self.step_size = step_size
        self.frozen_dofs = frozen_dofs if frozen_dofs is not None else {}
        self.active_indices = [
            i for i in range(self.full_dim) if i not in self.frozen_dofs
        ]
        self.active_dim = len(self.active_indices)
        self.active_bounds = self.full_bounds[self.active_indices]

        self.max_extend_dist = max_extend_dist
        self.nb_shortcut_subd = 1

    def _get_full_state(self, active_state: np.ndarray) -> np.ndarray:
        full_state = np.zeros(self.full_dim)
        full_state[self.active_indices] = active_state
        for idx, val in self.frozen_dofs.items():
            full_state[idx] = val
        return full_state

    def _extract_active_state(self, full_state: np.ndarray) -> np.ndarray:
        return full_state[self.active_indices]

    def sample_active_state(self) -> np.ndarray:
        return np.random.uniform(self.active_bounds[:, 0], self.active_bounds[:, 1])

    def is_state_valid(self, active_state: np.ndarray) -> bool:
        full_state = self._get_full_state(active_state)
        return not self.collision_fn(full_state)

    def is_path_valid(
        self, active_state1: np.ndarray, active_state2: np.ndarray
    ) -> bool:
        dist = np.linalg.norm(active_state2 - active_state1)
        if dist < 5e-2:
            return self.is_state_valid(active_state1)

        num_steps = int(np.ceil(dist / self.step_size))
        # print(num_steps)
        trajectory = sample_trajectory_trivial(
            active_state1, active_state2, num_steps, False, True
        )
        for interp_state in trajectory[0:-1:2]:
            if not self.is_state_valid(interp_state):
                return False

        for interp_state in trajectory[1:-1:2]:
            if not self.is_state_valid(interp_state):
                return False
        # for i in range(num_steps + 1):
        #     interp_state = active_state1 + (active_state2 - active_state1) * (
        #         i / num_steps
        #     )
        #     if not self.is_state_valid(interp_state):
        #         return False
        return True

    def _extend(
        self, tree: RRTTree, target_state: np.ndarray
    ) -> tuple[ExtendStatus, RRTNode]:
        """Takes a single step from the nearest node in the tree toward the target."""
        nearest_node = tree.get_nearest(target_state)
        direction = target_state - nearest_node.state
        dist = np.linalg.norm(direction)

        if dist > self.max_extend_dist:
            new_state = nearest_node.state + (direction / dist) * self.max_extend_dist
            status = ExtendStatus.ADVANCED
        else:
            new_state = target_state
            status = ExtendStatus.REACHED

        if self.is_path_valid(nearest_node.state, new_state):
            new_node = RRTNode(new_state)
            new_node.parent = nearest_node
            tree.add_node(new_node)
            return status, new_node

        return ExtendStatus.TRAPPED, nearest_node

    # def _connect(
    #     self, tree: RRTTree, target_state: np.ndarray
    # ) -> Tuple[ExtendStatus, RRTNode]:
    #     """Repeatedly extends the tree toward the target until reached or trapped."""
    #     while True:
    #         status, new_node = self._extend(tree, target_state)
    #         if status != ExtendStatus.ADVANCED:
    #             return status, new_node

    def _connect(
        self, tree: RRTTree, target_state: np.ndarray
    ) -> tuple[ExtendStatus, RRTNode]:
        """Optimized connect that bypasses redundant spatial index queries."""
        # Query the R-Tree exactly ONCE
        current_node = tree.get_nearest(target_state)

        while True:
            direction = target_state - current_node.state
            dist = np.linalg.norm(direction)

            if dist > self.max_extend_dist:
                new_state = (
                    current_node.state + (direction / dist) * self.max_extend_dist
                )
                status = ExtendStatus.ADVANCED
            else:
                new_state = target_state
                status = ExtendStatus.REACHED

            # Check validity of this specific step
            if self.is_path_valid(current_node.state, new_state):
                new_node = RRTNode(new_state)
                new_node.parent = current_node

                # Add to tree and shift our reference point forward
                tree.add_node(new_node)
                current_node = new_node

                if status == ExtendStatus.REACHED:
                    return status, current_node
            else:
                # Hit an obstacle
                return ExtendStatus.TRAPPED, current_node

    def _extract_path(
        self, node_a: RRTNode, node_b: RRTNode, is_tree_a_start: bool
    ) -> list[np.ndarray]:
        """Traces back through parents to reconstruct the full path."""

        def trace_to_root(node):
            path = []
            current = node
            while current is not None:
                path.append(current.state)
                current = current.parent
            return path

        path_a = trace_to_root(node_a)
        path_b = trace_to_root(node_b)

        if is_tree_a_start:
            active_path = path_a[::-1] + path_b[1:]
        else:
            active_path = path_b[::-1] + path_a[1:]

        return [self._get_full_state(state) for state in active_path]

    def _sample_active_state_bridge(
        self, std_dev: float = 0.5, attempts: int = 10
    ) -> np.ndarray:
        """
        Attempts to find a 'bridge' in a narrow passage.
        Falls back to uniform sampling if it fails.
        """
        for _ in range(attempts):
            # 1. Sample a random uniform state
            q1 = np.random.uniform(self.active_bounds[:, 0], self.active_bounds[:, 1])

            # 2. We only proceed if q1 is IN COLLISION
            if not self.is_state_valid(q1):

                # 3. Sample a second state nearby using a Gaussian distribution
                q2 = np.random.normal(loc=q1, scale=std_dev)

                # Clamp q2 to bounds
                q2 = np.clip(q2, self.active_bounds[:, 0], self.active_bounds[:, 1])

                # 4. We only proceed if q2 is ALSO IN COLLISION
                if not self.is_state_valid(q2):

                    # 5. Check the midpoint!
                    q_mid = (q1 + q2) / 2.0
                    if self.is_state_valid(q_mid):
                        return q_mid  # Found a narrow passage!

        # Fallback: Just return a standard uniform sample
        return np.random.uniform(self.active_bounds[:, 0], self.active_bounds[:, 1])

    def plan(
        self,
        full_start: np.ndarray,
        full_goal: np.ndarray,
        max_iterations: int = 1000,
        ignore_start_and_goal=False,
    ) -> List[np.ndarray] | None:
        start_active = self._extract_active_state(full_start)
        goal_active = self._extract_active_state(full_goal)

        if not ignore_start_and_goal:
            if not self.is_state_valid(start_active):
                print("Start is in collision!")
                return None

            if not self.is_state_valid(goal_active):
                print("Goal  is in collision!")
                return None
        if self.is_path_valid(start_active, goal_active):
            print("Direct path is free! Skipping tree generation.")
            return [
                self._get_full_state(start_active),
                self._get_full_state(goal_active),
            ]
        tree_a = RRTTree(self.active_dim)
        tree_b = RRTTree(self.active_dim)

        tree_a.add_node(RRTNode(start_active))
        tree_b.add_node(RRTNode(goal_active))

        is_tree_a_start = True

        for _ in range(max_iterations):
            q_rand = self.sample_active_state()

            # 1. Extend Tree A
            status_a, new_node_a = self._extend(tree_a, q_rand)

            if status_a != ExtendStatus.TRAPPED:
                # 2. Try to connect Tree B to the new node in Tree A
                status_b, new_node_b = self._connect(tree_b, new_node_a.state)

                if status_b == ExtendStatus.REACHED:
                    # Trees connected successfully!
                    return self._extract_path(new_node_a, new_node_b, is_tree_a_start)

            # 3. Swap trees
            if len(tree_a.nodes) > len(tree_b.nodes):
                # if 1:
                # print("wtwtw")
                tree_a, tree_b = tree_b, tree_a
                is_tree_a_start = not is_tree_a_start

        print("Failed to connect trees within max iterations.")
        return None

    def shortcut(self, waypoints_feasible: np.ndarray) -> list[np.ndarray] | None:
        nb_subdivision_internal = self.nb_shortcut_subd

        active_traj = np.array(
            [self._extract_active_state(q) for q in waypoints_feasible]
        )

        graph, graph_waypoints = ampl.graph_from_polyline(
            active_traj, nb_subdivision_internal
        )
        nb_node = len(graph_waypoints)
        for i in range(0, nb_node - (nb_subdivision_internal + 1)):
            for j in range(i + (nb_subdivision_internal + 1), nb_node, 3):
                if self.is_path_valid(
                    graph_waypoints[i].copy(), graph_waypoints[j].copy()
                ):
                    wij = np.linalg.norm(
                        graph_waypoints[j].copy() - graph_waypoints[i].copy()
                    )
                    graph[i].append((j, wij))
        new_path_len, new_path = ampl.graph_dijkstra_single(
            graph, nb_node, 0, nb_node - 1
        )

        active_traj_shortcut = graph_waypoints[new_path].copy()

        print(
            "c-space length before =",
            np.linalg.norm(active_traj[:-1] - active_traj[1:], axis=1).sum(),
        )
        print(
            "c-space length after  =",
            np.linalg.norm(
                active_traj_shortcut[:-1] - active_traj_shortcut[1:], axis=1
            ).sum(),
        )

        return [self._get_full_state(state) for state in active_traj_shortcut]
