import numpy as np
import ampl
from .base import Col
from .colobj import *


class EntityRecord:
    """Stores the overarching state of an object and pointers to its components."""

    def __init__(self, pose):
        self.pose = np.array(pose, dtype=np.float32)
        self.hull_idx = None  # Index in the C++ hull_groups array
        self.pc_idx = None  # Index in the local_point_clouds array


class ColConvex(Col):
    def __init__(self):
        self.entities: dict[str, EntityRecord] = {}  #

        self.tree = ampl.DynamicTree3D()
        self.hull_groups: list[ampl.VSCHf] = []
        self.proxies = []
        self.hull_idx_to_entity = []

        # Python ID Mapping
        self.local_pcs = []
        self.pc_idx_to_entity = []

        self.disabled_collision_pairs = set()
        self._cached_ignored_keys = []
        self._dirty_ignored_keys = True  # Start dirty

        # self._workspace_entities: list[str] = []
        self._workspace_hull_ids: list[int] = []
        self.workspace_aabb: ampl.AABB3D = None

    # ==========================================
    # DICTIONARY MAGIC METHODS
    # ==========================================
    def __getitem__(self, entity_id: str) -> ampl.VSCHf:
        """Allows access via physics['Ship']"""
        if entity_id not in self.entity_to_index:
            raise KeyError(f"Entity '{entity_id}' not found in collision system.")
        idx = self.entity_to_index[entity_id]
        return self.hull_groups[idx]

    def __contains__(self, entity_id: str) -> bool:
        """Allows checking via 'Ship' in physics"""
        return entity_id in self.entity_to_index

    def __len__(self) -> int:
        """Allows checking size via len(physics)"""
        return len(self.hull_groups)

    def disable_collision(self, entity_a: str, entity_b: str):
        """Instructs the broad-phase to ignore collisions between these two entities."""
        self.disabled_collision_pairs.add(frozenset([entity_a, entity_b]))
        self._dirty_ignored_keys = True  # Invalidate cache

    def enable_collision(self, entity_a: str, entity_b: str):
        """Re-enables collision checking between two entities."""
        pair = frozenset([entity_a, entity_b])
        if pair in self.disabled_collision_pairs:
            self.disabled_collision_pairs.discard(pair)
            self._dirty_ignored_keys = True  # Invalidate cache

    # ==========================================
    # CORE API
    # ==========================================
    def add(
        self,
        entity_id: str,
        pose: np.ndarray = np.array([0, 0, 0, 1, 0, 0, 0], dtype=np.float32),
        cvh_group: ampl.VSCHf = None,
        local_pc: np.ndarray = None,
    ):
        """
        Adds an entity to the manager with optional physics and planning components.
        pose format: [qw, qx, qy, qz, tx, ty, tz]
        """
        if entity_id in self.entities:
            raise ValueError(f"Entity '{entity_id}' already exists.")

        record = EntityRecord(pose)
        self.entities[entity_id] = record

        # --- Subscribe to Collision System ---
        if cvh_group is not None:
            record.hull_idx = len(self.hull_groups)
            self.hull_idx_to_entity.append(entity_id)
            self.hull_groups.append(cvh_group)

            # Init pose and tree proxy
            cvh_group.pose = pose
            cvh_group.batch_update_world_spheres()
            x, y, z, r = cvh_group.world_master_sph

            aabb = ampl.AABB3D()
            aabb.min = [x - r, y - r, z - r]
            aabb.max = [x + r, y + r, z + r]
            self.proxies.append(self.tree.create_proxy(aabb, record.hull_idx))
            self._dirty_ignored_keys = True

        # --- Subscribe to Point Cloud System ---
        if local_pc is not None:
            record.pc_idx = len(self.local_pcs)
            self.pc_idx_to_entity.append(entity_id)
            self.local_pcs.append(local_pc.astype(np.float32))

    def update_pose(self, entity_id: str, pose_array):
        """Updates the entity pose and instantly syncs active components."""
        record = self.entities.get(entity_id)
        if not record:
            return

        record.pose = np.array(pose_array, dtype=np.float32)

        # 1. Sync Collision System (O(1) update)
        if record.hull_idx is not None:
            group = self.hull_groups[record.hull_idx]
            group.pose = pose_array
            group.batch_update_world_spheres()

            x, y, z, r = group.world_master_sph
            aabb = ampl.AABB3D()
            aabb.min = [x - r, y - r, z - r]
            aabb.max = [x + r, y + r, z + r]
            self.tree.update_proxy(self.proxies[record.hull_idx], aabb)

    def get_scene_point_cloud(self, include=None, exclude=None) -> np.ndarray:
        """
        Transforms and concatenates point clouds based on current poses.

        :param include: If provided, ONLY these entity IDs will be included.
        :param exclude: If provided, these entity IDs will be skipped.
        :return: An (M, 3) numpy array of world-space points.
        """
        if not self.local_pcs:
            return np.empty((0, 3), dtype=np.float32)

        # Convert to sets for lightning-fast O(1) lookups
        include_set = set(include) if include is not None else None
        exclude_set = set(exclude) if exclude is not None else set()

        world_clouds = []
        for i, local_pc in enumerate(self.local_pcs):
            entity_id = self.pc_idx_to_entity[i]

            # --- FILTERING LOGIC ---
            if include_set is not None and entity_id not in include_set:
                continue
            if entity_id in exclude_set:
                continue

            # --- TRANSFORMATION LOGIC ---
            world_pc = np.zeros_like(local_pc, dtype=np.float32)
            ampl.transform_xyz(
                local_pc, world_pc, self.entities[entity_id].pose.astype(np.float32)
            )
            world_clouds.append(world_pc)

            # world_clouds.append(world_pc)

        # Handle the case where everything was filtered out
        if not world_clouds:
            return np.empty((0, 3), dtype=np.float32)

        return np.vstack(world_clouds)

    def process_collisions(self):
        """
        Executes the C++ pipeline and returns exact GJK pairs mapped to Entity IDs.
        """
        if self._dirty_ignored_keys:
            self._rebuild_ignored_keys_cache()

        # 2. Pass the CACHED sorted keys to the C++ backend ($O(1)$ Python overhead)
        raw_pairs = ampl.get_gjk_collision_pairs(
            self.tree, self.proxies, self.hull_groups, self._cached_ignored_keys
        )
        # raw_pairs = ampl.get_gjk_collision_pairs(
        #     self.tree, self.proxies, self.hull_groups
        # )
        # print(self.proxies)

        results = []
        for id_a, comp_a, id_b, comp_b in raw_pairs:
            entity_a = self.hull_idx_to_entity[id_a]
            entity_b = self.hull_idx_to_entity[id_b]
            results.append((entity_a, comp_a, entity_b, comp_b))

        return results

    def remove(self, entity_id: str):
        record = self.entities.pop(entity_id, None)
        if not record:
            return

        # --- Remove from Collision System ---
        if record.hull_idx is not None:
            idx = record.hull_idx
            last_idx = len(self.hull_groups) - 1
            last_ent = self.hull_idx_to_entity[last_idx]

            # 1. Destroy C++ Proxy
            self.tree.destroy_proxy(self.proxies[idx])

            # 2. CACHE FIX: Remove the dead index from the workspace cache FIRST
            if idx in self._workspace_hull_ids:
                self._workspace_hull_ids.remove(idx)

            # 3. Swap and Pop
            if idx != last_idx:
                # Move the last element into the deleted slot
                self.hull_groups[idx] = self.hull_groups[last_idx]
                self.proxies[idx] = self.proxies[last_idx]
                self.hull_idx_to_entity[idx] = last_ent

                # Update the moved entity's record
                self.entities[last_ent].hull_idx = idx

                # Update the C++ tree node's internal ID
                self.proxies[idx].entityID = idx

                # 4. CACHE FIX: Now safely update the moved item's ID in the cache
                if last_idx in self._workspace_hull_ids:
                    cache_pos = self._workspace_hull_ids.index(last_idx)
                    self._workspace_hull_ids[cache_pos] = idx

            # Pop the trailing duplicates
            self.hull_groups.pop()
            self.proxies.pop()
            self.hull_idx_to_entity.pop()
            self._dirty_ignored_keys = True

        # --- Remove from Point Cloud System ---
        if record.pc_idx is not None:
            idx = record.pc_idx
            last_idx = len(self.local_pcs) - 1
            last_ent = self.pc_idx_to_entity[last_idx]

            if idx != last_idx:
                self.local_pcs[idx] = self.local_pcs[last_idx]
                self.pc_idx_to_entity[idx] = last_ent
                self.entities[last_ent].pc_idx = idx

            self.local_pcs.pop()
            self.pc_idx_to_entity.pop()

    # def remove(self, entity_id: str):
    #     """Safely removes an entity from all systems it is subscribed to."""
    #     record = self.entities.pop(entity_id, None)
    #     if not record:
    #         return

    #     # --- Remove from Collision System ---
    #     if record.hull_idx is not None:
    #         idx = record.hull_idx
    #         last_idx = len(self.hull_groups) - 1
    #         last_ent = self.hull_idx_to_entity[last_idx]

    #         self.tree.destroy_proxy(self.proxies[idx])

    #         if idx != last_idx:
    #             self.hull_groups[idx] = self.hull_groups[last_idx]
    #             self.proxies[idx] = self.proxies[last_idx]
    #             self.hull_idx_to_entity[idx] = last_ent

    #             # Update the swapped entity's record and tree proxy
    #             self.entities[last_ent].hull_idx = idx
    #             self.proxies[idx].entityID = idx

    #         self.hull_groups.pop()
    #         self.proxies.pop()
    #         self.hull_idx_to_entity.pop()
    #         self._dirty_ignored_keys = True

    #     # --- Remove from Point Cloud System ---
    #     if record.pc_idx is not None:
    #         idx = record.pc_idx
    #         last_idx = len(self.local_pcs) - 1
    #         last_ent = self.pc_idx_to_entity[last_idx]

    #         if idx != last_idx:
    #             self.local_pcs[idx] = self.local_pcs[last_idx]
    #             self.pc_idx_to_entity[idx] = last_ent
    #             self.entities[last_ent].pc_idx = idx

    #         self.local_pcs.pop()
    #         self.pc_idx_to_entity.pop()

    def _rebuild_ignored_keys_cache(self):
        """Internal helper to compile the 64-bit keys only when needed."""
        ignored_keys = []
        for ent_a, ent_b in self.disabled_collision_pairs:
            rec_a = self.entities.get(ent_a)
            rec_b = self.entities.get(ent_b)

            # Only ignore if BOTH entities are currently active in the physics system
            if (
                rec_a
                and rec_b
                and rec_a.hull_idx is not None
                and rec_b.hull_idx is not None
            ):
                min_idx = min(rec_a.hull_idx, rec_b.hull_idx)
                max_idx = max(rec_a.hull_idx, rec_b.hull_idx)

                # Bitwise shift to create the exact same 64-bit key as C++
                pair_key = (min_idx << 32) | max_idx
                ignored_keys.append(pair_key)

        # Sort the keys (Required for C++ std::binary_search)
        ignored_keys.sort()
        self._cached_ignored_keys = ignored_keys
        self._dirty_ignored_keys = False

    def get_world_vertices(self, entity_id: str, comp_idx: int):
        """Lazy-evaluates and returns the (N,3) convex hull vertices."""
        hull_idx = self.entities[entity_id].hull_idx
        return self.hull_groups[hull_idx].get_world_hull_array(comp_idx)

    # ==========================================
    # WORKSPACE CONSTRAINTS
    # ==========================================

    def configure_workspace(
        self,
        entity_ids: list[str] = None,
        workspace_min: list[float] = None,
        workspace_max: list[float] = None,
    ):
        """
        Configures the workspace bounds and caches the exact integer hull_idx
        for lightning-fast memory access during the safety check.
        """
        # 1. Resolve strings to integer IDs exactly ONCE
        if entity_ids is not None:
            new_hull_ids = []
            for ent_id in entity_ids:
                if ent_id not in self.entities:
                    raise KeyError(f"Entity '{ent_id}' not found in the system.")

                hull_idx = self.entities[ent_id].hull_idx
                if hull_idx is None:
                    raise ValueError(f"Entity '{ent_id}' lacks a collision hull.")

                new_hull_ids.append(hull_idx)

            self._workspace_hull_ids = new_hull_ids

        # 2. Build or update the internal AABB3D object
        if workspace_min is not None and workspace_max is not None:
            if self.workspace_aabb is None:
                self.workspace_aabb = ampl.AABB3D()
            self.workspace_aabb.min = workspace_min
            self.workspace_aabb.max = workspace_max

        elif workspace_min is not None or workspace_max is not None:
            raise ValueError("You must provide BOTH workspace_min and workspace_max.")

    def is_workspace_safe(self) -> bool:
        """
        Returns True if ALL registered workspace entities are fully contained
        inside the cached AABB. Returns False the instant any link pokes outside.
        """
        if not self._workspace_hull_ids:
            return True  # Trivially safe if no arms are registered

        if self.workspace_aabb is None:
            raise RuntimeError(
                "Cannot check safety: Workspace AABB has not been configured."
            )
        # print(self._workspace_entities)

        violating_proxies = self.tree.query_exterior(self.workspace_aabb)
        intersection_set = set(violating_proxies) & set(self._workspace_hull_ids)
        # print(violating_proxies,self._workspace_hull_ids)

        for id in intersection_set:
            if ampl.collision_check_aaabb3_vsch(
                self.workspace_aabb.min,
                self.workspace_aabb.max,
                self.hull_groups[id],
            ):
                return False
        return True
