import numpy as np
import ampl
from ampl import Tf
from abc import ABC, abstractmethod
from enum import Enum
from typing import TypeVar, Any, Type
import numpy.typing as npt

FrameEnumT = TypeVar("FrameEnumT", bound=Enum)


class Kin(ABC):
    @abstractmethod
    def update_kin(
        self, q: np.ndarray, pose_base: Tf = None, update_jacobian: bool = False
    ) -> None:
        pass

    @abstractmethod
    def get_limits(self) -> tuple[np.ndarray, np.ndarray]:
        pass

    @abstractmethod
    def get_fk_actuated_frame(self) -> np.ndarray:
        pass

    @abstractmethod
    def get_jacobian_actuated_frame(self) -> np.ndarray:
        pass

    @abstractmethod
    def get_fk(self, frame: FrameEnumT) -> Tf:
        pass

    @abstractmethod
    def get_base(self) -> Tf:
        pass

    @abstractmethod
    def get_actuated_frames(self) -> list[str]:
        pass

    @abstractmethod
    def get_ik(self, frame: FrameEnumT) -> dict:
        pass

    @abstractmethod
    def get_jacobian(self, frame: FrameEnumT) -> npt.NDArray[np.float64]:
        pass


class MP(ABC):
    @abstractmethod
    def plan(
        self, full_start: np.ndarray, full_goal: np.ndarray, max_iterations: int = 1000
    ) -> list[np.ndarray] | None:
        pass

    @abstractmethod
    def shortcut(self, waypoints_feasible: np.ndarray) -> list[np.ndarray]:
        pass


class Traj(ABC):
    @abstractmethod
    def update_param(self, waypoints: list[np.ndarray] | np.ndarray):
        pass

    @property
    @abstractmethod
    def arc_length(self):
        pass

    @abstractmethod
    def evaluate(self, s: float | np.ndarray) -> np.ndarray:
        pass


class Col(ABC):
    """
    Lightweight interface for managing rigid-body collision detection
    and workspace safety constraints.
    """

    @abstractmethod
    def add(self, entity_id: str, pose: np.ndarray, **kwargs: Any) -> None:
        """
        Registers an entity in the physics world.
        The geometry payload (convex hulls, meshes, point clouds) is passed via kwargs
        to keep the interface decoupled from specific backend implementations.
        """
        pass

    @abstractmethod
    def remove(self, entity_id: str) -> None:
        """Removes the entity from the collision tree and all internal caches."""
        pass

    @abstractmethod
    def update_pose(self, entity_id: str, pose: np.ndarray) -> None:
        """Updates the kinematic state of an entity. Must be O(1) or highly optimized."""
        pass

    @abstractmethod
    def process_collisions(self) -> list[tuple[str, int, str, int]]:
        """
        Executes the narrow-phase collision check.
        Returns a list of colliding pairs: (EntityA, CompA, EntityB, CompB).
        """
        pass

    @abstractmethod
    def configure_workspace(
        self,
        entity_ids: list[str] | None,
        workspace_min: list[float] = None,
        workspace_max: list[float] = None,
    ) -> None:
        """Configures the safe workspace boundary and the entities bound to it."""
        pass

    @abstractmethod
    def is_workspace_safe(self) -> bool:
        """Returns True if all bound entities are strictly inside the workspace boundary."""
        pass

    @abstractmethod
    def disable_collision(self, entity_a: str, entity_b: str) -> None:
        """Instructs the broad-phase to ignore collisions between these two entities."""
        pass

    @abstractmethod
    def enable_collision(self, entity_a: str, entity_b: str) -> None:
        """Re-enables collision checking between two entities."""
        pass


class ColObj:
    """
    Collision Ojbect Base
    """

    def __init__(self):
        self.entity = None
        self.entity_move = None
        self._pose = np.array([0, 0, 0, 1, 0, 0, 0], dtype=np.float32)
        self.active = False

    def update_parameter(self):
        return

    @property
    def pose(self):
        return self._pose

    @pose.setter
    def pose(self, rwt: np.ndarray):
        np.copyto(dst=self._pose, src=rwt)


class WBC(ABC):
    # _QPSolver: Type["ampl.DAQPSolver7" | "ampl.DAQPSolver18"]
    # _Controller: Type["ampl.Controller7" | "ampl.Controller18"]
    # _LinearVelTask: Type["ampl.LinearVelTask7" | "ampl.LinearVelTask18"]
    # _AngularVelTask: Type["ampl.AngularVelTask7" | "ampl.AngularVelTask18"]
    # _JointVelocityLimitConstraint: Type[
    #     "ampl.JointVelocityLimitConstraint7" | "ampl.JointVelocityLimitConstraint18"
    # ]

    def __init__(self, dof: int):
        """
        Initialize the WBC abstraction.

        :param wbc_module: The compiled C++ nanobind module (e.g., wbc_py).
        :param dof: The total degrees of freedom (e.g., 9).
        """

        self.dof = dof
        # 1. Dynamically load the C++ classes based on the given DOF
        self._load_bindings()

        # 2. Instantiate core solver and controller
        self.solver = self._QPSolver()
        self.controller = self._Controller(self.solver)

        # 3. Storage for tasks and constraints
        self.tasks = {}
        self.constraints = {}

    def _load_bindings(self):
        """Fetches the correct C++ classes using getattr and the dof suffix."""
        if 1:
            # Core
            self._QPSolver = getattr(ampl, f"DAQPSolver{self.dof}")
            self._Controller = getattr(ampl, f"Controller{self.dof}")

            # Tasks
            # self._DampingTask = getattr(ampl, f"DampingTask{self.dof}")
            self._LinearVelTask = getattr(ampl, f"LinearVelTask{self.dof}")
            self._AngularVelTask = getattr(ampl, f"AngularVelTask{self.dof}")

            # self._CartesianVelConstraint = getattr(
            #     ampl, f"CartesianVelocityConstraint{self.dof}"
            # )
            # self._CollisionBarrierConstraint = getattr(
            #     ampl, f"CollisionBarrierConstraint{self.dof}"
            # )
            # Note: Retained the typo "Veclocity" to match your C++ bindings
            self._JointVelocityLimitConstraint = getattr(
                ampl, f"JointVelocityLimitConstraint{self.dof}"
            )

    # ==========================================
    # Abstract Methods
    # ==========================================

    # @abstractmethod
    # def setup_tasks(self):
    #     """Define and add all required tasks to the controller."""
    #     pass

    # @abstractmethod
    # def setup_constraints(self):
    #     """Define and add all required constraints to the controller."""
    #     pass

    @abstractmethod
    def update(self, *args, **kwargs):
        """Update tasks and constraints with the latest state (q, q_dot, jacobians)."""
        pass

    # ==========================================
    # Concrete Utility Methods
    # ==========================================

    def solve(self):
        """Solve the QP problem and return the joint velocities."""
        q_dot = self.controller.solve()
        status = self.controller.solver_status()
        return q_dot, status


# class RobotInterface(Col, Kin, ABC):
