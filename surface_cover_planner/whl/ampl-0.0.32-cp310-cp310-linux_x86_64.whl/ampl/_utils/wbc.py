import numpy as np
import ampl
from .base import WBC, Kin
import json
from abc import ABC, abstractmethod
from .misc import spatial_to_mixed_linear_fast
from typing import Dict, Any, Optional

DTypeD = np.float64


class WBIK:
    def __init__(self, dof: int):
        self.dof = dof
        self.linear_tasks: Dict[str, ampl.WBCLinearVelTask] = {}
        self.angular_tasks: Dict[str, ampl.WBCAngularVelTask] = {}
        self.swivel_tasks: Dict[str, ampl.WBCSwivelVelTask] = {}
        self.reg_tasks: Dict[str, ampl.WBCJointRegularizationTask] = {}
        self.joint_limits: Dict[str, ampl.WBCJointVelocityLimitConstraint] = {}
        self.linear_limits: Dict[str, ampl.WBCLinearVelConstraint] = {}
        self.collision_limits: Dict[str, ampl.WBCCollisionBarrierConstraint] = {}
        self.repulsion_tasks: Dict[str, ampl.WBCContactRepTask] = {}

        # ==========================================
        # 2. DYNAMIC GETATTR FACTORY ROUTING
        # ==========================================
        try:
            # Core Solvers
            self._SolverClass = getattr(ampl, f"DAQPSolver{dof}")
            self._ControllerClass = getattr(ampl, f"Controller{dof}")

            # Tasks
            self._LinearTaskClass = getattr(ampl, f"LinearVelTask{dof}")
            self._AngularTaskClass = getattr(ampl, f"AngularVelTask{dof}")
            self._SwivelTaskClass = getattr(ampl, f"SwivelVelTask{dof}")
            self._RegTaskClass = getattr(ampl, f"JointRegularizationTask{dof}")
            self._RepulsionClass = getattr(ampl, f"ContactRepTask{dof}")

            # Constraints
            self._JointLimitClass = getattr(ampl, f"JointVelocityLimitConstraint{dof}")
            self._LinearLimitClass = getattr(ampl, f"LinearVelConstraint{dof}")
            self._CollisionClass = getattr(ampl, f"CollisionBarrierConstraint{dof}")

        except AttributeError:
            # If getattr fails to find the class, it means the C++ binding for this DOF doesn't exist
            raise ValueError(
                f"WBC classes for {dof} DOF not found in 'ampl' module. Did you compile them?"
            )

        # Instantiate core solver
        self.solver: ampl.WBCDAQPSolver = self._SolverClass()
        self.controller: ampl.WBCController = self._ControllerClass(self.solver, 100)

    def _parse_blocks(
        self, block_data: list[dict[str, int]]
    ) -> list[ampl.KinematicBlock]:
        return [
            ampl.KinematicBlock(b["local_start"], b["global_start"], b["size"])
            for b in block_data
        ]

    def load_config(self, config: Dict[str, Any]):
        """Parses the JSON: Topology first, then Tasks/Constraints."""

        # ------------------------------------------
        # 1. LOAD TOPOLOGY (CRITICAL: MUST BE FIRST)
        # ------------------------------------------
        if "topology" in config:
            topo = config["topology"]

            # Safely cast JSON lists to tuples for nanobind's std::pair
            raw_regions = topo["macro_regions"]

            parsed_regions = [
                [(int(block[0]), int(block[1])) for block in region]
                for region in raw_regions
            ]
            # print(parsed_regions)

            # Pass directly to C++ Controller
            self.controller.init_topology(
                parsed_regions, topo["joint_to_region"], topo.get("id_to_col_shift", 0)
            )
        else:
            raise ValueError(
                "[WBC] JSON Configuration is missing the required 'topology' block."
            )

        # ------------------------------------------
        # LOAD TASKS
        # ------------------------------------------
        if "tasks" in config:
            for t_type, task_group in config["tasks"].items():
                for name, params in task_group.items():

                    if t_type == "LinearVelTask":
                        blocks = self.controller.get_blocks_for_joint(
                            params["joint_id"]
                        )
                        obj = self._LinearTaskClass(blocks, params["weight"])
                        self.linear_tasks[name] = obj
                        self.controller.add_task(obj)

                    elif t_type == "AngularVelTask":
                        blocks = self.controller.get_blocks_for_joint(
                            params["joint_id"]
                        )
                        obj = self._AngularTaskClass(blocks, params["weight"])
                        self.angular_tasks[name] = obj
                        self.controller.add_task(obj)

                    elif t_type == "SwivelVelTask":
                        blocks = self.controller.get_blocks_for_joint(
                            params["joint_id"]
                        )
                        obj = self._SwivelTaskClass(blocks, params["weight"])
                        self.swivel_tasks[name] = obj
                        self.controller.add_task(obj)

                    elif t_type == "JointRegularizationTask":
                        obj = self._RegTaskClass(
                            params["dq"],
                            params["ddq"],
                            params["dddq"],
                            params.get("dt", 0.001),
                        )
                        if "multipliers" in params:
                            obj.set_joint_multipliers(
                                np.array(params["multipliers"], dtype=np.float64)
                            )
                        self.reg_tasks[name] = obj
                        self.controller.add_task(obj)

                    elif t_type == "ContactRepTask":
                        obj = self._RepulsionClass(params["max_collisions"])
                        self.repulsion_tasks[name] = obj
                        self.controller.add_task(obj)

        # ------------------------------------------
        # LOAD CONSTRAINTS
        # ------------------------------------------
        if "constraints" in config:
            for c_type, constraint_group in config["constraints"].items():
                for name, params in constraint_group.items():
                    if c_type == "JointVelocityLimitConstraint":
                        q_min = np.array(params["q_min"], dtype=np.float64)
                        q_max = np.array(params["q_max"], dtype=np.float64)
                        v_lim = np.array(params["v_limit"], dtype=np.float64)
                        obj = self._JointLimitClass(
                            q_min, q_max, v_lim, params.get("dt", 0.001)
                        )
                        self.joint_limits[name] = obj
                        self.controller.add_constraint(obj)
                    elif c_type == "CollisionBarrierConstraint":
                        obj = self._CollisionClass(
                            params["max_collisions"], params["gamma"], params["d_safe"]
                        )
                        self.collision_limits[name] = obj
                        self.controller.add_constraint(obj)

    def load_config_from_file(self, filepath: str):
        with open(filepath, "r") as f:
            self.load_config(json.load(f))


class WBC277(WBIK):
    def __init__(self, config: dict):
        super().__init__(16)
        if config:
            self.load_config(config)
        self._v_goal_L: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._v_goal_R: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._w_goal_L: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._w_goal_R: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._fk = np.zeros((self.dof, 7), dtype=DTypeD, order="C")
        self._Js = np.zeros((6, self.dof), dtype=DTypeD, order="F")
        self._q_curr = np.zeros(self.dof, dtype=DTypeD)
        if "self_collision" in self.collision_limits:
            NB_SELF_COLLISION = self.collision_limits["self_collision"].max_collisions
            self._d_cbf = np.zeros(NB_SELF_COLLISION, dtype=np.float64)
            self._J_cbf = np.zeros(
                (NB_SELF_COLLISION, self.dof), dtype=np.float64, order="F"
            )


class WBCT77(WBIK):
    def __init__(self, config: dict, dof_torso: int):
        super().__init__(dof_torso + 14)
        if config:
            self.load_config(config)
        self._v_goal_L: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._v_goal_R: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._w_goal_L: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._w_goal_R: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._fk = np.zeros((self.dof, 7), dtype=DTypeD, order="C")
        self._Js = np.zeros((6, self.dof), dtype=DTypeD, order="F")
        self._q_curr = np.zeros(self.dof, dtype=DTypeD)
        if "self_collision" in self.collision_limits:
            NB_SELF_COLLISION = self.collision_limits["self_collision"].max_collisions
            self._d_cbf = np.zeros(NB_SELF_COLLISION, dtype=np.float64)
            self._J_cbf = np.zeros(
                (NB_SELF_COLLISION, self.dof), dtype=np.float64, order="F"
            )

        # self._tf_diff: ampl.Tf = ampl.Tf()
        # self._q_curr = np.zeros(self.dof, dtype=DTypeD)
        # self._dq = np.zeros(self.dof, dtype=DTypeD)
        # self._dq_prev = np.zeros(self.dof, dtype=DTypeD)


class WBCBase(WBC):
    def __init__(self, dof: int, config: Optional[dict[str, Any]] = None):
        # 1. Pass the dynamic DOF directly to the factory base class
        super().__init__(dof=dof)

        self.dt: float = 0.01  # Default

        # Initialize storage for your instantiated tasks and constraints
        self.constraints: dict[str, Any] = {}
        self.tasks: dict[str, Any] = {}

        # 2. Load config if provided
        if config is not None:
            self.load_from_dict(config)

    @abstractmethod
    def update(self, *args, **kwargs):
        pass

    def load_from_dict(self, config: Dict[str, Any]):
        """Builds the controller tasks and constraints from a dictionary."""
        self.dt = config.get("dt", self.dt)

        # --- 1. Load Constraints ---
        for name, params in config.get("constraints", {}).items():
            ctype = params.get("type")

            if ctype == "JointVelocityLimit":
                # Because super().__init__(dof) set up the correct C++ bindings,
                # self._JointVelocityLimitConstraint automatically points to the right DOF version!
                self.constraints[ctype] = self._JointVelocityLimitConstraint(
                    params["start_idx"],
                    params["num_dof"],
                    np.array(params["q_min"]),
                    np.array(params["q_max"]),
                    np.array(params["v_limit"]),
                    self.dt,
                )
                self.controller.add_constraint(self.constraints[ctype])

            elif ctype == "CollisionBarrier":
                self.constraints[ctype] = self._CollisionBarrierConstraint(
                    params["num_max_constraints"], params["weight"]
                )
                self.controller.add_constraint(self.constraints[ctype])
            else:
                print(f"Warning: Unknown constraint type '{ctype}'")

        # --- 2. Load Tasks ---
        for name, params in config.get("tasks", {}).items():
            ttype = params.get("type")

            if ttype == "Damping":
                self.tasks[ttype] = self._DampingTask(params["weights"])
                self.tasks[ttype].set_dt(self.dt)
                self.controller.add_task(self.tasks[ttype])

            elif ttype == "Smoothness":
                self.tasks[ttype] = self._SmoothnessTask(params["weight"])
                self.tasks[ttype].set_dt(self.dt)
                self.controller.add_task(self.tasks[ttype])

            elif ttype == "Jerk":
                self.tasks[ttype] = self._JerkTask(
                    params["weight"], dt=1.0 / float(self.dt)
                )
                self.controller.add_task(self.tasks[ttype])

            elif ttype == "LinearVel":
                self.tasks[ttype] = self._LinearVelTask(
                    params["start_idx"], params["num_dof"], params["weight"]
                )
                self.tasks[ttype].set_dt(self.dt)
                self.controller.add_task(self.tasks[ttype])

            elif ttype == "AngularVel":
                self.tasks[ttype] = self._AngularVelTask(
                    params["start_idx"], params["num_dof"], params["weight"]
                )
                self.tasks[ttype].set_dt(self.dt)
                self.controller.add_task(self.tasks[ttype])

            elif ttype == "Gravity":
                self.tasks[ttype] = self._GravityTask(weight=params["weight"])
                self.tasks[ttype].set_dt(self.dt)
                self.controller.add_task(self.tasks[ttype])

            else:
                print(f"Warning: Unknown task type '{ttype}'")

    # ==========================================
    # Serialization / Deserialization Utilities
    # ==========================================

    def load_from_json_string(self, json_str: str):
        config_dict = json.loads(json_str)
        self.load_from_dict(config_dict)

    def load_from_json_bytes(self, json_bytes: bytes):
        config_dict = json.loads(json_bytes.decode("utf-8"))
        self.load_from_dict(config_dict)

    def load_from_file(self, filepath: str):
        with open(filepath, "r") as f:
            config_dict = json.load(f)
        self.load_from_dict(config_dict)


class WBCA7(WBCBase):

    def __init__(self, config: dict, kin: Kin):
        super().__init__(7, config)
        self._kin = kin
        self._dir_elbo_pull = np.array([0.0, 0.0, -1.0], dtype=DTypeD)
        self._v_goal: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._w_goal: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._tf_diff: ampl.Tf = ampl.Tf()
        self._q_curr = np.zeros(self.dof, dtype=DTypeD)
        self._dq = np.zeros(self.dof, dtype=DTypeD)
        self._dq_prev = np.zeros(self.dof, dtype=DTypeD)
        self._v_goal_relax = np.full(3, 0.1, dtype=DTypeD)
        self._J_tcp_mixed = np.zeros((6, self.dof), dtype=DTypeD, order="F")
        self._Jv_elbow_mixed = np.zeros((3, self.dof), dtype=DTypeD, order="F")
        self._J_spatial = np.zeros((6, self.dof), dtype=DTypeD, order="F")

    def set_goal(self, tf_curr: ampl.Tf, tf_target: ampl.Tf):
        self._tf_diff = tf_target @ tf_curr.inv()
        self._v_goal = tf_target.position - tf_curr.position
        self._w_goal = self._tf_diff.log_so3()

    def update_state(self, q_curr: np.ndarray, J_spatial: np.ndarray):
        np.copyto(self._q_curr, q_curr)
        np.copyto(self._J_spatial, J_spatial)

    def update_jacobian_tcp(self, link_position: np.ndarray):
        self._J_tcp_mixed = spatial_to_mixed_linear_fast(
            self._J_spatial, link_position.astype(DTypeD)
        )
        return

    def update_jacobian_elbow(self, link_position: np.ndarray, link_index: int):
        self._Jv_elbow_mixed[:3, :link_index] = spatial_to_mixed_linear_fast(
            self._J_spatial, link_position.astype(DTypeD)
        )[:3, :link_index]
        return

    def update_controller(self):
        self.tasks["LinearVel"].update(self._J_tcp_mixed, self._v_goal)
        self.tasks["AngularVel"].update(self._J_tcp_mixed, self._w_goal)
        self.tasks["Smoothness"].update(self._dq_prev)
        self.tasks["Jerk"].update(self._dq_prev)
        self.constraints["JointVelocityLimit"].update(self._q_curr)
        self.tasks["Gravity"].update(self._Jv_elbow_mixed[:3], self._dir_elbo_pull)
        # np.copyto(self._q_curr, q_curr)

    def solve(self) -> tuple[int, np.ndarray]:
        self._dq = self.controller.solve()
        if np.isnan(self._dq).any():
            return -6, None
        return self.controller.solver_status(), self._dq

    def update(self):
        return


class WBCT2A7A7(WBCBase):

    def __init__(self, config: dict, kin: Kin):
        super().__init__(16, config)
        self._kin = kin
        self._dir_elbo_pull = np.array([0.0, 0.0, -1.0], dtype=DTypeD)

        self._v_goal_L: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._w_goal_L: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._v_goal_R: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._w_goal_R: np.ndarray = np.zeros(3, dtype=DTypeD)
        self._tf_diff_L: ampl.Tf = ampl.Tf()
        self._tf_diff_R: ampl.Tf = ampl.Tf()

        self._q_curr = np.zeros(self.dof, dtype=DTypeD)
        self._dq = np.zeros(self.dof, dtype=DTypeD)
        self._dq_prev = np.zeros(self.dof, dtype=DTypeD)
        # self._v_goal_relax = np.full(3, 0.1, dtype=DTypeD)

        self._J_tcp_mixed = np.zeros((6, self.dof), dtype=DTypeD, order="F")
        self._Jv_elbow_mixed = np.zeros((3, self.dof), dtype=DTypeD, order="F")
        self._J_spatial = np.zeros((6, self.dof), dtype=DTypeD, order="F")

    def set_goal_L(self, tf_curr: ampl.Tf, tf_target: ampl.Tf):
        self._tf_diff_L = tf_target @ tf_curr.inv()
        self._v_goal_L = tf_target.position - tf_curr.position
        self._w_goal_L = self._tf_diff_L.log_so3()

    def set_goal_R(self, tf_curr: ampl.Tf, tf_target: ampl.Tf):
        self._tf_diff_R = tf_target @ tf_curr.inv()
        self._v_goal_R = tf_target.position - tf_curr.position
        self._w_goal_R = self._tf_diff_R.log_so3()

    def update_state(self, q_curr: np.ndarray, J_spatial: np.ndarray):
        np.copyto(self._q_curr, q_curr)
        np.copyto(self._J_spatial, J_spatial)

    def update_jacobian_tcp_L(self, link_position: np.ndarray):
        self._J_tcp_mixed = spatial_to_mixed_linear_fast(
            self._J_spatial, link_position.astype(DTypeD)
        )
        return

    def update_jacobian_elbow(self, link_position: np.ndarray, link_index: int):
        self._Jv_elbow_mixed[:3, :link_index] = spatial_to_mixed_linear_fast(
            self._J_spatial, link_position.astype(DTypeD)
        )[:3, :link_index]
        return

    def update_controller(self):
        self.tasks["LinearVel"].update(self._J_tcp_mixed, self._v_goal)
        self.tasks["AngularVel"].update(self._J_tcp_mixed, self._w_goal)
        self.tasks["Smoothness"].update(self._dq_prev)
        self.tasks["Jerk"].update(self._dq_prev)
        self.constraints["JointVelocityLimit"].update(self._q_curr)
        self.tasks["Gravity"].update(self._Jv_elbow_mixed[:3], self._dir_elbo_pull)
        # np.copyto(self._q_curr, q_curr)

    def solve(self) -> tuple[int, np.ndarray]:
        self._dq = self.controller.solve()
        if np.isnan(self._dq).any():
            return -6, None
        return self.controller.solver_status(), self._dq

    def update(self):
        return
