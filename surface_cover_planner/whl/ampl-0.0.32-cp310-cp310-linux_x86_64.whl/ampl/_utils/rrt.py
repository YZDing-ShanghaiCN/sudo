import numpy as np
from typing import Optional
import ampl
from enum import Enum


class RRTNode:
    def __init__(self, state: np.ndarray):
        self.state = state
        self.parent: Optional["RRTNode"] = None


class ExtendStatus(Enum):
    ADVANCED = 1  # Successfully took a step toward the target
    REACHED = 2  # Successfully reached the exact target state
    TRAPPED = 3  # Hit an obstacle and could not move


class RRTTree:
    # 1. Explicitly list the template dimensions compiled in the C++ library
    SUPPORTED_DIMS = frozenset(range(0, 20))

    def __init__(self, active_dim: int):
        """
        Initializes the Fast C++ RTree for spatial queries.

        Args:
            active_dim: The number of active degrees of freedom (DOF) for the robot.
        """
        # 2. Hard fail with a highly descriptive error message
        if active_dim not in self.SUPPORTED_DIMS:
            raise ValueError(
                f"\n[CRITICAL ERROR] AMPL RTree is not compiled for {active_dim}D space!\n"
                f"Currently supported dimensions: {sorted(list(self.SUPPORTED_DIMS))}\n"
            )

        # 3. If safe, initialize the C++ tree
        self.rtree_index = ampl.RTree(active_dim)
        self.nodes = []

    def add_node(self, node):
        node_id = len(self.nodes)
        self.nodes.append(node)
        self.rtree_index.insert(node_id, node.state)

    def get_nearest(self, target_state: np.ndarray, search_radius=1.0):
        # We can also add a quick shape assert here to catch bad NumPy arrays!
        assert (
            target_state.shape[0] == self.rtree_index.__len__
            or target_state.size in self.SUPPORTED_DIMS
        ), f"Target state dimension ({target_state.size}) does not match tree dimension!"

        nearest_id = self.rtree_index.nearest(
            target_state, initial_radius=search_radius
        )
        return self.nodes[nearest_id]
