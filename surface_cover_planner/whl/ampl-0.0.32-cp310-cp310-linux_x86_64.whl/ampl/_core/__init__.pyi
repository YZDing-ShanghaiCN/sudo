from collections.abc import Sequence
import enum
from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


def version() -> None:
    """Print version of ampl in terminal."""

class ControlType(enum.Enum):
    Reactive6 = 0

    Reactive7 = 1

Reactive6: ControlType = ControlType.Reactive6

Reactive7: ControlType = ControlType.Reactive7

class ArmType(enum.Enum):
    Humanoid7 = 3

    FR7 = 4

    Industrial6 = 0

    CRX6 = 2

    UR6 = 1

    Extern_TZRX = 5

    Torso4 = 6

    Torso5 = 7

Humanoid7: ArmType = ArmType.Humanoid7

FR7: ArmType = ArmType.FR7

Industrial6: ArmType = ArmType.Industrial6

CRX6: ArmType = ArmType.CRX6

UR6: ArmType = ArmType.UR6

Extern_TZRX: ArmType = ArmType.Extern_TZRX

Torso4: ArmType = ArmType.Torso4

Torso5: ArmType = ArmType.Torso5

def get_arm6_presets() -> list[str]:
    """Returns available presets of arm 6."""

def get_arm7_presets() -> list[str]:
    """Returns available presets of arm 7."""

class ControlReactive:
    def __init__(self, dof_arm: int) -> None:
        """Create a reactive control."""

    def type(self) -> ControlType: ...

    def setup_problem(self, min_link: int = 2, max_link: int = 5) -> None:
        """
        For min_link <= link <= max_link, we force each link's origin to escape from a base direction
        """

    def update_data(self, rwts_link: Annotated[NDArray[numpy.float64], dict(shape=(None, 7), device='cpu', writable=False)], J_spatial: Annotated[NDArray[numpy.float64], dict(shape=(None, 6), device='cpu', writable=False)], state_curr: Annotated[NDArray[numpy.float64], dict(device='cpu', writable=False)], state_lo: Annotated[NDArray[numpy.float64], dict(device='cpu', writable=False)], state_up: Annotated[NDArray[numpy.float64], dict(device='cpu', writable=False)], direction_escape_in_base: Annotated[NDArray[numpy.float64], dict(device='cpu', writable=False)], delta_tcp_xyz_goal: Annotated[NDArray[numpy.float64], dict(device='cpu', writable=False)]) -> None: ...

    def update_data_wbc(self, rwts: Annotated[NDArray[numpy.float64], dict(shape=(None, 7), device='cpu', writable=False)], J: Annotated[NDArray[numpy.float64], dict(shape=(None, 6), device='cpu', writable=False)], q: Annotated[NDArray[numpy.float64], dict(device='cpu', writable=False)], dq_lo: Annotated[NDArray[numpy.float64], dict(device='cpu', writable=False)], dp_hi: Annotated[NDArray[numpy.float64], dict(device='cpu', writable=False)], twist_target: Annotated[NDArray[numpy.float64], dict(device='cpu', writable=False)], p_col: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu', writable=False)] | None = None, p_col_grad: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu', writable=False)] | None = None, p_col_label: Annotated[NDArray[numpy.uint32], dict(device='cpu', writable=False)] | None = None) -> None: ...

    def solve(self, min_escape_distance: float = 0.01, weight_escape: float = 0.15, weight_ee_rotation: float = 3, weight_delta_tcp_xyz_goal: float = 1, state_delta: Annotated[NDArray[numpy.float64], dict(device='cpu')]) -> float: ...

    def solve_wbc(self, weight_dof: Annotated[NDArray[numpy.float64], dict(device='cpu', writable=False)], gain_damping: float = 0.0001, gain_angular: float = 1.0, gain_linear: float = 1.0, gain_elbo: float = 1.0, gain_col_self: float = 0.001, dq: Annotated[NDArray[numpy.float64], dict(device='cpu')]) -> float: ...

class ArmBase:
    def __init__(self, arm_preset: str, arm_type: ArmType, dof: int) -> None:
        """create a preset arm solver"""

    def info(self) -> str: ...

    def joint_limits(self) -> tuple[list[float], list[float]]: ...

    def jacobian(self, arr_rwt: Annotated[NDArray[numpy.float64], dict(shape=(None, None), device='cpu')], J_global: NDArray[numpy.float64]) -> None: ...

    def fk_links(self, q: Annotated[NDArray[numpy.float64], dict(shape=(None,), device='cpu', writable=False)], arr_rwt: Annotated[NDArray[numpy.float64], dict(shape=(None, None), device='cpu')]) -> None:
        """len(q) >= dof, arr_rwt.shape = (dof+1,7), rwt=[rx,ry,rz,w,tx,ty,tz]"""

    def ik(self, m44_world_tool0: Annotated[NDArray[numpy.float64], dict(shape=(None, None), device='cpu')], arr_qik: Annotated[NDArray[numpy.float64], dict(shape=(None, None), device='cpu')]) -> int:
        """arr_qik.shape = (8,dof)"""

    def ik_extern(self, xyz_world_tool0: Annotated[NDArray[numpy.float64], dict(device='cpu')], arr_qik: Annotated[NDArray[numpy.float64], dict(shape=(None, None), device='cpu')]) -> int:
        """only for extern positioner"""

    def ik_iter(self, m44_world_tool0: Annotated[NDArray[numpy.float64], dict(shape=(None, None), device='cpu')], q_ref: NDArray[numpy.float64], q_ik: NDArray[numpy.float64], param_iter: NDArray[numpy.float64], nb_iter: int = 5) -> int:
        """param_iter needs at least 6 continous doubles"""

    def set_base(self, m44_world_base: Annotated[NDArray[numpy.float64], dict(shape=(None, None), device='cpu')]) -> None:
        """set pose of arm base in world"""

class ICPType(enum.Enum):
    P_Query_SDF = 1

P_Query_SDF: ICPType = ICPType.P_Query_SDF

class ICP:
    def __init__(self) -> None: ...

    def create(self, arg: ICPType, /) -> None: ...

    def update_cache(self, v: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], f: Annotated[NDArray[numpy.uint32], dict(shape=(None, 3), device='cpu')] | None = None, param: ICPParam) -> None:
        """update cache structure"""

    def solve(self, p: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], tf_init: Annotated[NDArray[numpy.float32], dict(shape=(4, 4), device='cpu')] | None = None, param: ICPParam) -> tuple[Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='C')], list[float]]:
        """solve icp with initial guess. return pose and cost."""

    def solve_batch(self, p: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], tfs_init: Annotated[NDArray[numpy.float32], dict(shape=(None, 4, 4), device='cpu')], param: ICPParam) -> list[tuple[Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='C')], list[float]]]:
        """solve icp with initial guess. return pose and cost."""

class ICPParam:
    def __init__(self) -> None: ...

    @property
    def df_shape(self) -> list[int]: ...

    @df_shape.setter
    def df_shape(self, arg: Sequence[int], /) -> None: ...

    @property
    def df_origin(self) -> list[float]: ...

    @df_origin.setter
    def df_origin(self, arg: Sequence[float], /) -> None: ...

    @property
    def df_side(self) -> float: ...

    @df_side.setter
    def df_side(self, arg: float, /) -> None: ...

    @property
    def nb_worker(self) -> int: ...

    @nb_worker.setter
    def nb_worker(self, arg: int, /) -> None: ...

    @property
    def iter_damping(self) -> float: ...

    @iter_damping.setter
    def iter_damping(self, arg: float, /) -> None: ...

    @property
    def scale_translation(self) -> float: ...

    @scale_translation.setter
    def scale_translation(self, arg: float, /) -> None: ...

    @property
    def max_iter(self) -> int: ...

    @max_iter.setter
    def max_iter(self, arg: int, /) -> None: ...

class Octreed:
    def __init__(self) -> None: ...

    def create(self, arg0: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')], arg1: Annotated[NDArray[numpy.uint32], dict(shape=(None, 3), device='cpu')], arg2: Annotated[NDArray[numpy.uint32], dict(shape=(None, 2), device='cpu')], arg3: int, /) -> None: ...

    def nearest_neighbour(self, arg0: Annotated[NDArray[numpy.float64], dict(shape=(None, 3))], arg1: NDArray[numpy.float64], arg2: OcTreedEntityType, arg3: float, /) -> None: ...

class OcTreedEntityType(enum.Enum):
    Ver = 1

    Edg = 2

    Tri = 3

Ver: OcTreedEntityType = OcTreedEntityType.Ver

Edg: OcTreedEntityType = OcTreedEntityType.Edg

Tri: OcTreedEntityType = OcTreedEntityType.Tri

def pointcloud_subsample_octree(pointcloud: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], level_subdivide: int = 9, bucket_size: int = 4) -> list[int]:
    """This function subsamples a pointcloud according to octree-bins"""

def pointcloud_segment(pointcloud: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], num_knn: int = 15, max_radius: float = -1.0, max_theta: float = 0.7853981633974483, min_num_per_cluster: int = 250, pointcloud_normal: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')] | None = None, nb_work: int = 4) -> list[list[int]]:
    """This function segments a pointcloud into surface-like clusters"""

def warp_pixel_to_xyz(uv: Annotated[NDArray[numpy.float32], dict(shape=(None, 2), device='cpu')], plane: NDArray[numpy.float32], fx: float, fy: float, cx: float, cy: float, xyz: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], rectify: bool = False) -> Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='C')]:
    """return a plane which best fits points"""

def ransac_plane3(pts: NDArray[numpy.float32], threshold: float, p_outlier: float) -> tuple[Annotated[NDArray[numpy.float32], dict(shape=(None,), order='C')], float]:
    """return a plane which best fits points"""

def estimate_plane(pts: NDArray[numpy.float32]) -> tuple[Annotated[NDArray[numpy.float32], dict(shape=(None,), order='C')], float]:
    """return a plane which best fits points"""

def SO3_align(a: NDArray[numpy.float32], b: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float32], dict(shape=(3, 3), order='C')]:
    """return R such that R a = b"""

def transform_so3_upexp(r3: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float32], dict(shape=(3, 3), order='C')]:
    """return up exp."""

def transform_so3_downlog(R33: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float32], dict(shape=(3), order='C')]:
    """return down log."""

def transform_se3_downlog(R33: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float32], dict(shape=(6), order='C')]:
    """return down log."""

def transform_se3_upexp(r3: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='C')]:
    """return up exp."""

def bounding_obb_point2(xy: Annotated[NDArray[numpy.float32], dict(shape=(None, 2), device='cpu')]) -> list[float]:
    """return obb2 [center_x, center_y, angle, extent]"""

def bounding_obb_point3(xyz: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')]) -> tuple[list[float], list[float], Annotated[NDArray[numpy.float32], dict(shape=(3, 3), order='C')]]:
    """return obb3 [center_x, center_y, angle, extent]"""

def bounding_sphere_point3(xyz: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], method: str = 'fast') -> list[float]:
    """
    return sphere [center_x, center_y, center_z, radius]. method = fast or minball
    """

def transform_xyz(xyz_src: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], xyz_dst: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], rwt: Annotated[NDArray[numpy.float32], dict(device='cpu')]) -> None: ...

def sample_polyline_uniform(waypoints: Annotated[NDArray[numpy.float32], dict(shape=(None, None), device='cpu')], nb_interpolate: int) -> NDArray[numpy.float32]:
    """uniform interplate n-dimensional poly along arclength."""

def sample_sphere3_fibonacci(n: int) -> Annotated[NDArray[numpy.float32], dict(order='C')]:
    """Generate n Fibonacci points on a 3D sphere (float32)"""

def so3_upexp(r: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float64], dict(shape=(3, 3), order='F')]:
    """return exp of r"""

@overload
def rwtmul(rwtA: NDArray[numpy.float32], rwtB: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float32], dict(shape=(7), order='C')]:
    """return rwtAB"""

@overload
def rwtmul(rwtA: NDArray[numpy.float64], rwtB: NDArray[numpy.float64]) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]: ...

@overload
def rwtinv(rwt: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float32], dict(shape=(7), order='C')]:
    """return rwtinv"""

@overload
def rwtinv(rwt: NDArray[numpy.float64]) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]: ...

@overload
def euler_to_rw(eu_angle: NDArray[numpy.float32], eu_order: Sequence[int]) -> Annotated[NDArray[numpy.float32], dict(shape=(4), order='C')]:
    """return rw"""

@overload
def euler_to_rw(eu_angle: NDArray[numpy.float64], eu_order: Sequence[int]) -> Annotated[NDArray[numpy.float64], dict(shape=(4), order='C')]: ...

@overload
def tf44_to_qt7(tf44: Annotated[NDArray[numpy.float32], dict(shape=(4, 4))]) -> Annotated[NDArray[numpy.float32], dict(shape=(7), order='C')]:
    """return qt7"""

@overload
def tf44_to_qt7(tf44: Annotated[NDArray[numpy.float64], dict(shape=(4, 4))]) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]: ...

@overload
def qt7_to_tf44(qt7: Annotated[NDArray[numpy.float64], dict(shape=(None,))]) -> Annotated[NDArray[numpy.float64], dict(shape=(4, 4), order='C')]:
    """return tf44"""

@overload
def qt7_to_tf44(qt7: Annotated[NDArray[numpy.float32], dict(shape=(None,))]) -> Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='C')]: ...

@overload
def wxyz_t_to_tf44(wxyz: Annotated[NDArray[numpy.float64], dict(shape=(None,))], t: Annotated[NDArray[numpy.float64], dict(shape=(None,))]) -> Annotated[NDArray[numpy.float64], dict(shape=(4, 4), order='C')]:
    """return tf44"""

@overload
def wxyz_t_to_tf44(wxyz: Annotated[NDArray[numpy.float32], dict(shape=(None,))], t: Annotated[NDArray[numpy.float32], dict(shape=(None,))]) -> Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='C')]: ...

def distancefield_xyz2occ(xyz: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), order='C', device='cpu')], occ: NDArray[numpy.uint8], shape: NDArray[numpy.uint32], origin: NDArray[numpy.float32], dx: float) -> None:
    """This function computes an occupation grid from a point cloud"""

def distancefield_occ2edf(occ: Annotated[NDArray[numpy.uint8], dict(order='C', device='cpu')], edf: NDArray[numpy.float32], shape: NDArray[numpy.uint32], origin: NDArray[numpy.float32], dx: float, nb_worker: int = 4) -> None:
    """
    This function computes an euclidean distance field from a occupation grid
    """

def distancefield_xyz2edf(xyz: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), order='C', device='cpu')], occ: NDArray[numpy.uint8], edf: NDArray[numpy.float32], shape: NDArray[numpy.uint32], origin: NDArray[numpy.float32], dx: float, nb_worker: int = 4) -> None:
    """This function computes an euclidean distance field from a point cloud"""

def distancefield_df2trimesh(df: NDArray[numpy.float32], mc_level: float, shape: NDArray[numpy.uint32], origin: NDArray[numpy.float32], dx: float) -> tuple[NDArray[numpy.float32], NDArray[numpy.uint32]]:
    """
    This function performs marching cube on a distance field under a given level.
    """

@overload
def frame3_contact(frame_position_in_world: NDArray[numpy.float32], frame_tangent_in_world: NDArray[numpy.float32], frame_normal_in_world: NDArray[numpy.float32], contact_position_in_frame: NDArray[numpy.float32], contact_direction_in_frame: NDArray[numpy.float32], contact_position_in_tool: NDArray[numpy.float32], contact_direction_in_tool: NDArray[numpy.float32], align_direction_in_target: NDArray[numpy.float32], align_direction_in_tool: NDArray[numpy.float32], is_target_frame_or_world: int = 1) -> Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='C')]:
    """This function computes contact."""

@overload
def frame3_contact(frame_position_in_world: NDArray[numpy.float64], frame_tangent_in_world: NDArray[numpy.float64], frame_normal_in_world: NDArray[numpy.float64], contact_position_in_frame: NDArray[numpy.float64], contact_direction_in_frame: NDArray[numpy.float64], contact_position_in_tool: NDArray[numpy.float64], contact_direction_in_tool: NDArray[numpy.float64], align_direction_in_target: NDArray[numpy.float64], align_direction_in_tool: NDArray[numpy.float64], is_target_frame_or_world: int = 1) -> Annotated[NDArray[numpy.float64], dict(shape=(4, 4), order='C')]: ...

def get_stl_data(arg: str, /) -> tuple: ...

def trimesh_vhacd(vertices: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')], indices: Annotated[NDArray[numpy.uint32], dict(shape=(None, 3), device='cpu')], maxConvexHulls: int = 64, resolution: int = 400000, minimumVolumePercentErrorAllowed: float = 1.0, maxRecursionDepth: int = 10, shrinkWrap: bool = True, fillMode: str = 'flood', maxNumVerticesPerCH: int = 64, asyncACD: bool = True, minEdgeLength: int = 2, findBestPlane: bool = False) -> object:
    """This function wraps around vhacd."""

def trimesh_sampler_barycentricysplit(vertices: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], indices: Annotated[NDArray[numpy.uint32], dict(shape=(None, 3), device='cpu')], nb_samples_expect: int, sample_distance_expect: float) -> Annotated[NDArray[numpy.float32], dict(shape=(None, None))]:
    """
    This function samples pointcloud from a mesh by barycentric face-splitting.
    """

def trimesh_raycast(vertices: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')], indices: Annotated[NDArray[numpy.uint32], dict(shape=(None, 3), device='cpu')], origins_ray: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')], directions_ray: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')], ret_hit_indice: bool = False, nb_worker: int = 1, max_dist: float = 10000.0) -> tuple[NDArray[numpy.float64], NDArray[numpy.uint32]]:
    """
    This function performs distance queries of a point cloud against a distance field
    """

def trimesh_connected_components(indices: Annotated[NDArray[numpy.uint32], dict(shape=(None, 3), device='cpu')]) -> list[list[int]]:
    """Return connected components according to face connectivity."""

def trimesh_convexhull(vertices: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], epsilon: float = 1e-05) -> tuple[NDArray[numpy.float32], NDArray[numpy.uint32]]:
    """Return vertices and faces of a convex hull."""

class SphereNode8:
    def __init__(self) -> None: ...

    @property
    def x(self) -> list[float]: ...

    @x.setter
    def x(self, arg: Sequence[float], /) -> None: ...

    @property
    def y(self) -> list[float]: ...

    @y.setter
    def y(self, arg: Sequence[float], /) -> None: ...

    @property
    def z(self) -> list[float]: ...

    @z.setter
    def z(self, arg: Sequence[float], /) -> None: ...

    @property
    def r(self) -> list[float]: ...

    @r.setter
    def r(self, arg: Sequence[float], /) -> None: ...

    @property
    def child_idx(self) -> list[int]: ...

    @child_idx.setter
    def child_idx(self, arg: Sequence[int], /) -> None: ...

    @property
    def valid_mask(self) -> int: ...

    @valid_mask.setter
    def valid_mask(self, arg: int, /) -> None: ...

    @property
    def leaf_mask(self) -> int: ...

    @leaf_mask.setter
    def leaf_mask(self, arg: int, /) -> None: ...

class WallLeafHit:
    """Represents a collision between a link and the global boundary walls."""

    def __init__(self, link_idx: int, leaf_idx: int) -> None: ...

    @property
    def link_idx(self) -> int:
        """The index of the link."""

    @property
    def leaf_idx(self) -> int:
        """The global leaf ID on the link."""

class SphereTree:
    def __init__(self) -> None: ...

    @property
    def root_sphere(self) -> Annotated[NDArray[numpy.float32], dict(shape=(4), order='C')]: ...

    @root_sphere.setter
    def root_sphere(self, arg: Annotated[NDArray[numpy.float32], dict(shape=(4), order='C')], /) -> None: ...

    @property
    def nodes(self) -> list[SphereNode8]: ...

    @nodes.setter
    def nodes(self, arg: Sequence[SphereNode8], /) -> None: ...

    def clone(self) -> SphereTree:
        """Creates a deep, detached copy of the tree that Python now owns."""

class SphereLeafPair:
    """Represents a read-only topological overlap between two leaves."""

    def __init__(self, link_a: int, link_b: int, leaf_a: int, leaf_b: int) -> None: ...

    @property
    def link_a(self) -> int:
        """The index of the first link."""

    @property
    def link_b(self) -> int:
        """The index of the second link."""

    @property
    def leaf_a(self) -> int:
        """The global leaf ID on the first link."""

    @property
    def leaf_b(self) -> int:
        """The global leaf ID on the second link."""

class SphereBVHScene:
    def __init__(self, num_links: int) -> None: ...

    def get_world_tree(self, link_idx: int) -> SphereTree:
        """
        Returns a read-only reference to the world-space SphereTree for a given link.
        """

    def set_local_tree(self, arg0: int, arg1: SphereTree, /) -> None: ...

    @property
    def workspace_active(self) -> bool:
        """Returns True if the containment workspace is currently enabled."""

    @property
    def workspace_min(self) -> tuple[float, float, float]:
        """Returns the minimum (X, Y, Z) boundaries of the workspace as a tuple."""

    @property
    def workspace_max(self) -> tuple[float, float, float]:
        """Returns the maximum (X, Y, Z) boundaries of the workspace as a tuple."""

    def set_acm(self, arg0: int, arg1: int, arg2: bool, /) -> None: ...

    @overload
    def set_workspace(self, min_x: float = -0.5, min_y: float = -1.0, min_z: float = 0.6000000238418579, max_x: float = 1.5, max_y: float = 1.0, max_z: float = 2.0) -> None:
        """
        Defines the Axis-Aligned Bounding Box (AABB) for the containment cage.
        Calling this automatically sets wall_active = True, enabling environment collisions.
        """

    @overload
    def set_workspace(self, x_wall: Sequence[float] = [-0.5, 1.5], y_wall: Sequence[float] = [-1.0, 1.0], z_wall: Sequence[float] = [0.6000000238418579, 2.0]) -> None:
        """
        Set the Safe Wall AABB constraint using [min, max] bounds for each axis.
        """

    def build_leaf_cache(self) -> None:
        """
        Precomputes O(1) memory addresses for all leaves. Run ONCE after loading geometry.
        """

    def set_workspace_check(self, arg0: int, arg1: bool, /) -> None: ...

    def update_poses(self, start_idx: int, raw_poses: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def get_spheres_at_level(self, level: int) -> list[float]:
        """
        Extracts flattened [x,y,z,r] array of all valid spheres at depth 0, 1, or 2.
        """

    def compute_collisions(self, d_safe: float) -> list[SphereLeafPair]: ...

    def compute_wall_collisions(self, d_safe: float) -> list[WallLeafHit]:
        """
        Returns a list of WallLeafHit objects representing geometry hitting the environmental walls.
        """

    def get_full_acm(self) -> list[bool]:
        """Returns the flattened N x N Allowed Collision Matrix."""

    def get_full_wall_checks(self) -> list[bool]:
        """Returns the N-length array of Safe Cell configurations."""

    def compute_collision_gradients(self, leaf_pairs: Sequence[SphereLeafPair], wall_hits: Sequence[WallLeafHit], max_top_k: int = 0) -> NDArray[numpy.float32]:
        """
        Computes gradients and returns an (N, 14) NumPy array for the QP solver.
        """

    def fill_contact_jacobians(self, leaf_pairs: Sequence[SphereLeafPair], wall_hits: Sequence[WallLeafHit] = [], J_array: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], start_idx: int, J_cbf_out: Annotated[NDArray[numpy.float64], dict(shape=(None, None))], distances_out: Annotated[NDArray[numpy.float64], dict(shape=(None,), order='C')], max_top_k: int = 1, col_shift_cbf: int = 0, return_contact_regions: bool = False) -> object: ...

    def set_region_mapping(self, regions: Sequence[Sequence[tuple[int, int]]], link_map: Sequence[int]) -> None:
        """Caches the macro regions and link mapping to avoid boundary overhead."""

    def compute_bounding_plane(self, target_links: Sequence[int], axis: int, is_max: bool) -> float:
        """
        Computes the geometric bounding plane along a given axis (0=X, 1=Y, 2=Z) for specific links.
        Set is_max=True for the maximum bound, or False for the minimum bound.
        """

class VSCHf:
    def __init__(self) -> None:
        """Initialize an empty ConvexHullGroup"""

    @property
    def local_master_sph(self) -> list[float]: ...

    @local_master_sph.setter
    def local_master_sph(self, arg: Sequence[float], /) -> None: ...

    @property
    def world_master_sph(self) -> list[float]: ...

    @world_master_sph.setter
    def world_master_sph(self, arg: Sequence[float], /) -> None: ...

    @property
    def pose(self) -> list[float]: ...

    @pose.setter
    def pose(self, arg: Sequence[float], /) -> None: ...

    @property
    def local_sph_x(self) -> list[float]: ...

    @local_sph_x.setter
    def local_sph_x(self, arg: Sequence[float], /) -> None: ...

    @property
    def local_sph_y(self) -> list[float]: ...

    @local_sph_y.setter
    def local_sph_y(self, arg: Sequence[float], /) -> None: ...

    @property
    def local_sph_z(self) -> list[float]: ...

    @local_sph_z.setter
    def local_sph_z(self, arg: Sequence[float], /) -> None: ...

    @property
    def comp_sph_r(self) -> list[float]: ...

    @comp_sph_r.setter
    def comp_sph_r(self, arg: Sequence[float], /) -> None: ...

    @property
    def world_sph_x(self) -> list[float]: ...

    @world_sph_x.setter
    def world_sph_x(self, arg: Sequence[float], /) -> None: ...

    @property
    def world_sph_y(self) -> list[float]: ...

    @world_sph_y.setter
    def world_sph_y(self, arg: Sequence[float], /) -> None: ...

    @property
    def world_sph_z(self) -> list[float]: ...

    @world_sph_z.setter
    def world_sph_z(self, arg: Sequence[float], /) -> None: ...

    @property
    def local_cvhs(self) -> list[list[float]]: ...

    @local_cvhs.setter
    def local_cvhs(self, arg: Sequence[Sequence[float]], /) -> None: ...

    @property
    def world_cvhs(self) -> list[list[float]]: ...

    @world_cvhs.setter
    def world_cvhs(self, arg: Sequence[Sequence[float]], /) -> None: ...

    def size(self) -> int:
        """Returns the number of sub-components"""

    def batch_update_world_spheres(self) -> None:
        """
        Transforms all local component spheres to world space using the current pose
        """

    def update_world_hull(self, comp_idx: int) -> None:
        """
        Transforms a specific convex hull's vertices to world space (Call right before GJK)
        """

    def get_world_hull_array(self, comp_idx: int) -> Annotated[NDArray[numpy.float32], dict(shape=(None, 3))]:
        """
        Lazy-evaluates the hull transformation and returns a zero-copy (N, 3) numpy array
        """

class AABB3D:
    def __init__(self) -> None: ...

    @property
    def min(self) -> Annotated[NDArray[numpy.float32], dict(shape=(3), order='C')]: ...

    @min.setter
    def min(self, arg: Sequence[float], /) -> None: ...

    @property
    def max(self) -> Annotated[NDArray[numpy.float32], dict(shape=(3), order='C')]: ...

    @max.setter
    def max(self, arg: Sequence[float], /) -> None: ...

    def overlaps(self, arg: AABB3D, /) -> bool: ...

    def merge(self, arg: AABB3D, /) -> AABB3D: ...

class Sphere3D:
    def __init__(self, center: Annotated[NDArray[numpy.float32], dict(shape=(3), order='C')], radius: float) -> None: ...

    @property
    def center(self) -> Annotated[NDArray[numpy.float32], dict(shape=(3), order='C')]: ...

    @center.setter
    def center(self, arg: Annotated[NDArray[numpy.float32], dict(shape=(3), order='C')], /) -> None: ...

    @property
    def radius(self) -> float: ...

    @radius.setter
    def radius(self, arg: float, /) -> None: ...

    def compute_aabb(self) -> AABB3D: ...

class Node3D:
    @property
    def entityID(self) -> int: ...

    @entityID.setter
    def entityID(self, arg: int, /) -> None: ...

class DynamicTree3D:
    def __init__(self) -> None: ...

    def create_proxy(self, arg0: AABB3D, arg1: int, /) -> Node3D: ...

    def update_proxy(self, arg0: Node3D, arg1: AABB3D, /) -> bool: ...

    def destroy_proxy(self, arg: Node3D, /) -> None: ...

    def print(self) -> None: ...

    def get_potential_collisions(self) -> list[tuple[int, int]]:
        """Returns a list of (id_A, id_B) tuples for all overlapping AABBs"""

    def query(self, test_box: AABB3D) -> list[int]:
        """Returns a list of entity IDs overlapping the box"""

    def has_exterior_collision(self, workspace: AABB3D) -> bool:
        """
        Returns True if any proxy in the tree extends outside the given workspace AABB.
        """

    def query_exterior(self, workspace: AABB3D) -> list[int]:
        """
        Returns a list of Entity IDs that are poking outside the given workspace AABB.
        """

def get_gjk_collision_pairs(tree: DynamicTree3D, proxies: Sequence[Node3D], hull_groups: Sequence[VSCHf], ignored_pairs: Sequence[int]) -> list[tuple[int, int, int, int]]:
    """
    Returns a list of tuples: (GroupA_ID, HullA_Index, GroupB_ID, HullB_Index)
    """

def query_tree_external_vsch(tree: DynamicTree3D, ext_obj: VSCHf) -> list[int]:
    """
    Queries an external ConvexHullGroup against the tree without inserting it. Returns a list of colliding Entity IDs.
    """

class VSphG8f:
    def __init__(self) -> None: ...

    @property
    def nb_sph(self) -> int: ...

    @nb_sph.setter
    def nb_sph(self, arg: int, /) -> None: ...

    @property
    def nb_offset(self) -> int: ...

    @nb_offset.setter
    def nb_offset(self, arg: int, /) -> None: ...

    def get_group(self, arg: int, /) -> dict: ...

class VCvhf:
    @overload
    def __init__(self) -> None: ...

    @overload
    def __init__(self, arg: VCvhf) -> None: ...

    @property
    def sph(self) -> list[float]: ...

    @sph.setter
    def sph(self, arg: Sequence[float], /) -> None: ...

    @property
    def components_sph(self) -> list[list[float]]: ...

    @components_sph.setter
    def components_sph(self, arg: Sequence[Sequence[float]], /) -> None: ...

    @property
    def components_cvhs(self) -> list[list[float]]: ...

    @components_cvhs.setter
    def components_cvhs(self, arg: Sequence[Sequence[float]], /) -> None: ...

    def size(self) -> int: ...

    def sizes(self) -> list[int]: ...

class DistanceField:
    def __init__(self) -> None: ...

    @property
    def shape(self) -> list[int]: ...

    @shape.setter
    def shape(self, arg: Sequence[int], /) -> None: ...

    @property
    def origin(self) -> list[float]: ...

    @origin.setter
    def origin(self, arg: Sequence[float], /) -> None: ...

    @property
    def side(self) -> float: ...

    @side.setter
    def side(self, arg: float, /) -> None: ...

    def allocate_buffer(self) -> None: ...

    def clear(self) -> None: ...

    def get_occ_grid(self) -> Annotated[NDArray[numpy.uint8], dict(order='C')]: ...

    def get_df_grid(self) -> Annotated[NDArray[numpy.float32], dict(order='C')]: ...

class OBB3:
    def __init__(self) -> None: ...

    @property
    def center(self) -> list[float]: ...

    @center.setter
    def center(self, arg: Sequence[float], /) -> None: ...

    @property
    def u(self) -> list[float]: ...

    @u.setter
    def u(self, arg: Sequence[float], /) -> None: ...

    @property
    def v(self) -> list[float]: ...

    @v.setter
    def v(self, arg: Sequence[float], /) -> None: ...

    @property
    def w(self) -> list[float]: ...

    @w.setter
    def w(self, arg: Sequence[float], /) -> None: ...

    @property
    def half_extents(self) -> list[float]: ...

    @half_extents.setter
    def half_extents(self, arg: Sequence[float], /) -> None: ...

class AAABB3:
    def __init__(self) -> None: ...

    @property
    def xyz_min(self) -> list[float]: ...

    @xyz_min.setter
    def xyz_min(self, arg: Sequence[float], /) -> None: ...

    @property
    def xyz_max(self) -> list[float]: ...

    @xyz_max.setter
    def xyz_max(self, arg: Sequence[float], /) -> None: ...

class COBB3:
    def __init__(self) -> None: ...

    @property
    def center(self) -> list[float]: ...

    @center.setter
    def center(self, arg: Sequence[float], /) -> None: ...

    @property
    def u(self) -> list[float]: ...

    @u.setter
    def u(self, arg: Sequence[float], /) -> None: ...

    @property
    def v(self) -> list[float]: ...

    @v.setter
    def v(self, arg: Sequence[float], /) -> None: ...

    @property
    def w(self) -> list[float]: ...

    @w.setter
    def w(self, arg: Sequence[float], /) -> None: ...

    @property
    def half_extents(self) -> list[float]: ...

    @half_extents.setter
    def half_extents(self, arg: Sequence[float], /) -> None: ...

    @property
    def r(self) -> float: ...

    @r.setter
    def r(self, arg: float, /) -> None: ...

class Plane3:
    @overload
    def __init__(self) -> None: ...

    @overload
    def __init__(self, arg: Plane3) -> None: ...

    @property
    def center(self) -> list[float]: ...

    @center.setter
    def center(self, arg: Sequence[float], /) -> None: ...

    @property
    def normal_dist(self) -> list[float]: ...

    @normal_dist.setter
    def normal_dist(self, arg: Sequence[float], /) -> None: ...

@overload
def collision_initialize_object(xyzr: Annotated[NDArray[numpy.float32], dict(shape=(None, 4), device='cpu')], offset: Annotated[NDArray[numpy.uint32], dict(shape=(None,), device='cpu')], VSphG8f: VSphG8f) -> None:
    """Initialize spheres into vectorized data buffer."""

@overload
def collision_initialize_object(xyz: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], df: DistanceField, nb_worker: int = 4) -> None:
    """Initialize df from xyz."""

@overload
def collision_initialize_object(plane_center: NDArray[numpy.float32], plane_normal: NDArray[numpy.float32], plane_obj: Plane3, extent_consider_large: float = 100.0) -> None:
    """Initialize plane3."""

@overload
def collision_initialize_object(xyz: Sequence[Annotated[NDArray[numpy.float32], dict(shape=(None, 3))]], cvx_obj: VCvhf) -> None:
    """Initialize cvx_obj from xyz."""

@overload
def collision_initialize_object(xyz: Sequence[Annotated[NDArray[numpy.float32], dict(shape=(None, 3))]], cvx_obj: VSCHf) -> None:
    """Initialize cvx_obj from xyz."""

@overload
def collision_visualize_object(df: DistanceField, field_level: float) -> tuple[NDArray[numpy.float32], NDArray[numpy.uint32]]:
    """
    This function performs marching cube on a distance field object for a given field level.
    """

@overload
def collision_visualize_object(spheres: VSphG8f, nb_v_per_sphere: int = 32) -> tuple[NDArray[numpy.float32], NDArray[numpy.uint32]]:
    """This function create a mesh version of packed spheres."""

@overload
def collision_visualize_object(spheres: VSphG8f, centers: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], grads: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], dists: Annotated[NDArray[numpy.float32], dict(device='cpu')], labels: Annotated[NDArray[numpy.uint32], dict(device='cpu')] | None = None) -> None:
    """This function visualize spheres, grads and distance."""

def collision_debug_object(spheres: VSphG8f) -> None:
    """This function prints xyzr and offsets of packed spheres"""

def collision_detail(spheres: VSphG8f, ps_sph: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], grads_sph: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], dists: Annotated[NDArray[numpy.float32], dict(device='cpu')], labels: Annotated[NDArray[numpy.uint32], dict(device='cpu')] | None = None) -> None:
    """This function visualize spheres, grads and distance."""

def collision_transform_object_inplace(spheres: VSphG8f, i_sph: int, rwt: NDArray[numpy.float32]) -> None:
    """This function transforms packed spheres in place."""

@overload
def collision_transform_object(spheres_src: VSphG8f, spheres_dst: VSphG8f, i_sph: int, rwt: NDArray[numpy.float32]) -> None:
    """This function transforms packed spheres in place."""

@overload
def collision_transform_object(spheres_src: VSphG8f, spheres_dst: VSphG8f, i_sph: int, rwt: NDArray[numpy.float32]) -> None:
    """This function transforms packed spheres in place."""

@overload
def collision_transform_object(cvhs_src: VCvhf, cvhs_dst: VCvhf, rwt: NDArray[numpy.float32]) -> None:
    """This function transforms packed convex hulls."""

@overload
def collision_transform_object(obb3_src: OBB3, obb3_dst: OBB3, rwt: NDArray[numpy.float32]) -> None:
    """This function transforms one obb3."""

@overload
def collision_transform_object(cobb3_src: COBB3, cobb3_dst: COBB3, rwt: NDArray[numpy.float32]) -> None:
    """This function transforms one cobb3."""

@overload
def collision_check_df_vsph(df: DistanceField, spheres: VSphG8f, i_sph: int, d_safe: float) -> bool:
    """
    This function computes intersection between distance field and packed spheres.
    """

@overload
def collision_check_df_vsph(df: DistanceField, spheres: VSphG8f, i_sph: int, d_safe: float, wall: Annotated[NDArray[numpy.float32], dict(shape=(None,), device='cpu')]) -> bool: ...

def collision_check_vcvh_vcvh(vcvhA: VCvhf, vcvhB: VCvhf, d_safe: float = 9.999999747378752e-05) -> float:
    """
    This function computes intersection between distance field and packed spheres.
    """

def collision_distance_vcvh_vcvh(vcvhA: VCvhf, vcvhB: VCvhf, wA: NDArray[numpy.float32], wB: NDArray[numpy.float32]) -> float:
    """
    This function computes minimum distance and witness pair for two packes of convex hulls.
    """

def collision_check_vsph_vsph(spheresA: VSphG8f, i_sph_A: int, spheresB: VSphG8f, i_sph_B: int) -> bool:
    """This function checks collision between two packed spheres."""

def collision_check_plane_vcvh(planeA: Plane3, vcvhB: VCvhf, d_safe: float = 9.999999747378752e-05) -> float:
    """
    This function computes intersection between distance field and packed spheres.
    """

@overload
def collision_check_obb_vsph(obb: OBB3, spheres: VSphG8f, i_sph: int) -> bool:
    """
    This function computes intersection between oriented bounding box (3d) and packed spheres.
    """

@overload
def collision_check_obb_vsph(obb: OBB3, spheres: VSphG8f, i_sph: int, wall: Annotated[NDArray[numpy.float32], dict(shape=(None,), device='cpu')]) -> bool:
    """
    This function computes intersection between oriented bounding box (3d) and packed spheres subject to wall.
    """

def collision_check_cobb_vsph(cobb: COBB3, spheres: VSphG8f, i_sph: int) -> bool:
    """
    This function computes intersection between chamfered oriented bounding box (3d) and packed spheres.
    """

def collision_check_aaabb_vsph(aaabb: AAABB3, spheres: VSphG8f, i_sph: int) -> bool:
    """
    This function computes intersection between anti axis-aligned bounding box (3d) and packed spheres.
    """

def collision_check_aaabb3_vsch(min3: Sequence[float], max3: Sequence[float], vschf: VSCHf) -> bool:
    """
    Returns False if VSCHf is fully inside the AABB, True if it intersects the exterior (anti-aabb).
    """

def collision_gradient_df_vsph(df: DistanceField, spheres: VSphG8f, i_sph: int) -> None:
    """
    This function computes distance gradient between  of distance field and packed spheres.
    """

def collision_gradient_df_vsph_trilinear(df: DistanceField, spheres: VSphG8f, i_sph: int) -> None:
    """
    This function computes distance gradient between  of distance field and packed spheres.
    """

def collision_gradient_obb_vsph(obb: OBB3, spheres: VSphG8f, i_sph: int) -> None:
    """
    This function computes distance gradient between  of oriented bounding box and packed spheres.
    """

def collision_gradient_obb_vsph_pd(obb: OBB3, spheres: VSphG8f, i_sph: int) -> None:
    """
    This function computes distance gradient between  of oriented bounding box and packed spheres.
    """

def collision_gradient_aaabb_vsph_pd(aaabb: AAABB3, spheres: VSphG8f, i_sph: int) -> None:
    """
    This function computes distance gradient between  of anti_axis-aligned bounding box and packed spheres.
    """

def collision_check_xyzwall_vsph(wall: Annotated[NDArray[numpy.float32], dict(shape=(None,), device='cpu')], spheres: VSphG8f, i_sph: int) -> bool:
    """
    This function computes intersection between axis-aligned infinite walls and packed spheres.
    """

@overload
def collision_check_cvx_cvx(cxvA: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')], cvxB: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')]) -> float:
    """This function computes intersection between two convex hull."""

@overload
def collision_check_cvx_cvx(cxvA: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], cvxB: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')]) -> float: ...

@overload
def collision_check_sphtree_sphtree(treeA: SphereTree, T_A_mat: Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='F')], treeB: SphereTree, T_B_mat: Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='F')], d_safe: float) -> list[tuple[int, int]]:
    """
    Checks collision between two SphereTrees returning a list of colliding leaf IDs.
    """

@overload
def collision_check_sphtree_sphtree(treeA: SphereTree, treeB: SphereTree, d_safe: float) -> list[tuple[int, int]]: ...

def splat_swept_capsule(df: DistanceField, node_A: SphereNode8, node_B: SphereNode8, truncation_margin: float = 0.05000000074505806) -> None:
    """
    Splats a continuous capsule sweep between two SphereNode8 states into the DistanceField.
    """

class IRTree:
    def insert(self, id: int, point: Annotated[NDArray[numpy.float64], dict(shape=(None,), writable=False)]) -> None: ...

    def remove(self, id: int) -> None: ...

    def nearest(self, target: Annotated[NDArray[numpy.float64], dict(shape=(None,), writable=False)], initial_radius: float = 0.5) -> int: ...

    def __len__(self) -> int: ...

def RTree(dims: int) -> IRTree:
    """Initializes the RTree for a specific number of dimensions."""

class RNG3:
    def __init__(self) -> None: ...

    def set_range(self, arg0: NDArray[numpy.float64], arg1: NDArray[numpy.float64], /) -> None: ...

    def reset(self) -> None: ...

    def seed(self, arg: int, /) -> None: ...

    @overload
    def next(self, arg0: NDArray[numpy.float32], arg1: int, /) -> None: ...

    @overload
    def next(self, arg0: NDArray[numpy.float64], arg1: int, /) -> None: ...

class RNG6:
    def __init__(self) -> None: ...

    def set_range(self, arg0: NDArray[numpy.float64], arg1: NDArray[numpy.float64], /) -> None: ...

    def reset(self) -> None: ...

    def seed(self, arg: int, /) -> None: ...

    @overload
    def next(self, arg0: NDArray[numpy.float32], arg1: int, /) -> None: ...

    @overload
    def next(self, arg0: NDArray[numpy.float64], arg1: int, /) -> None: ...

class RNG7:
    def __init__(self) -> None: ...

    def set_range(self, arg0: NDArray[numpy.float64], arg1: NDArray[numpy.float64], /) -> None: ...

    def reset(self) -> None: ...

    def seed(self, arg: int, /) -> None: ...

    @overload
    def next(self, arg0: NDArray[numpy.float32], arg1: int, /) -> None: ...

    @overload
    def next(self, arg0: NDArray[numpy.float64], arg1: int, /) -> None: ...

def graph_from_polyline(waypoints: Annotated[NDArray[numpy.float32], dict(shape=(None, None), device='cpu')], nb_internal: int = 1) -> tuple[dict[int, list[tuple[int, float]]], NDArray[numpy.float32]]:
    """densify and create graph"""

def graph_dijkstra_single(adj: dict, nb_vertex: int, src: int, dst: int) -> tuple[float, list[int]]:
    """dijkstra"""

def dynamicprogram_minimum_deviation(dp: Annotated[NDArray[numpy.float32], dict(shape=(None, None), device='cpu')], value_invalid: float = 1000000000.0) -> list[int]:
    """dp"""

def graph_distance_matrix_l2(xa: Annotated[NDArray[numpy.float32], dict(shape=(None, None), device='cpu')], xb: Annotated[NDArray[numpy.float32], dict(shape=(None, None), device='cpu')], mab: Annotated[NDArray[numpy.float32], dict(shape=(None, None), device='cpu')]) -> None:
    """
    dense distance matrix. mab is row major. mab.shape = (xb.shape[1], xa.shape[1])
    """

def optim_qp(Q: Annotated[NDArray[numpy.float64], dict(shape=(None, None))], p: NDArray[numpy.float64], A: Annotated[NDArray[numpy.float64], dict(shape=(None, None))], u: NDArray[numpy.float64], x: NDArray[numpy.float64]) -> float:
    """Solve positive definite quadratic program."""

@overload
def dynamicprogram_smooth_path(mask: Annotated[NDArray[numpy.bool_], dict(shape=(None, None), order='C', device='cpu')], state: Annotated[NDArray[numpy.float32], dict(shape=(None, None, None), order='C', device='cpu')], threshold: Annotated[NDArray[numpy.float32], dict(shape=(None,), order='C', device='cpu')], weight_2nd: float = 1.0) -> tuple[list[int], float]:
    """Finds optimal smooth path minimizing 1st and 2nd order L2 norms."""

@overload
def dynamicprogram_smooth_path(mask_arr: Annotated[NDArray[numpy.bool_], dict(shape=(None, None), order='C', device='cpu')], state_arr: Annotated[NDArray[numpy.float32], dict(shape=(None, None, None), order='C', device='cpu')], thresh1_arr: Annotated[NDArray[numpy.float32], dict(shape=(None,), order='C', device='cpu')] | None = None, thresh2_arr: Annotated[NDArray[numpy.float32], dict(shape=(None,), order='C', device='cpu')] | None = None, weight_2nd: float = 1.0, target_start_idx: int = -1) -> tuple[list[int], float]:
    """Finds optimal smooth path minimizing 1st/2nd order L2 norms."""

def algo_debug() -> None: ...

def image_apriltags_create_grid(xyz_nx4x3: Annotated[NDArray[numpy.float32], dict(shape=(None, None, 3), device='cpu')], family: int = 6, tag_size: float = 88.0, tag_spacing: float = 0.3) -> None:
    """This function extracts apriltags for 36h11"""

def image_apriltags(gray: Annotated[NDArray[numpy.float32], dict(shape=(None, None), device='cpu')], corners_nx4x2: Annotated[NDArray[numpy.float32], dict(shape=(None, None, 2), device='cpu')], family: int = 6, nb_black_border: int = 2) -> list[int]:
    """This function extracts apriltags for 36h11"""

def image_roi(mask: Annotated[NDArray[numpy.uint8], dict(shape=(None, None), device='cpu')], ids: Sequence[int] = []) -> dict[int, list[int]]:
    """This function extracts rois from a multi-labelled mask"""

def image_depth_to_xyz(dI: Annotated[NDArray[numpy.uint16], dict(shape=(None, None), device='cpu')], fx: float, fy: float, cx: float, cy: float, xyzI: Annotated[NDArray[numpy.float32], dict(shape=(None, None, 3), device='cpu')], scale: float = -1.0, z_min_after_scale: float = 0.0, z_max_after_scale: float = 65535.0) -> None:
    """depth image to xyz image"""

def image_xyz_to_normal(arg0: Annotated[NDArray[numpy.float32], dict(shape=(None, None, 3), device='cpu')], arg1: float, arg2: float, arg3: Annotated[NDArray[numpy.float32], dict(shape=(None, None, 3), device='cpu')], /) -> None:
    """xyz image to nx ny nz image"""

class TrajBC6:
    def __init__(self) -> None: ...

    @property
    def start_velocity(self) -> Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')]: ...

    @start_velocity.setter
    def start_velocity(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')], /) -> None: ...

    @property
    def start_acceleration(self) -> Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')]: ...

    @start_acceleration.setter
    def start_acceleration(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')], /) -> None: ...

    @property
    def end_velocity(self) -> Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')]: ...

    @end_velocity.setter
    def end_velocity(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')], /) -> None: ...

    @property
    def end_acceleration(self) -> Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')]: ...

    @end_acceleration.setter
    def end_acceleration(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')], /) -> None: ...

    @property
    def start_jerk(self) -> Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')]: ...

    @start_jerk.setter
    def start_jerk(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')], /) -> None: ...

    @property
    def end_jerk(self) -> Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')]: ...

    @end_jerk.setter
    def end_jerk(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')], /) -> None: ...

class TrajBC7:
    def __init__(self) -> None: ...

    @property
    def start_velocity(self) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]: ...

    @start_velocity.setter
    def start_velocity(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')], /) -> None: ...

    @property
    def start_acceleration(self) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]: ...

    @start_acceleration.setter
    def start_acceleration(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')], /) -> None: ...

    @property
    def end_velocity(self) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]: ...

    @end_velocity.setter
    def end_velocity(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')], /) -> None: ...

    @property
    def end_acceleration(self) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]: ...

    @end_acceleration.setter
    def end_acceleration(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')], /) -> None: ...

    @property
    def start_jerk(self) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]: ...

    @start_jerk.setter
    def start_jerk(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')], /) -> None: ...

    @property
    def end_jerk(self) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]: ...

    @end_jerk.setter
    def end_jerk(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')], /) -> None: ...

class TrajBC3:
    def __init__(self) -> None: ...

    @property
    def start_velocity(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]: ...

    @start_velocity.setter
    def start_velocity(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], /) -> None: ...

    @property
    def start_acceleration(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]: ...

    @start_acceleration.setter
    def start_acceleration(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], /) -> None: ...

    @property
    def end_velocity(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]: ...

    @end_velocity.setter
    def end_velocity(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], /) -> None: ...

    @property
    def end_acceleration(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]: ...

    @end_acceleration.setter
    def end_acceleration(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], /) -> None: ...

    @property
    def start_jerk(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]: ...

    @start_jerk.setter
    def start_jerk(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], /) -> None: ...

    @property
    def end_jerk(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]: ...

    @end_jerk.setter
    def end_jerk(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], /) -> None: ...

class TrajPPoly3:
    def __init__(self) -> None: ...

    @overload
    def generate_time_sequence(self, arg: float, /) -> list[float]: ...

    @overload
    def generate_time_sequence(self, arg0: float, arg1: float, arg2: float, /) -> list[float]: ...

class CurveBSpline:
    def __init__(self, x: Annotated[NDArray[numpy.float64], dict(device='cpu', writable=False)], y: Annotated[NDArray[numpy.float64], dict(device='cpu', writable=False)], deg: int = 5, smoothing: float = 0.001, w: Annotated[NDArray[numpy.float64], dict(device='cpu', writable=False)] | None = None) -> None: ...

    def degree(self) -> int: ...

    def eval(self, arg: float, /) -> float: ...

def dquery_line3_line3(p1: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], p2: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], q1: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], q2: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]) -> tuple[Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]]:
    """
    Computes the closest points between two infinite 3D lines defined by point pairs.
    """

def top_k(d: Annotated[NDArray[numpy.float32], dict(order='C', device='cpu', writable=False)], labels: Annotated[NDArray[numpy.uint32], dict(order='C', device='cpu', writable=False)], mask: Sequence[int], k: int) -> dict[int, list[int]]:
    """
    Finds the original array positions of the top k values in 'd' for each label in 'mask'.
    """

def spatial_to_mixed_linear(J_spatial: Annotated[NDArray[numpy.float64], dict(shape=(6, None), order='F', device='cpu')], p_world: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), order='C', device='cpu')], g_world: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), order='C', device='cpu')], link_indices: Annotated[NDArray[numpy.int32], dict(shape=(None,), order='C', device='cpu')], out: Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='F', device='cpu')]) -> None:
    """Projects spatial Jacobians using F-contiguous NumPy arrays."""

class Tf:
    @overload
    def __init__(self) -> None: ...

    @overload
    def __init__(self, matrix: Annotated[NDArray[numpy.float64], dict(shape=(4, 4), order='F')]) -> None: ...

    @overload
    def __init__(self, args: tuple[Annotated[NDArray[numpy.float64], dict(shape=(4), order='C')], Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]]) -> None: ...

    @overload
    def __init__(self, array: Annotated[NDArray, dict(shape=(None,))]) -> None: ...

    @overload
    def __init__(self, rpy: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], xyz: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]) -> None: ...

    @overload
    def __init__(self, x: float, y: float, theta: float) -> None:
        """Fast initialization for 2D poses (x, y, yaw)."""

    @overload
    def __init__(self, axis: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], radians: float, translation: object | None = None) -> None:
        """
        Initialize pose from an axis (Vector3d), an angle (radians), and optional translation.
        """

    def clone(self) -> Tf:
        """Returns a deep copy of the pose."""

    def __mul__(self, arg: Tf, /) -> Tf: ...

    @overload
    def __matmul__(self, arg: Tf, /) -> Tf: ...

    @overload
    def __matmul__(self, array: Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='C')]) -> NDArray[numpy.float64]: ...

    def __rmatmul__(self, array: Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='C')]) -> NDArray[numpy.float64]: ...

    def inv(self) -> Tf: ...

    def log_so3(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]:
        """Computes the SO(3) logarithmic map (3D rotation vector)."""

    def slerp(self, t: float, other: Tf) -> Tf:
        """
        Interpolate between this pose and another pose (LERP for translation, SLERP for rotation).
        """

    @property
    def position(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]: ...

    @position.setter
    def position(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], /) -> None: ...

    def set_from_2d(self, x: float, y: float, theta: float) -> None: ...

    @property
    def wxyz(self) -> Annotated[NDArray[numpy.float64], dict(shape=(4), order='C')]: ...

    @wxyz.setter
    def wxyz(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(4), order='C')], /) -> None: ...

    @property
    def local_x(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]:
        """Local X axis vector in world coordinates"""

    @property
    def local_y(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]:
        """Local Y axis vector in world coordinates"""

    @property
    def local_z(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]:
        """Local Z axis vector in world coordinates"""

    def as_array(self) -> Annotated[NDArray[numpy.float64], dict(shape=(7))]: ...

    def rwt(self) -> Annotated[NDArray[numpy.float64], dict(shape=(7))]: ...

    @property
    def matrix(self) -> Annotated[NDArray[numpy.float64], dict(shape=(4, 4), order='F')]: ...

    @matrix.setter
    def matrix(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(4, 4), order='F')], /) -> None: ...

    def transform_points(self, points: Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='C')]) -> NDArray[numpy.float64]:
        """
        Applies the full pose transformation (R*p + t) to an Nx3 array of points.
        """

    def rotate_points(self, points: Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='C')]) -> NDArray[numpy.float64]:
        """
        Applies only the rotation part of the pose (R*p) to an Nx3 array of points.
        """

    def __repr__(self) -> str: ...

class KinematicBlock:
    def __init__(self, local_start: int, global_start: int, size: int) -> None: ...

    @property
    def local_start(self) -> int: ...

    @local_start.setter
    def local_start(self, arg: int, /) -> None: ...

    @property
    def global_start(self) -> int: ...

    @global_start.setter
    def global_start(self, arg: int, /) -> None: ...

    @property
    def size(self) -> int: ...

    @size.setter
    def size(self, arg: int, /) -> None: ...

class DAQPSolver6:
    def __init__(self) -> None: ...

class Task6:
    pass

class Constraint6:
    pass

class Controller6:
    def __init__(self, solver: DAQPSolver6, max_constraint_rows: int = 100) -> None: ...

    def add_task(self, arg: Task6, /) -> None: ...

    def add_constraint(self, arg: Constraint6, /) -> None: ...

    def solve(self) -> Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')]: ...

    def solver_status(self) -> int: ...

    def init_topology(self, macro_regions: Sequence[Sequence[tuple[int, int]]], link_to_region: Sequence[int], id_to_col_shift: int = 0) -> None:
        """
        Compiles the macro regions into explicit KinematicBlocks for all joints at boot time.
        """

    def get_blocks_for_joint(self, joint_id: int) -> list[KinematicBlock]:
        """Returns the O(1) cached KinematicBlocks for a specific joint ID."""

    @property
    def macro_regions(self) -> list[list[tuple[int, int]]]:
        """Get the compiled macro regions (lists of column blocks)"""

    @property
    def joint_to_region(self) -> list[int]:
        """Get the mapping of joint IDs to their respective macro region"""

class JointRegularizationTask6(Task6):
    def __init__(self, dq: float, ddq: float, dddq: float, current_dt: float = 0.001) -> None: ...

    def set_dt(self, dt: float) -> None: ...

    def update_history(self, q_dot_prev: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def reset(self, current_vel: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_joint_multipliers(self, multipliers: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_dq(self, dq: float) -> None: ...

    def set_ddq(self, ddq: float) -> None: ...

    def set_dddq(self, dddq: float) -> None: ...

    def is_active(self) -> bool: ...

    def set_active(self, arg: bool, /) -> None: ...

class LinearVelTask6(Task6):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], tcp_in_base: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')] | None = None) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    def set_weight(self, weight: float) -> None:
        """Real-time safe scalar weight update."""

class AngularVelTask6(Task6):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    def set_weight(self, weight: float) -> None:
        """Real-time safe scalar weight update."""

class SwivelVelTask6(Task6):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, p_s: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], p_e: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], p_w: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], phi_dot_des: float) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

class ContactRepTask6(Task6):
    def __init__(self, max_collisions: int) -> None: ...

    def update(self, Jc_array: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], current_weight: float) -> None:
        """Updates the multi-contact net escape gradient."""

    def is_active(self) -> bool:
        """Returns true if there are active collisions and weight > 0."""

    def set_active(self, active: bool) -> None:
        """Manually toggle the task on or off."""

    def set_weight(self, weight: float) -> None:
        """Set a uniform scalar weight."""

class LinearVelConstraint6(Constraint6):
    def __init__(self, arg0: int, arg1: Sequence[KinematicBlock], /) -> None: ...

    def update(self, global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], v_min: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], v_max: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], r_vec_base: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')] | None = None) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

class CollisionBarrierConstraint6(Constraint6):
    def __init__(self, max_collisions: int, gamma: float, d_safe: float) -> None: ...

    def update_direct(self, Jc_array: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], dist_array: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')]) -> None: ...

    @property
    def gamma(self) -> float:
        """CBF aggressiveness multiplier"""

    @gamma.setter
    def gamma(self, arg: float, /) -> None: ...

    @property
    def d_safe(self) -> float:
        """Minimum safe distance margin (meters)"""

    @d_safe.setter
    def d_safe(self, arg: float, /) -> None: ...

    @property
    def max_collisions(self) -> int:
        """Get the pre-allocated maximum number of collisions allowed"""

    def set_active(self, arg: bool, /) -> None: ...

class JointVelocityLimitConstraint6(Constraint6):
    def __init__(self, q_min: Annotated[NDArray[numpy.float64], dict(order='C')], q_max: Annotated[NDArray[numpy.float64], dict(order='C')], v_limit: Annotated[NDArray[numpy.float64], dict(order='C')], dt: float = 0.001) -> None: ...

    def update(self, q_curr: Annotated[NDArray[numpy.float64], dict(order='C')]) -> None: ...

    def update_limits(self, q_min: Annotated[NDArray[numpy.float64], dict(order='C')], q_max: Annotated[NDArray[numpy.float64], dict(order='C')], v_limits: Annotated[NDArray[numpy.float64], dict(order='C')]) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    @property
    def q_min(self) -> Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')]:
        """Get minimum joint positions"""

    @property
    def q_max(self) -> Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')]:
        """Get maximum joint positions"""

    @property
    def v_limit(self) -> Annotated[NDArray[numpy.float64], dict(shape=(6), order='C')]:
        """Get maximum joint velocities"""

class DAQPSolver7:
    def __init__(self) -> None: ...

class Task7:
    pass

class Constraint7:
    pass

class Controller7:
    def __init__(self, solver: DAQPSolver7, max_constraint_rows: int = 100) -> None: ...

    def add_task(self, arg: Task7, /) -> None: ...

    def add_constraint(self, arg: Constraint7, /) -> None: ...

    def solve(self) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]: ...

    def solver_status(self) -> int: ...

    def init_topology(self, macro_regions: Sequence[Sequence[tuple[int, int]]], link_to_region: Sequence[int], id_to_col_shift: int = 0) -> None:
        """
        Compiles the macro regions into explicit KinematicBlocks for all joints at boot time.
        """

    def get_blocks_for_joint(self, joint_id: int) -> list[KinematicBlock]:
        """Returns the O(1) cached KinematicBlocks for a specific joint ID."""

    @property
    def macro_regions(self) -> list[list[tuple[int, int]]]:
        """Get the compiled macro regions (lists of column blocks)"""

    @property
    def joint_to_region(self) -> list[int]:
        """Get the mapping of joint IDs to their respective macro region"""

class JointRegularizationTask7(Task7):
    def __init__(self, dq: float, ddq: float, dddq: float, current_dt: float = 0.001) -> None: ...

    def set_dt(self, dt: float) -> None: ...

    def update_history(self, q_dot_prev: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def reset(self, current_vel: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_joint_multipliers(self, multipliers: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_dq(self, dq: float) -> None: ...

    def set_ddq(self, ddq: float) -> None: ...

    def set_dddq(self, dddq: float) -> None: ...

    def is_active(self) -> bool: ...

    def set_active(self, arg: bool, /) -> None: ...

class LinearVelTask7(Task7):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], tcp_in_base: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')] | None = None) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    def set_weight(self, weight: float) -> None:
        """Real-time safe scalar weight update."""

class AngularVelTask7(Task7):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    def set_weight(self, weight: float) -> None:
        """Real-time safe scalar weight update."""

class SwivelVelTask7(Task7):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, p_s: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], p_e: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], p_w: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], phi_dot_des: float) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

class ContactRepTask7(Task7):
    def __init__(self, max_collisions: int) -> None: ...

    def update(self, Jc_array: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], current_weight: float) -> None:
        """Updates the multi-contact net escape gradient."""

    def is_active(self) -> bool:
        """Returns true if there are active collisions and weight > 0."""

    def set_active(self, active: bool) -> None:
        """Manually toggle the task on or off."""

    def set_weight(self, weight: float) -> None:
        """Set a uniform scalar weight."""

class LinearVelConstraint7(Constraint7):
    def __init__(self, arg0: int, arg1: Sequence[KinematicBlock], /) -> None: ...

    def update(self, global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], v_min: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], v_max: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], r_vec_base: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')] | None = None) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

class CollisionBarrierConstraint7(Constraint7):
    def __init__(self, max_collisions: int, gamma: float, d_safe: float) -> None: ...

    def update_direct(self, Jc_array: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], dist_array: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')]) -> None: ...

    @property
    def gamma(self) -> float:
        """CBF aggressiveness multiplier"""

    @gamma.setter
    def gamma(self, arg: float, /) -> None: ...

    @property
    def d_safe(self) -> float:
        """Minimum safe distance margin (meters)"""

    @d_safe.setter
    def d_safe(self, arg: float, /) -> None: ...

    @property
    def max_collisions(self) -> int:
        """Get the pre-allocated maximum number of collisions allowed"""

    def set_active(self, arg: bool, /) -> None: ...

class JointVelocityLimitConstraint7(Constraint7):
    def __init__(self, q_min: Annotated[NDArray[numpy.float64], dict(order='C')], q_max: Annotated[NDArray[numpy.float64], dict(order='C')], v_limit: Annotated[NDArray[numpy.float64], dict(order='C')], dt: float = 0.001) -> None: ...

    def update(self, q_curr: Annotated[NDArray[numpy.float64], dict(order='C')]) -> None: ...

    def update_limits(self, q_min: Annotated[NDArray[numpy.float64], dict(order='C')], q_max: Annotated[NDArray[numpy.float64], dict(order='C')], v_limits: Annotated[NDArray[numpy.float64], dict(order='C')]) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    @property
    def q_min(self) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]:
        """Get minimum joint positions"""

    @property
    def q_max(self) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]:
        """Get maximum joint positions"""

    @property
    def v_limit(self) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]:
        """Get maximum joint velocities"""

class DAQPSolver14:
    def __init__(self) -> None: ...

class Task14:
    pass

class Constraint14:
    pass

class Controller14:
    def __init__(self, solver: DAQPSolver14, max_constraint_rows: int = 100) -> None: ...

    def add_task(self, arg: Task14, /) -> None: ...

    def add_constraint(self, arg: Constraint14, /) -> None: ...

    def solve(self) -> Annotated[NDArray[numpy.float64], dict(shape=(14), order='C')]: ...

    def solver_status(self) -> int: ...

    def init_topology(self, macro_regions: Sequence[Sequence[tuple[int, int]]], link_to_region: Sequence[int], id_to_col_shift: int = 0) -> None:
        """
        Compiles the macro regions into explicit KinematicBlocks for all joints at boot time.
        """

    def get_blocks_for_joint(self, joint_id: int) -> list[KinematicBlock]:
        """Returns the O(1) cached KinematicBlocks for a specific joint ID."""

    @property
    def macro_regions(self) -> list[list[tuple[int, int]]]:
        """Get the compiled macro regions (lists of column blocks)"""

    @property
    def joint_to_region(self) -> list[int]:
        """Get the mapping of joint IDs to their respective macro region"""

class JointRegularizationTask14(Task14):
    def __init__(self, dq: float, ddq: float, dddq: float, current_dt: float = 0.001) -> None: ...

    def set_dt(self, dt: float) -> None: ...

    def update_history(self, q_dot_prev: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def reset(self, current_vel: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_joint_multipliers(self, multipliers: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_dq(self, dq: float) -> None: ...

    def set_ddq(self, ddq: float) -> None: ...

    def set_dddq(self, dddq: float) -> None: ...

    def is_active(self) -> bool: ...

    def set_active(self, arg: bool, /) -> None: ...

class LinearVelTask14(Task14):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], tcp_in_base: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')] | None = None) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    def set_weight(self, weight: float) -> None:
        """Real-time safe scalar weight update."""

class AngularVelTask14(Task14):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    def set_weight(self, weight: float) -> None:
        """Real-time safe scalar weight update."""

class SwivelVelTask14(Task14):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, p_s: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], p_e: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], p_w: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], phi_dot_des: float) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

class ContactRepTask14(Task14):
    def __init__(self, max_collisions: int) -> None: ...

    def update(self, Jc_array: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], current_weight: float) -> None:
        """Updates the multi-contact net escape gradient."""

    def is_active(self) -> bool:
        """Returns true if there are active collisions and weight > 0."""

    def set_active(self, active: bool) -> None:
        """Manually toggle the task on or off."""

    def set_weight(self, weight: float) -> None:
        """Set a uniform scalar weight."""

class LinearVelConstraint14(Constraint14):
    def __init__(self, arg0: int, arg1: Sequence[KinematicBlock], /) -> None: ...

    def update(self, global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], v_min: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], v_max: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], r_vec_base: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')] | None = None) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

class CollisionBarrierConstraint14(Constraint14):
    def __init__(self, max_collisions: int, gamma: float, d_safe: float) -> None: ...

    def update_direct(self, Jc_array: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], dist_array: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')]) -> None: ...

    @property
    def gamma(self) -> float:
        """CBF aggressiveness multiplier"""

    @gamma.setter
    def gamma(self, arg: float, /) -> None: ...

    @property
    def d_safe(self) -> float:
        """Minimum safe distance margin (meters)"""

    @d_safe.setter
    def d_safe(self, arg: float, /) -> None: ...

    @property
    def max_collisions(self) -> int:
        """Get the pre-allocated maximum number of collisions allowed"""

    def set_active(self, arg: bool, /) -> None: ...

class JointVelocityLimitConstraint14(Constraint14):
    def __init__(self, q_min: Annotated[NDArray[numpy.float64], dict(order='C')], q_max: Annotated[NDArray[numpy.float64], dict(order='C')], v_limit: Annotated[NDArray[numpy.float64], dict(order='C')], dt: float = 0.001) -> None: ...

    def update(self, q_curr: Annotated[NDArray[numpy.float64], dict(order='C')]) -> None: ...

    def update_limits(self, q_min: Annotated[NDArray[numpy.float64], dict(order='C')], q_max: Annotated[NDArray[numpy.float64], dict(order='C')], v_limits: Annotated[NDArray[numpy.float64], dict(order='C')]) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    @property
    def q_min(self) -> Annotated[NDArray[numpy.float64], dict(shape=(14), order='C')]:
        """Get minimum joint positions"""

    @property
    def q_max(self) -> Annotated[NDArray[numpy.float64], dict(shape=(14), order='C')]:
        """Get maximum joint positions"""

    @property
    def v_limit(self) -> Annotated[NDArray[numpy.float64], dict(shape=(14), order='C')]:
        """Get maximum joint velocities"""

class DAQPSolver16:
    def __init__(self) -> None: ...

class Task16:
    pass

class Constraint16:
    pass

class Controller16:
    def __init__(self, solver: DAQPSolver16, max_constraint_rows: int = 100) -> None: ...

    def add_task(self, arg: Task16, /) -> None: ...

    def add_constraint(self, arg: Constraint16, /) -> None: ...

    def solve(self) -> Annotated[NDArray[numpy.float64], dict(shape=(16), order='C')]: ...

    def solver_status(self) -> int: ...

    def init_topology(self, macro_regions: Sequence[Sequence[tuple[int, int]]], link_to_region: Sequence[int], id_to_col_shift: int = 0) -> None:
        """
        Compiles the macro regions into explicit KinematicBlocks for all joints at boot time.
        """

    def get_blocks_for_joint(self, joint_id: int) -> list[KinematicBlock]:
        """Returns the O(1) cached KinematicBlocks for a specific joint ID."""

    @property
    def macro_regions(self) -> list[list[tuple[int, int]]]:
        """Get the compiled macro regions (lists of column blocks)"""

    @property
    def joint_to_region(self) -> list[int]:
        """Get the mapping of joint IDs to their respective macro region"""

class JointRegularizationTask16(Task16):
    def __init__(self, dq: float, ddq: float, dddq: float, current_dt: float = 0.001) -> None: ...

    def set_dt(self, dt: float) -> None: ...

    def update_history(self, q_dot_prev: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def reset(self, current_vel: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_joint_multipliers(self, multipliers: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_dq(self, dq: float) -> None: ...

    def set_ddq(self, ddq: float) -> None: ...

    def set_dddq(self, dddq: float) -> None: ...

    def is_active(self) -> bool: ...

    def set_active(self, arg: bool, /) -> None: ...

class LinearVelTask16(Task16):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], tcp_in_base: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')] | None = None) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    def set_weight(self, weight: float) -> None:
        """Real-time safe scalar weight update."""

class AngularVelTask16(Task16):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    def set_weight(self, weight: float) -> None:
        """Real-time safe scalar weight update."""

class SwivelVelTask16(Task16):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, p_s: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], p_e: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], p_w: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], phi_dot_des: float) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

class ContactRepTask16(Task16):
    def __init__(self, max_collisions: int) -> None: ...

    def update(self, Jc_array: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], current_weight: float) -> None:
        """Updates the multi-contact net escape gradient."""

    def is_active(self) -> bool:
        """Returns true if there are active collisions and weight > 0."""

    def set_active(self, active: bool) -> None:
        """Manually toggle the task on or off."""

    def set_weight(self, weight: float) -> None:
        """Set a uniform scalar weight."""

class LinearVelConstraint16(Constraint16):
    def __init__(self, arg0: int, arg1: Sequence[KinematicBlock], /) -> None: ...

    def update(self, global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], v_min: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], v_max: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], r_vec_base: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')] | None = None) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

class CollisionBarrierConstraint16(Constraint16):
    def __init__(self, max_collisions: int, gamma: float, d_safe: float) -> None: ...

    def update_direct(self, Jc_array: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], dist_array: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')]) -> None: ...

    @property
    def gamma(self) -> float:
        """CBF aggressiveness multiplier"""

    @gamma.setter
    def gamma(self, arg: float, /) -> None: ...

    @property
    def d_safe(self) -> float:
        """Minimum safe distance margin (meters)"""

    @d_safe.setter
    def d_safe(self, arg: float, /) -> None: ...

    @property
    def max_collisions(self) -> int:
        """Get the pre-allocated maximum number of collisions allowed"""

    def set_active(self, arg: bool, /) -> None: ...

class JointVelocityLimitConstraint16(Constraint16):
    def __init__(self, q_min: Annotated[NDArray[numpy.float64], dict(order='C')], q_max: Annotated[NDArray[numpy.float64], dict(order='C')], v_limit: Annotated[NDArray[numpy.float64], dict(order='C')], dt: float = 0.001) -> None: ...

    def update(self, q_curr: Annotated[NDArray[numpy.float64], dict(order='C')]) -> None: ...

    def update_limits(self, q_min: Annotated[NDArray[numpy.float64], dict(order='C')], q_max: Annotated[NDArray[numpy.float64], dict(order='C')], v_limits: Annotated[NDArray[numpy.float64], dict(order='C')]) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    @property
    def q_min(self) -> Annotated[NDArray[numpy.float64], dict(shape=(16), order='C')]:
        """Get minimum joint positions"""

    @property
    def q_max(self) -> Annotated[NDArray[numpy.float64], dict(shape=(16), order='C')]:
        """Get maximum joint positions"""

    @property
    def v_limit(self) -> Annotated[NDArray[numpy.float64], dict(shape=(16), order='C')]:
        """Get maximum joint velocities"""

class DAQPSolver18:
    def __init__(self) -> None: ...

class Task18:
    pass

class Constraint18:
    pass

class Controller18:
    def __init__(self, solver: DAQPSolver18, max_constraint_rows: int = 100) -> None: ...

    def add_task(self, arg: Task18, /) -> None: ...

    def add_constraint(self, arg: Constraint18, /) -> None: ...

    def solve(self) -> Annotated[NDArray[numpy.float64], dict(shape=(18), order='C')]: ...

    def solver_status(self) -> int: ...

    def init_topology(self, macro_regions: Sequence[Sequence[tuple[int, int]]], link_to_region: Sequence[int], id_to_col_shift: int = 0) -> None:
        """
        Compiles the macro regions into explicit KinematicBlocks for all joints at boot time.
        """

    def get_blocks_for_joint(self, joint_id: int) -> list[KinematicBlock]:
        """Returns the O(1) cached KinematicBlocks for a specific joint ID."""

    @property
    def macro_regions(self) -> list[list[tuple[int, int]]]:
        """Get the compiled macro regions (lists of column blocks)"""

    @property
    def joint_to_region(self) -> list[int]:
        """Get the mapping of joint IDs to their respective macro region"""

class JointRegularizationTask18(Task18):
    def __init__(self, dq: float, ddq: float, dddq: float, current_dt: float = 0.001) -> None: ...

    def set_dt(self, dt: float) -> None: ...

    def update_history(self, q_dot_prev: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def reset(self, current_vel: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_joint_multipliers(self, multipliers: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_dq(self, dq: float) -> None: ...

    def set_ddq(self, ddq: float) -> None: ...

    def set_dddq(self, dddq: float) -> None: ...

    def is_active(self) -> bool: ...

    def set_active(self, arg: bool, /) -> None: ...

class LinearVelTask18(Task18):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], tcp_in_base: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')] | None = None) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    def set_weight(self, weight: float) -> None:
        """Real-time safe scalar weight update."""

class AngularVelTask18(Task18):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    def set_weight(self, weight: float) -> None:
        """Real-time safe scalar weight update."""

class SwivelVelTask18(Task18):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, p_s: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], p_e: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], p_w: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], phi_dot_des: float) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

class ContactRepTask18(Task18):
    def __init__(self, max_collisions: int) -> None: ...

    def update(self, Jc_array: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], current_weight: float) -> None:
        """Updates the multi-contact net escape gradient."""

    def is_active(self) -> bool:
        """Returns true if there are active collisions and weight > 0."""

    def set_active(self, active: bool) -> None:
        """Manually toggle the task on or off."""

    def set_weight(self, weight: float) -> None:
        """Set a uniform scalar weight."""

class LinearVelConstraint18(Constraint18):
    def __init__(self, arg0: int, arg1: Sequence[KinematicBlock], /) -> None: ...

    def update(self, global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], v_min: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], v_max: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], r_vec_base: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')] | None = None) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

class CollisionBarrierConstraint18(Constraint18):
    def __init__(self, max_collisions: int, gamma: float, d_safe: float) -> None: ...

    def update_direct(self, Jc_array: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], dist_array: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')]) -> None: ...

    @property
    def gamma(self) -> float:
        """CBF aggressiveness multiplier"""

    @gamma.setter
    def gamma(self, arg: float, /) -> None: ...

    @property
    def d_safe(self) -> float:
        """Minimum safe distance margin (meters)"""

    @d_safe.setter
    def d_safe(self, arg: float, /) -> None: ...

    @property
    def max_collisions(self) -> int:
        """Get the pre-allocated maximum number of collisions allowed"""

    def set_active(self, arg: bool, /) -> None: ...

class JointVelocityLimitConstraint18(Constraint18):
    def __init__(self, q_min: Annotated[NDArray[numpy.float64], dict(order='C')], q_max: Annotated[NDArray[numpy.float64], dict(order='C')], v_limit: Annotated[NDArray[numpy.float64], dict(order='C')], dt: float = 0.001) -> None: ...

    def update(self, q_curr: Annotated[NDArray[numpy.float64], dict(order='C')]) -> None: ...

    def update_limits(self, q_min: Annotated[NDArray[numpy.float64], dict(order='C')], q_max: Annotated[NDArray[numpy.float64], dict(order='C')], v_limits: Annotated[NDArray[numpy.float64], dict(order='C')]) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    @property
    def q_min(self) -> Annotated[NDArray[numpy.float64], dict(shape=(18), order='C')]:
        """Get minimum joint positions"""

    @property
    def q_max(self) -> Annotated[NDArray[numpy.float64], dict(shape=(18), order='C')]:
        """Get maximum joint positions"""

    @property
    def v_limit(self) -> Annotated[NDArray[numpy.float64], dict(shape=(18), order='C')]:
        """Get maximum joint velocities"""

class DAQPSolver19:
    def __init__(self) -> None: ...

class Task19:
    pass

class Constraint19:
    pass

class Controller19:
    def __init__(self, solver: DAQPSolver19, max_constraint_rows: int = 100) -> None: ...

    def add_task(self, arg: Task19, /) -> None: ...

    def add_constraint(self, arg: Constraint19, /) -> None: ...

    def solve(self) -> Annotated[NDArray[numpy.float64], dict(shape=(19), order='C')]: ...

    def solver_status(self) -> int: ...

    def init_topology(self, macro_regions: Sequence[Sequence[tuple[int, int]]], link_to_region: Sequence[int], id_to_col_shift: int = 0) -> None:
        """
        Compiles the macro regions into explicit KinematicBlocks for all joints at boot time.
        """

    def get_blocks_for_joint(self, joint_id: int) -> list[KinematicBlock]:
        """Returns the O(1) cached KinematicBlocks for a specific joint ID."""

    @property
    def macro_regions(self) -> list[list[tuple[int, int]]]:
        """Get the compiled macro regions (lists of column blocks)"""

    @property
    def joint_to_region(self) -> list[int]:
        """Get the mapping of joint IDs to their respective macro region"""

class JointRegularizationTask19(Task19):
    def __init__(self, dq: float, ddq: float, dddq: float, current_dt: float = 0.001) -> None: ...

    def set_dt(self, dt: float) -> None: ...

    def update_history(self, q_dot_prev: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def reset(self, current_vel: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_joint_multipliers(self, multipliers: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_dq(self, dq: float) -> None: ...

    def set_ddq(self, ddq: float) -> None: ...

    def set_dddq(self, dddq: float) -> None: ...

    def is_active(self) -> bool: ...

    def set_active(self, arg: bool, /) -> None: ...

class LinearVelTask19(Task19):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], tcp_in_base: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')] | None = None) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    def set_weight(self, weight: float) -> None:
        """Real-time safe scalar weight update."""

class AngularVelTask19(Task19):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')]) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    def set_weight(self, weight: float) -> None:
        """Real-time safe scalar weight update."""

class SwivelVelTask19(Task19):
    def __init__(self, arg0: Sequence[KinematicBlock], arg1: float, /) -> None: ...

    def update(self, p_s: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], p_e: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], p_w: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], phi_dot_des: float) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

class ContactRepTask19(Task19):
    def __init__(self, max_collisions: int) -> None: ...

    def update(self, Jc_array: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], current_weight: float) -> None:
        """Updates the multi-contact net escape gradient."""

    def is_active(self) -> bool:
        """Returns true if there are active collisions and weight > 0."""

    def set_active(self, active: bool) -> None:
        """Manually toggle the task on or off."""

    def set_weight(self, weight: float) -> None:
        """Set a uniform scalar weight."""

class LinearVelConstraint19(Constraint19):
    def __init__(self, arg0: int, arg1: Sequence[KinematicBlock], /) -> None: ...

    def update(self, global_jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], v_min: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], v_max: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')], r_vec_base: Annotated[NDArray[numpy.float64], dict(order='C', device='cpu')] | None = None) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

class CollisionBarrierConstraint19(Constraint19):
    def __init__(self, max_collisions: int, gamma: float, d_safe: float) -> None: ...

    def update_direct(self, Jc_array: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], dist_array: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')]) -> None: ...

    @property
    def gamma(self) -> float:
        """CBF aggressiveness multiplier"""

    @gamma.setter
    def gamma(self, arg: float, /) -> None: ...

    @property
    def d_safe(self) -> float:
        """Minimum safe distance margin (meters)"""

    @d_safe.setter
    def d_safe(self, arg: float, /) -> None: ...

    @property
    def max_collisions(self) -> int:
        """Get the pre-allocated maximum number of collisions allowed"""

    def set_active(self, arg: bool, /) -> None: ...

class JointVelocityLimitConstraint19(Constraint19):
    def __init__(self, q_min: Annotated[NDArray[numpy.float64], dict(order='C')], q_max: Annotated[NDArray[numpy.float64], dict(order='C')], v_limit: Annotated[NDArray[numpy.float64], dict(order='C')], dt: float = 0.001) -> None: ...

    def update(self, q_curr: Annotated[NDArray[numpy.float64], dict(order='C')]) -> None: ...

    def update_limits(self, q_min: Annotated[NDArray[numpy.float64], dict(order='C')], q_max: Annotated[NDArray[numpy.float64], dict(order='C')], v_limits: Annotated[NDArray[numpy.float64], dict(order='C')]) -> None: ...

    def set_active(self, arg: bool, /) -> None: ...

    @property
    def q_min(self) -> Annotated[NDArray[numpy.float64], dict(shape=(19), order='C')]:
        """Get minimum joint positions"""

    @property
    def q_max(self) -> Annotated[NDArray[numpy.float64], dict(shape=(19), order='C')]:
        """Get maximum joint positions"""

    @property
    def v_limit(self) -> Annotated[NDArray[numpy.float64], dict(shape=(19), order='C')]:
        """Get maximum joint velocities"""
