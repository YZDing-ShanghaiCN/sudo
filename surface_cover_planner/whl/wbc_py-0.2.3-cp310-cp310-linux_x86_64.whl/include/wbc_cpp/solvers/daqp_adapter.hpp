#pragma once
#include "solver_base.hpp"

// extern "C" {
// #include "wbc_cpp/external/daqp/api.h"
// #include "wbc_cpp/external/daqp/daqp.h"
// }

#include "wbc_cpp/external/daqp/daqp.hpp"
namespace WBC {

template <int N_VAR> class DAQPSolver : public QPSolver<N_VAR> {
public:
  using Base = QPSolver<N_VAR>;
  using typename Base::Matrix;
  using typename Base::MatrixDyn;
  using typename Base::Vector;
  using typename Base::VectorDyn;

  DAQPSolver() {}

  // 可以在这里预分配内存，或者让 DAQP 自动管理
  void init(int max_constraints = 100) override {}

  Vector solve(const Eigen::Ref<const Matrix> &H,
               const Eigen::Ref<const Vector> &g,
               const Eigen::Ref<const MatrixDyn> &A,
               const Eigen::Ref<const VectorDyn> &lb,
               const Eigen::Ref<const VectorDyn> &ub) override {

    // 1. 填充 QP 问题结构体

    Eigen::VectorXd qp_lb = lb;
    Eigen::VectorXd qp_ub = ub;
    Eigen::MatrixXd qp_A = A;
    Eigen::MatrixXd qp_H = H;
    Eigen::VectorXd qp_g = g;

    EigenDAQPResult result2 = daqp_solve(qp_H, qp_g, qp_A, qp_ub, qp_lb);

    Vector x_sol = result2.get_primal();
    _solver_status = result2.exitflag;
    // std::cout << "\n[DAQP DEBUG] EXIT FLAG:" << result2.exitflag <<
    // std::endl;
    if (0) {

      std::cout << "\n[DAQP DEBUG] Matrix Inspection (First Run Only):"
                << std::endl;
      std::cout << "------------------------------------------------"
                << std::endl;

      // Eigen's default print format is usually fine, but clean it up slightly
      Eigen::IOFormat CleanFmt(4, 0, ", ", "\n", "[", "]");

      std::cout << "H (Hessian) [" << H.rows() << "x" << H.cols() << "]:\n"
                << H.format(CleanFmt) << "\n"
                << std::endl;

      std::cout << "g (Gradient) [" << g.size() << "]:\n"
                << g.transpose().format(CleanFmt) << "\n"
                << std::endl;

      std::cout << "A (Constraints) [" << A.rows() << "x" << A.cols() << "]:\n"
                << A.format(CleanFmt) << "\n"
                << std::endl;

      std::cout << "lb (Lower Bounds) [" << lb.size() << "]:\n"
                << lb.transpose().format(CleanFmt) << "\n"
                << std::endl;

      std::cout << "ub (Upper Bounds) [" << ub.size() << "]:\n"
                << ub.transpose().format(CleanFmt) << "\n"
                << std::endl;
      std::cout << "x_sol             [" << x_sol.size() << "]:\n"
                << x_sol.transpose().format(CleanFmt) << "\n"
                << std::endl;
      std::cout << "x_sol             [" << x_sol.size() << "]:\n"
                << (A * x_sol).transpose().format(CleanFmt) << "\n"
                << std::endl;
      std::cout << "------------------------------------------------"
                << std::endl;
      // is_first_run = false; // Set to false to stop printing
    }

    // for (int i = 0; i < N_VAR; ++i) {
    //   x_sol[i] = work_.x[i];
    // }

    return x_sol;
  }
  int get_solver_status() const override { return _solver_status; };

private:
  int _solver_status = -1;
  void free_workspace() {}
};

} // namespace WBC