#pragma once
#include <Eigen/Dense>

namespace WBC {

/**
 * @brief QP Solver Abstract Base Class
 * Solves: min 0.5 * x'Hx + g'x
 * s.t. lb <= A*x <= ub
 * * @tparam N_VAR Number of decision variables (compile-time constant)
 */
template <int N_VAR> class QPSolver {
public:
  using Matrix = Eigen::Matrix<double, N_VAR, N_VAR>;
  using Vector = Eigen::Matrix<double, N_VAR, 1>;
  using MatrixDyn = Eigen::Matrix<double, Eigen::Dynamic, N_VAR>;
  using VectorDyn = Eigen::Matrix<double, Eigen::Dynamic, 1>;

  virtual ~QPSolver() = default;

  /**
   * @brief 初始化求解器 (分配内存、设置设置等)
   * @param max_constraints 预估的最大约束行数 (用于预分配内存)
   */
  virtual void init(int max_constraints = 100) = 0;

  /**
   * @brief 求解 QP 问题
   * * @param H  Hessian matrix (N_VAR x N_VAR)
   * @param g  Gradient vector (N_VAR)
   * @param A  Constraint matrix (n_constr x N_VAR)
   * @param lb Lower bound vector (n_constr)
   * @param ub Upper bound vector (n_constr)
   * @return   Optimal solution vector x
   */
  virtual Vector solve(const Eigen::Ref<const Matrix> &H,
                       const Eigen::Ref<const Vector> &g,
                       const Eigen::Ref<const MatrixDyn> &A,
                       const Eigen::Ref<const VectorDyn> &lb,
                       const Eigen::Ref<const VectorDyn> &ub) = 0;

  virtual int get_solver_status() const = 0;
};

} // namespace WBC