#pragma once

#include "solvers/solver_base.hpp"
#include <Eigen/Dense>
#include <iostream>
#include <vector>

// 1. Check if we are in Debug mode.
// Standard CMake 'Debug' builds usually define _DEBUG or NDEBUG is NOT defined.
//#if !defined(NDEBUG) || defined(_DEBUG) || defined(DEBUG_ENABLED)
#ifdef WBC_DEBUG_ENABLED

// The Macro: [FILE:LINE] Message
#define LOG_DEBUG(msg)                                                         \
  std::cout << "[DEBUG] [" << __FILE__ << ":" << __LINE__ << "] " << msg       \
            << std::endl

// A more advanced version for multiple arguments (C++11 and up)
#define LOG_VAR(name, value)                                                   \
  std::cout << "[DEBUG] " << name << " = " << value << std::endl

#else
// In Release mode, these expand to nothing (zero overhead)
#define LOG_DEBUG(msg)                                                         \
  do {                                                                         \
  } while (0)
#define LOG_VAR(name, value)                                                   \
  do {                                                                         \
  } while (0)
#endif

namespace WBC {

template <int N_VAR> class Core {
public:
  using Vector = Eigen::Matrix<double, N_VAR, 1>;
  using Matrix = Eigen::Matrix<double, N_VAR, N_VAR>;
  using MatrixDyn = Eigen::Matrix<double, Eigen::Dynamic, N_VAR>;
  using VectorDyn = Eigen::Matrix<double, Eigen::Dynamic, 1>;

  template <int HistoryLength> class History {
  public:
    virtual ~History() = default;
    void update(const double *current_q, const double *current_dq,
                double current_dt) = 0;
  };

  class Task {
  public:
    virtual ~Task() = default;

    virtual void compute_cost(Eigen::Ref<Matrix> H, Eigen::Ref<Vector> g) = 0;
    virtual void set_weight(const double *w_ptr, uint32_t nb_w) = 0;
    virtual void set_dt(double dt) = 0;
    virtual void set_active(bool active) = 0;
    virtual bool is_active() const = 0;
  };

  class Constraint {
  public:
    virtual ~Constraint() = default;
    virtual int get_rows() const = 0;
    virtual void compute_constraint(Eigen::Ref<MatrixDyn> A,
                                    Eigen::Ref<VectorDyn> lb,
                                    Eigen::Ref<VectorDyn> ub) = 0;

    virtual void set_active(bool active) = 0;
    virtual bool is_active() const = 0;

    // virtual void set_active(bool active) = 0;
    // virtual bool is_active() const = 0;
  };

  class Controller {
  public:
    explicit Controller(QPSolver<N_VAR> *solver) : solver_(solver) {
      H_sum_.setZero();
      g_sum_.setZero();
      if (solver_)
        solver_->init();
    }

    void add_task(Task *task) { tasks_.push_back(task); }
    void add_constraint(Constraint *constraint) {
      constraints_.push_back(constraint);
    }

    Vector solve() {
      H_sum_.setIdentity();
      H_sum_ *= 1e-8;
      g_sum_.setZero();

      for (auto *task : tasks_) {
        task->compute_cost(H_sum_, g_sum_);
      }

      int total_rows = 0;
      for (auto *c : constraints_) {
        if (!c->is_active())
          continue;
        if (c->get_rows() <= 0)
          continue;
        total_rows += c->get_rows();
      }

      MatrixDyn A_all(total_rows, N_VAR);
      VectorDyn lb_all(total_rows);
      VectorDyn ub_all(total_rows);

      int current_row = 0;
      for (auto *c : constraints_) {
        if (!c->is_active())
          continue;
        int r = c->get_rows();
        if (r <= 0)
          continue;
        c->compute_constraint(A_all.block(current_row, 0, r, N_VAR),
                              lb_all.segment(current_row, r),
                              ub_all.segment(current_row, r));
        current_row += r;
      }

      if (!solver_) {
        throw std::runtime_error("No QP solver attached!");
      }
      LOG_VAR("QP SIZE", A_all.rows());
      return solver_->solve(H_sum_, g_sum_, A_all, lb_all, ub_all);
    }

    int solver_status() { return solver_->get_solver_status(); };

  private:
    QPSolver<N_VAR> *solver_;
    std::vector<Task *> tasks_;
    std::vector<Constraint *> constraints_;

    Matrix H_sum_;
    Vector g_sum_;

    Vector run_qp_solver(const Matrix &H, const Vector &g, const MatrixDyn &A,
                         const VectorDyn &lb, const VectorDyn &ub) {
      std::cout << "[Solver] H size: " << H.rows() << "x" << H.cols() << "\n";
      std::cout << "[Solver] A size: " << A.rows() << "x" << A.cols() << "\n";
      return -H.inverse() * g;
    }
  };
};

} // namespace WBC