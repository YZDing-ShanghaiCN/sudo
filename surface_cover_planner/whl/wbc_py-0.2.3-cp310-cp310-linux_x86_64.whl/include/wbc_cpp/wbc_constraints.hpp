#pragma once
#include "wbc_core.hpp"

namespace WBC {

template <int N_VAR>
class CollisionBarrierConstraint : public Core<N_VAR>::Constraint {
public:
  CollisionBarrierConstraint(int num_max_constraints, double weight)
      : weight_(weight), num_max_constraints_(num_max_constraints),
        active_(true) {}
  int get_rows() const override {
    return num_max_constraints_; // 每一行对应一个关节的速度限制
  }
  void set_weight(double w) { weight_ = w; }
  void clear() {
    // A.setZero(); // 确保其他地方是0
    // ub.setConstant(std::numeric_limits<double>::max());
    // lb.setConstant(-1 * std::numeric_limits<double>::max());
  }
  void update(const double *J_ptr, const double *d_ptr, const int *l_ptr,
              int num_constraint) {
    num_constraints_ = num_constraint;
    Eigen::Map<const Eigen::Matrix<double, Eigen::Dynamic, N_VAR>> J_map(
        J_ptr, num_constraint, N_VAR);
    J_ = J_map;
    Eigen::Map<const Eigen::Vector<double, -1>> d_map(d_ptr, num_constraint);
    d_ = d_map;
    // Eigen::Map<const Eigen::Vector<int, -1>> l_map(l_ptr);
    // l_ = l_map;
    // std::cout << J_ << std::endl;
    // std::cout << d_.transpose << std::endl;
    // 2. 映射或使用现有方向
    // if (dir_ptr) {
    //   Eigen::Map<const Eigen::Vector3d> dir_map(dir_ptr);
    //   // update_internal(J_map, dir_map);
    //   direction_ = dir_map;
    // }
  }
  void
  compute_constraint(Eigen::Ref<typename Core<N_VAR>::MatrixDyn> A,
                     Eigen::Ref<typename Core<N_VAR>::VectorDyn> lb,
                     Eigen::Ref<typename Core<N_VAR>::VectorDyn> ub) override {

    A.setZero(); // 确保其他地方是0
    ub.setConstant(std::numeric_limits<double>::max());
    lb.setConstant(-1 * std::numeric_limits<double>::max());

    if (J_.rows() == 0)
      return;

    // std::cout << A.rows() << std::endl;
    // std::cout << A.cols() << std::endl;
    // std::cout << J_.rows() << std::endl;
    // std::cout << J_.cols() << std::endl;

    A.block(0, 0, num_constraints_, N_VAR) = J_;
    lb.head(num_constraints_) = -1 * weight_ * d_;

    // for (int i = 0; i < num_constraints_; i++) {
    //   A
    // }
    // printf("done! \n");
  }
  bool is_active() const override { return active_; };
  void set_active(bool active) override { active_ = active; };

private:
  int num_constraints_;
  int num_max_constraints_;
  double weight_;
  Eigen::Matrix<double, -1, N_VAR> J_;
  Eigen::Vector<double, -1> d_;
  Eigen::Vector<int, -1> l_;

  bool active_;
};

template <int N_VAR>
class JointLimitConstraint : public Core<N_VAR>::Constraint {
public:
  JointLimitConstraint(int start_idx, int num_dof, const double *q_min_ptr,
                       const double *q_max_ptr, double dt = 0.001)
      : start_idx_(start_idx), num_dof_(num_dof), dt_(dt), active_(true) {
    // 保存极限值 (Map复制到内部存储)
    q_min_ = Eigen::Map<const Eigen::VectorXd>(q_min_ptr, num_dof);
    q_max_ = Eigen::Map<const Eigen::VectorXd>(q_max_ptr, num_dof);
  }

  void update(const double *q_curr_ptr) {
    q_curr_ = Eigen::Map<const Eigen::VectorXd>(q_curr_ptr, num_dof_);
  }

  int get_rows() const override {
    return num_dof_; // 每一行对应一个关节的速度限制
  }

  void
  compute_constraint(Eigen::Ref<typename Core<N_VAR>::MatrixDyn> A,
                     Eigen::Ref<typename Core<N_VAR>::VectorDyn> lb,
                     Eigen::Ref<typename Core<N_VAR>::VectorDyn> ub) override {
    A.setZero(); // 确保其他地方是0
    A.block(0, start_idx_, num_dof_, num_dof_).setIdentity();

    // 2. 计算速度限制: (q_lim - q_curr) / dt
    // 使用 array() 进行元素级运算
    lb = (q_min_ - q_curr_) / dt_;
    ub = (q_max_ - q_curr_) / dt_;
  }
  bool is_active() const override { return active_; };
  void set_active(bool active) override { active_ = active; };

private:
  int start_idx_;
  int num_dof_;
  double dt_;
  Eigen::VectorXd q_min_, q_max_, q_curr_;
  bool active_;
};

template <int N_VAR>
class JointVelocityLimitConstraint : public Core<N_VAR>::Constraint {
public:
  // 使用基类的类型定义
  // using Base = typename Core<N_VAR>::Constraint;
  // using MatrixDyn = typename Base::MatrixDyn;
  // using VectorDyn = typename Base::VectorDyn;

  /**
   * @brief 构造函数
   * @param v_limit_ptr 指向最大速度限制数组的指针 (假设是对称的: -v_lim <= v <=
   * v_lim)
   */
  JointVelocityLimitConstraint(
      int start_idx, int num_dof, const double *q_min_ptr,
      const double *q_max_ptr,
      const double *v_limit_ptr, // 【新增】速度限制输入
      double dt = 0.001)
      : start_idx_(start_idx), num_dof_(num_dof), dt_(dt), active_(true) {

    // 1. 初始化内部存储
    // 我们需要把外部数据拷贝到自己的 VectorXd 中，以防外部指针失效
    q_min_ = Eigen::Map<const Eigen::VectorXd>(q_min_ptr, num_dof);
    q_max_ = Eigen::Map<const Eigen::VectorXd>(q_max_ptr, num_dof);

    // 【新增】保存速度限制
    v_limit_ = Eigen::Map<const Eigen::VectorXd>(v_limit_ptr, num_dof);

    // 初始化 q_curr 为 0，防止第一次 update 前调用出错
    q_curr_.setZero(num_dof);
  }

  // 获取约束行数
  int get_rows() const override { return num_dof_; }

  // 更新当前关节位置
  void update(const double *q_curr_ptr) {
    q_curr_ = Eigen::Map<const Eigen::VectorXd>(q_curr_ptr, num_dof_);
  }

  void update(const double *q_min_ptr, const double *q_max_ptr) {
    q_min_ = Eigen::Map<const Eigen::VectorXd>(q_min_ptr, num_dof_);
    q_max_ = Eigen::Map<const Eigen::VectorXd>(q_max_ptr, num_dof_);
  }

  void update_velocity_limits(const double *v_lim_ptr) {
    v_limit_ = Eigen::Map<const Eigen::VectorXd>(v_lim_ptr, num_dof_);
  }

  // 【核心逻辑】计算 A, lb, ub
  void
  compute_constraint(Eigen::Ref<typename Core<N_VAR>::MatrixDyn> A,
                     Eigen::Ref<typename Core<N_VAR>::VectorDyn> lb,
                     Eigen::Ref<typename Core<N_VAR>::VectorDyn> ub) override {
    // ---------------------------------------------------------
    // 1. 设置 A 矩阵 (单位矩阵)
    // ---------------------------------------------------------
    // 约束形式: lb <= I * qdot <= ub
    A.setZero();
    A.block(0, start_idx_, num_dof_, num_dof_).setIdentity();

    // ---------------------------------------------------------
    // 2. 计算位置推导出的速度界限 (Position-based Velocity Limits)
    // ---------------------------------------------------------
    // v_pos_min = (q_min - q) / dt
    // v_pos_max = (q_max - q) / dt
    // 这里使用临时变量，也可以直接计算到 lb/ub 中暂存

    // std::cout << dt_ << std::endl;
    Eigen::VectorXd lb_pos = (q_min_ - q_curr_) / dt_;
    Eigen::VectorXd ub_pos = (q_max_ - q_curr_) / dt_;

    // std::cout << q_min_.transpose() << std::endl;
    // std::cout << q_max_.transpose() << std::endl;
    // std::cout << q_curr_.transpose() << std::endl;
    // std::cout << lb_pos.transpose() << std::endl;
    // std::cout << ub_pos.transpose() << std::endl;
    // ---------------------------------------------------------
    // 3. 计算最终界限 (取交集 / Clamp)
    // ---------------------------------------------------------
    // 最终下界: max(位置下界, -速度极限)
    // 最终上界: min(位置上界, +速度极限)

    // cwiseMax/Min 是 Eigen 的元素级比较函数
    lb = lb_pos.cwiseMax(-v_limit_);
    ub = ub_pos.cwiseMin(v_limit_);
  }
  bool is_active() const override { return active_; };
  void set_active(bool active) override { active_ = active; };

private:
  bool active_;
  int start_idx_;
  int num_dof_;
  double dt_;

  Eigen::VectorXd q_min_;
  Eigen::VectorXd q_max_;
  Eigen::VectorXd v_limit_; // 【新增】存储 v_max
  Eigen::VectorXd q_curr_;
};

template <int N_VAR>
class CartesianVelocityConstraint : public Core<N_VAR>::Constraint {
public:
  using Base = typename Core<N_VAR>::Constraint;
  // 使用与 Base 相同的类型定义
  using MatrixDyn = Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>;
  using VectorDyn = Eigen::Matrix<double, Eigen::Dynamic, 1>;

  // 为了内部存储高效，我们可以固定列数为 N_VAR
  using MatrixStorage = Eigen::Matrix<double, Eigen::Dynamic, N_VAR>;

  /**
   * @brief 构造函数
   * @param rows 约束的维数 (例如 3 for Position, 6 for Pose)
   */
  CartesianVelocityConstraint(int rows) : m_rows(rows), active_(true) {
    // 预分配内部存储空间
    J_.setZero(rows, N_VAR);
    lb_.setZero(rows);
    ub_.setZero(rows);
  }

  // 1. 实现基类纯虚函数: 返回行数
  int get_rows() const override { return m_rows; }

  // 2. 实现基类纯虚函数: 填充求解器矩阵
  // 注意：这里的 A, lb, ub 是 Solver 提供的内存引用
  void
  compute_constraint(Eigen::Ref<typename Core<N_VAR>::MatrixDyn> A,
                     Eigen::Ref<typename Core<N_VAR>::VectorDyn> lb,
                     Eigen::Ref<typename Core<N_VAR>::VectorDyn> ub) override {
    // 简单的数据拷贝
    // 约束形式: lb <= J * qdot <= ub

    // 确保维度安全 (Debug 模式下)
    assert(A.rows() == m_rows && A.cols() == N_VAR);

    A = J_;   // 将内部存储的雅可比填入约束矩阵 A
    lb = lb_; // 填入下界
    ub = ub_; // 填入上界
  }

  /**
   * @brief 更新约束参数 (通常由控制循环调用)
   * @param J 当前的雅可比矩阵
   * @param v_min 最小笛卡尔速度
   * @param v_max 最大笛卡尔速度
   */
  void update(const Eigen::Ref<const MatrixDyn> &J,
              const Eigen::Ref<const VectorDyn> &v_min,
              const Eigen::Ref<const VectorDyn> &v_max) {

    if (J.rows() != m_rows || J.cols() != N_VAR) {
      std::cerr
          << "[CartesianVelocityConstraint] Dimension mismatch in update!\n";
      return;
    }

    // 将外部数据存入内部缓存
    J_ = J;
    lb_ = v_min;
    ub_ = v_max;
  }

  bool is_active() const override { return active_; };
  void set_active(bool active) override { active_ = active; };

private:
  bool active_;
  int m_rows;

  // 内部缓存 (用于在 update() 和 compute_constraint() 之间传递数据)
  MatrixStorage J_;
  Eigen::VectorXd lb_;
  Eigen::VectorXd ub_;
};
} // namespace WBC