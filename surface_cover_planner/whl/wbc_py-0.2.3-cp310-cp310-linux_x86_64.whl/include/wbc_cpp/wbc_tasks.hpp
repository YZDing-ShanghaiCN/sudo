#pragma once
#include "wbc_core.hpp"

namespace WBC {

// ========================================================
// 任务 1: 姿态保持/阻尼 (Configuration / Damping Task)
// Cost = 0.5 * weight * || q_dot ||^2
// ========================================================
template <int N_VAR> class DampingTask : public Core<N_VAR>::Task {
public:
  using Base = typename Core<N_VAR>::Task; // 类型别名方便引用

  void set_weight(const double *weights, uint32_t nb_w) override {
    if (nb_w == 1) {
      W_diagonal_.setConstant(weights[0]);
    } else {
      W_diagonal_ = Eigen::Map<const Eigen::Matrix<double, N_VAR, 1>>(weights);
    }
  };
  void set_dt(double dt) override{};

  DampingTask(const std::vector<double> &weights) {

    set_weight(weights.data(), weights.size());
    set_active(true);
  }
  void compute_cost(Eigen::Ref<typename Core<N_VAR>::Matrix> H,
                    Eigen::Ref<typename Core<N_VAR>::Vector> g) override {

    H.diagonal().array() += W_diagonal_.array();
  }
  bool is_active() const override { return active_; };
  void set_active(bool active) override { active_ = active; };

private:
  Eigen::Matrix<double, N_VAR, 1> W_diagonal_;
  bool active_;
};

template <int N_VAR> class SmoothnessTask : public Core<N_VAR>::Task {
public:
  bool is_active() const override { return active_; };
  void set_active(bool active) override { active_ = active; };
  void set_dt(double dt) override{};
  /**
   * @brief 构造函数
   * @param weight 平滑权重 (权重越大，动作越迟缓/平滑)
   */
  SmoothnessTask(double weight = 0.1) : weight_(weight) {
    q_dot_prev_.setZero(N_VAR);
    set_active(true);
  }
  void set_weight(const double *weights, uint32_t nb_w) override {
    weight_ = weights[0];
  }

  /**
   * @brief 更新上一帧的状态
   * @param q_dot_prev 上一次 QP 求解出的速度指令
   */
  void update(const double *q_dot_prev_ptr) {
    // if (q_dot_prev.size() != N_VAR) {
    //   std::cerr << "[SmoothnessTask] Dimension mismatch!\n";
    //   return;
    // }
    q_dot_prev_ = Eigen::Map<const Eigen::VectorXd>(q_dot_prev_ptr, N_VAR);
    // q_dot_prev_ = q_dot_prev;
  }

  // 实现基类接口
  void compute_cost(Eigen::Ref<typename Core<N_VAR>::Matrix> H,
                    Eigen::Ref<typename Core<N_VAR>::Vector> g) override {
    // 目标函数: min weight * || x - x_prev ||^2
    // 展开: weight * (x'x - 2*x_prev'*x + ...)

    // 1. H 矩阵增加对角项 (阻尼作用)
    // H += weight * I
    for (int i = 0; i < N_VAR; ++i) {
      H(i, i) += weight_;
    }

    // 2. g 向量增加偏置项 (拉向上一帧)
    // g += -weight * x_prev
    g -= weight_ * q_dot_prev_;
  }

  // 允许动态调整权重
  // void set_weight(double w) { weight_ = w; }

private:
  double weight_;
  Eigen::Matrix<double, N_VAR, 1> q_dot_prev_;
  bool active_;
};

template <int N_VAR> class JerkTask : public Core<N_VAR>::Task {
public:
  using Base = typename Core<N_VAR>::Task;
  bool is_active() const override { return active_; };
  void set_active(bool active) override { active_ = active; };
  void set_dt(double dt) override { dt_ = dt; }
  void set_weight(const double *weights, uint32_t nb_w) override {
    weight_eff_ = weights[0] / (dt_ * dt_);
  }
  JerkTask(double weight, double dt = 0.001) {
    set_active(true);
    q_dot_prev_.setZero(N_VAR);
    q_dot_pprev_.setZero(N_VAR); // previous-previous (k-2)
    // 有效权重需要除以 dt^4 吗？通常不需要那么严格，
    // 只要相对权重合适即可。这里为了数值稳定性，我们归一化一下。
    // Jerk = d(acc)/dt = d^2(vel)/dt^2
    // 为了让权重直观，我们内部处理一下 scaling
    dt_ = dt;
    weight_eff_ = weight / (dt * dt);
  }

  /**
   * @brief 更新状态
   * @param q_dot_curr_measured 当前测量到的(或上一帧指令的)速度
   */
  void update(const double *q_dot_k_minus_1_ptr) {
    // 1. 移动历史窗口
    // q(k-2) = q(k-1)
    q_dot_pprev_ = q_dot_prev_;

    // 2. 更新最近一帧
    // q(k-1) = input
    q_dot_prev_ = Eigen::Map<const Eigen::VectorXd>(q_dot_k_minus_1_ptr, N_VAR);
    ;
  }

  void compute_cost(Eigen::Ref<typename Core<N_VAR>::Matrix> H,
                    Eigen::Ref<typename Core<N_VAR>::Vector> g) override {
    // 目标: min || q_dot_k - (2*q_prev - q_pprev) ||^2

    // 1. 计算基于恒定加速度的预测速度
    // v_target = q_prev + (q_prev - q_pprev)
    //          = 2 * q_prev - q_pprev
    Eigen::VectorXd v_target = 2.0 * q_dot_prev_ - q_dot_pprev_;

    // 2. 填充 QP
    // Cost = 0.5 * x'Hx + g'x
    // 展开 w * || x - v_t ||^2 -> w * (x'x - 2v_t'x + ...)

    // H += 2 * w * I (通常QP库也是 0.5 系数，所以这里填 2*w 还是 w 取决于库)
    // 假设 QP solver 是 min 0.5 xHx + gx
    // 那么 ||x-v||^2 = x'x - 2v'x
    // H 的对角线加 2.0 * weight
    // g 加 -2.0 * weight * v_target
    // 但通常为了方便调节，我们直接加 weight 到对角线，把 2 约掉。

    // H += w * I
    for (int i = 0; i < N_VAR; ++i) {
      H(i, i) += weight_eff_;
    }

    // g -= w * v_target
    g -= weight_eff_ * v_target;
  }

  // 手动复位（例如机器人重启时）
  void reset(const double *current_vel) {
    q_dot_prev_ = Eigen::Map<const Eigen::VectorXd>(current_vel, N_VAR);
    q_dot_pprev_ = q_dot_prev_; // 假设初始加速度为 0
  }

private:
  // double weight_;
  double weight_eff_;
  double dt_;
  bool active_;
  Eigen::VectorXd q_dot_prev_;  // k-1
  Eigen::VectorXd q_dot_pprev_; // k-2
};

template <int N_VAR> class GravityTask : public Core<N_VAR>::Task {
public:
  using Base = typename Core<N_VAR>::Task;
  using MatrixDyn = Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>;
  using VectorDyn = Eigen::Matrix<double, Eigen::Dynamic, 1>;
  bool is_active() const override { return active_; };
  void set_active(bool active) override { active_ = active; };
  void set_dt(double dt) override {}
  void set_weight(const double *weights, uint32_t nb_w) override {
    weight_ = weights[0];
  }
  GravityTask(double weight = 1.0) : weight_(weight) {
    set_active(true);
    direction_ << 0.0, 0.0, -1;
  }

  void update(const double *J_ptr, const double *dir_ptr = nullptr) {
    Eigen::Map<const Eigen::Matrix<double, 3, Eigen::Dynamic>> J_map(J_ptr, 3,
                                                                     N_VAR);
    // std::cout << "J_map" << std::endl;
    // std::cout << J_map << std::endl;
    J_ = J_map;
    if (dir_ptr) {
      Eigen::Map<const Eigen::Vector3d> dir_map(dir_ptr);
      direction_ = dir_map;
    }
  }

  // 实现基类接口：填充 H 和 g
  void compute_cost(Eigen::Ref<typename Core<N_VAR>::Matrix> H,
                    Eigen::Ref<typename Core<N_VAR>::Vector> g) override {
    // 公式: g += -weight * J^T * direction
    // 注意：不修改 H，因为这是一个纯线性偏置项，没有 "目标值" 的概念

    H += weight_ * (J_.transpose() * J_);

    // std::cout << (J_) << std::endl;

    g -= weight_ * (J_.transpose() * direction_);

    // Cost = 0.5 * x'Hx + g'x
    // 展开 w * || x0 + J dq - xt ||^2
    // 展开 (x0  - xt )^T J dq
    // 展开 -J^T (xt  - x0 )

    // std::cout << "g" << weight_ << " [] "
    //           << ((direction_)).transpose(); std::cout << std::endl;
  }

private:
  double weight_;
  Eigen::Vector3d direction_;

  // 内部缓存雅可比
  Eigen::Matrix<double, 3, N_VAR> J_;
  bool active_;
};
// ========================================================
// 任务 2: 线性速度跟踪 (Linear Velocity Tracking)
// Cost = weight * || J_lin * q_dot - v_des ||^2
// ========================================================
template <int N_VAR> class LinearVelocityTask : public Core<N_VAR>::Task {
public:
  bool is_active() const override { return active_; };
  void set_active(bool active) override { active_ = active; };
  void set_dt(double dt) override {}
  void set_weight(const double *weights, uint32_t nb_w) override {
    weight_ = weights[0];
  }
  // start_idx: 该任务涉及的机构在全局向量中的起始位置
  // num_dof:   该任务涉及的机构的自由度数
  LinearVelocityTask(int start_idx, int num_dof, double weight)
      : start_idx_(start_idx), num_dof_(num_dof), weight_(weight) {
    set_active(true);
  }

  // 用户在循环中调用此函数更新数据 (传入原始指针)
  // jacobian_ptr: 必须指向 6 x num_dof 的数组 (列优先或行优先需一致)
  // target_ptr:   必须指向 3个double (vx, vy, vz)
  void update(const double *jacobian_ptr, const double *target_ptr) {
    // Map 原始数据，零拷贝
    // 假设 jacobian_ptr 是按列存储的 6xN 矩阵
    // 我们只取前3行 (线性部分)
    // Eigen::Map 默认是列优先 (Column Major)
    raw_J_ = Eigen::Map<const Eigen::Matrix<double, 6, Eigen::Dynamic>>(
        jacobian_ptr, 6, num_dof_);
    //
    //  提取线性部分 (前3行)
    J_linear_ = raw_J_.topRows(3);

    // Map 目标速度
    v_des_ = Eigen::Map<const Eigen::Vector3d>(target_ptr);
    // std::cout << raw_J_ << std::endl;
    // std::cout << J_linear_ << std::endl;
  }

  void compute_cost(Eigen::Ref<typename Core<N_VAR>::Matrix> H,
                    Eigen::Ref<typename Core<N_VAR>::Vector> g) override {
    // 局部 Cost: H_local = w * J^T * J
    // 我们需要把局部 H 放到全局 H 的正确位置 (start_idx_)

    // Block 操作：H.block(row, col, rows, cols)
    // 这是一个引用操作，直接修改全局矩阵内存

    // 1. Hessian 贡献
    H.block(start_idx_, start_idx_, num_dof_, num_dof_) +=
        weight_ * (J_linear_.transpose() * J_linear_);

    // 2. Gradient 贡献: g = -w * J^T * v_des
    g.segment(start_idx_, num_dof_) +=
        -weight_ * (J_linear_.transpose() * v_des_);

    // std::cout << H << std::endl;
  }

private:
  int start_idx_;
  int num_dof_;
  double weight_;
  bool active_;

  // 内部缓存，避免重复分配
  // 注意：如果是 realtime，最好预分配最大尺寸或使用 Dynamic
  Eigen::Matrix<double, 6, Eigen::Dynamic> raw_J_;
  Eigen::Matrix<double, 3, Eigen::Dynamic> J_linear_;
  Eigen::Vector3d v_des_;
};
template <int N_VAR> class AngularVelocityTask : public Core<N_VAR>::Task {
public:
  bool is_active() const override { return active_; };
  void set_active(bool active) override { active_ = active; };
  void set_dt(double dt) override {}
  void set_weight(const double *weights, uint32_t nb_w) override {
    weight_ = weights[0];
  }
  // start_idx: 该任务涉及的机构在全局向量中的起始位置
  // num_dof:   该任务涉及的机构的自由度数
  AngularVelocityTask(int start_idx, int num_dof, double weight)
      : start_idx_(start_idx), num_dof_(num_dof), weight_(weight) {
    set_active(true);
  }

  // 用户在循环中调用此函数更新数据 (传入原始指针)
  // jacobian_ptr: 必须指向 6 x num_dof 的数组 (列优先或行优先需一致)
  // target_ptr:   必须指向 3个double (vx, vy, vz)
  void update(const double *jacobian_ptr, const double *target_ptr) {
    // Map 原始数据，零拷贝
    // 假设 jacobian_ptr 是按列存储的 6xN 矩阵
    // 我们只取前3行 (线性部分)
    // Eigen::Map 默认是列优先 (Column Major)
    raw_J_ = Eigen::Map<const Eigen::Matrix<double, 6, Eigen::Dynamic>>(
        jacobian_ptr, 6, num_dof_);
    //

    J_angular_ = raw_J_.bottomRows(3);

    // Map 目标速度
    w_des_ = Eigen::Map<const Eigen::Vector3d>(target_ptr);
    // std::cout << raw_J_ << std::endl;
    // std::cout << J_linear_ << std::endl;
  }

  void compute_cost(Eigen::Ref<typename Core<N_VAR>::Matrix> H,
                    Eigen::Ref<typename Core<N_VAR>::Vector> g) override {
    // 局部 Cost: H_local = w * J^T * J
    // 我们需要把局部 H 放到全局 H 的正确位置 (start_idx_)

    // Block 操作：H.block(row, col, rows, cols)
    // 这是一个引用操作，直接修改全局矩阵内存

    // 1. Hessian 贡献
    H.block(start_idx_, start_idx_, num_dof_, num_dof_) +=
        weight_ * (J_angular_.transpose() * J_angular_);

    // 2. Gradient 贡献: g = -w * J^T * v_des
    g.segment(start_idx_, num_dof_) +=
        -weight_ * (J_angular_.transpose() * w_des_);

    // std::cout << H << std::endl;
  }

private:
  int start_idx_;
  int num_dof_;
  double weight_;

  // 内部缓存，避免重复分配
  // 注意：如果是 realtime，最好预分配最大尺寸或使用 Dynamic
  Eigen::Matrix<double, 6, Eigen::Dynamic> raw_J_;
  Eigen::Matrix<double, 3, Eigen::Dynamic> J_angular_;
  Eigen::Vector3d w_des_;
  bool active_;
};

} // namespace WBC