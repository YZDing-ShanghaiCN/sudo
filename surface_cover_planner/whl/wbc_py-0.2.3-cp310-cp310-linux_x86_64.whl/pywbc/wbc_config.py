from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any
import yaml
import numpy as np


@dataclass
class TaskConfig:
    type: str
    name: str
    weight: float = 1.0
    # 针对不同任务的可选参数
    dim: int = 9
    weights_vec: Optional[List[float]] = None
    link_id: int = -1
    dt: float = 0.001
    # 运行时不需要保存到 yaml 的状态 (exclude from serialization if needed)
    # 这里我们只存配置参数


@dataclass
class ControllerConfig:
    solver_type: str
    name: str
    # 针对不同任务的可选参数
    dim: int = 9


@dataclass
class ConstraintConfig:
    type: str
    name: str
    # 关节限制参数
    q_min: Optional[List[float]] = None
    q_max: Optional[List[float]] = None
    v_limit: Optional[List[float]] = None
    dt: float = 0.001
    # 笛卡尔限制参数
    dim: int = 3
    weight: float = 1.0


@dataclass
class WBCConfig:
    tasks: List[TaskConfig] = field(default_factory=list)
    constraints: List[ConstraintConfig] = field(default_factory=list)
    controller: ControllerConfig = field(default_factory=list)

    @classmethod
    def load(cls, path: str):
        with open(path, "r") as f:
            data = yaml.safe_load(f)

        # 解析 Tasks
        tasks = [TaskConfig(**t) for t in data.get("tasks", [])]

        # 解析 Constraints
        constraints = [ConstraintConfig(**c) for c in data.get("constraints", [])]

        return cls(tasks=tasks, constraints=constraints)

    def save(self, path: str):
        # 转换为字典并保存
        data = asdict(self)
        # 过滤掉 None 值以保持 yaml 清爽 (可选)
        clean_data = {
            "tasks": [
                {k: v for k, v in asdict(t).items() if v is not None}
                for t in self.tasks
            ],
            "constraints": [
                {k: v for k, v in asdict(c).items() if v is not None}
                for c in self.constraints
            ],
        }
        with open(path, "w") as f:
            yaml.dump(clean_data, f, sort_keys=False)
