"""High-performance whole body controller"""

from collections.abc import Sequence
from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


def dquery_line3_line3(p1: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], p2: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], q1: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], q2: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]) -> tuple[Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]]:
    """
    Computes the closest points between two infinite 3D lines defined by point pairs.
    """

def top_k(d: Annotated[NDArray[numpy.float32], dict(order='C', device='cpu', writable=False)], labels: Annotated[NDArray[numpy.uint32], dict(order='C', device='cpu', writable=False)], mask: Sequence[int], k: int) -> dict[int, list[int]]:
    """
    Finds the original array positions of the top k values in 'd' for each label in 'mask'.
    """

def spatial_to_mixed_linear(J_spatial: Annotated[NDArray[numpy.float64], dict(shape=(6, None), order='F', device='cpu')], p_world: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), order='C', device='cpu')], g_world: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), order='C', device='cpu')], link_indices: Annotated[NDArray[numpy.int32], dict(shape=(None,), order='C', device='cpu')], out: Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='F', device='cpu')]) -> None:
    """Projects spatial Jacobians using F-contiguous NumPy arrays."""

class Tf:
    @overload
    def __init__(self) -> None: ...

    @overload
    def __init__(self, matrix: Annotated[NDArray[numpy.float64], dict(shape=(4, 4), order='F')]) -> None: ...

    @overload
    def __init__(self, args: tuple[Annotated[NDArray[numpy.float64], dict(shape=(4), order='C')], Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]]) -> None: ...

    @overload
    def __init__(self, array: Annotated[NDArray, dict(shape=(None,))]) -> None: ...

    @overload
    def __init__(self, rpy: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], xyz: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]) -> None: ...

    def __mul__(self, arg: Tf, /) -> Tf: ...

    @overload
    def __matmul__(self, arg: Tf, /) -> Tf: ...

    @overload
    def __matmul__(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='C')], /) -> NDArray[numpy.float64]: ...

    def __rmatmul__(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='C')], /) -> NDArray[numpy.float64]: ...

    def inv(self) -> Tf: ...

    def log_so3(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]:
        """Computes the SO(3) logarithmic map (3D rotation vector)."""

    def slerp(self, t: float, other: Tf) -> Tf:
        """
        Interpolate between this pose and another pose (LERP for translation, SLERP for rotation).
        """

    @property
    def position(self) -> Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')]: ...

    @position.setter
    def position(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(3), order='C')], /) -> None: ...

    @property
    def wxyz(self) -> Annotated[NDArray[numpy.float64], dict(shape=(4), order='C')]: ...

    @wxyz.setter
    def wxyz(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(4), order='C')], /) -> None: ...

    def as_array(self) -> Annotated[NDArray[numpy.float64], dict(shape=(7))]: ...

    @property
    def matrix(self) -> Annotated[NDArray[numpy.float64], dict(shape=(4, 4), order='F')]: ...

    @matrix.setter
    def matrix(self, arg: Annotated[NDArray[numpy.float64], dict(shape=(4, 4), order='F')], /) -> None: ...

    def __repr__(self) -> str: ...

class QPSolver9:
    def init(self, max_constraints: int = 100) -> None:
        """Initialize the solver memory."""

class DAQPSolver9(QPSolver9):
    def __init__(self) -> None:
        """Create a DAQP solver instance."""

class Task9:
    pass

class Constraint9:
    pass

class WBCController9:
    def __init__(self, solver: QPSolver9) -> None:
        """Initialize controller with a specific QP solver."""

    def add_task(self, task: Task9) -> None:
        """Add a task to the controller."""

    def add_constraint(self, constraint: Constraint9) -> None:
        """Add a constraint to the controller."""

    def solve(self) -> Annotated[NDArray[numpy.float64], dict(shape=(9), order='C')]:
        """Solve the QP and return the optimal q_dot (9,)"""

    def solver_status(self) -> int:
        """Solver exit flag after calling solve"""

class DampingTask9(Task9):
    def __init__(self, weights: Sequence[float]) -> None:
        """Create a damping task with diagonal weights."""

    def set_dt(self, dt: float) -> None:
        """Update dt if used for this task"""

    @overload
    def set_weight(self, weights: NDArray[numpy.float64]) -> None: ...

    @overload
    def set_weight(self, weights: float) -> None: ...

class SmoothnessTask(Task9):
    def __init__(self, weight: float = 0.1) -> None: ...

    def set_dt(self, dt: float) -> None:
        """Update dt if used for this task"""

    def update(self, q_dot_prev: NDArray[numpy.float64]) -> None: ...

    @overload
    def set_weight(self, weights: NDArray[numpy.float64]) -> None: ...

    @overload
    def set_weight(self, weights: float) -> None: ...

class JerkTask(Task9):
    def __init__(self, weight: float, dt: float = 0.001) -> None: ...

    def set_dt(self, dt: float) -> None:
        """Update dt if used for this task"""

    def set_weight(self, weights: float) -> None: ...

    def update(self, arg: NDArray[numpy.float64], /) -> None:
        """Update with the velocity from the previous step"""

    def reset(self, arg: NDArray[numpy.float64], /) -> None: ...

class LinearVelTask9(Task9):
    def __init__(self, start_idx: int, num_dof: int, weight: float) -> None:
        """Create a task to track linear velocity of a specific link."""

    def set_dt(self, dt: float) -> None:
        """Update dt if used for this task"""

    def set_weight(self, weights: float) -> None: ...

    def update(self, jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')]) -> None:
        """Update task with new Jacobian (6xN) and target velocity (3,)"""

class AngularVelTask9(Task9):
    def __init__(self, start_idx: int, num_dof: int, weight: float) -> None:
        """Create a task to track linear velocity of a specific link."""

    def set_dt(self, dt: float) -> None:
        """Update dt if used for this task"""

    def set_weight(self, weights: float) -> None: ...

    def update(self, jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], target: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')]) -> None:
        """Update task with new Jacobian (6xN) and target velocity (3,)"""

class GravityTask(Task9):
    def __init__(self, weight: float = 1.0) -> None: ...

    def set_dt(self, dt: float) -> None:
        """Update dt if used for this task"""

    def set_weight(self, weights: float) -> None: ...

    def update(self, jacobian: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], direction: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')]) -> None:
        """Update task with new Jacobian (3xN) and direction (3,)"""

class CartesianVelocityConstraint(Constraint9):
    def __init__(self, rows: int) -> None: ...

    def is_active(self) -> bool: ...

    def set_active(self, arg: bool, /) -> None: ...

    def update(self, J: Annotated[NDArray[numpy.float64], dict(shape=(None, None), writable=False)], v_min: Annotated[NDArray[numpy.float64], dict(shape=(None,), writable=False)], v_max: Annotated[NDArray[numpy.float64], dict(shape=(None,), writable=False)]) -> None:
        """Update the constraint parameters"""

class CollisionBarrierConstraint9(Constraint9):
    def __init__(self, num_max_constraints: int, weight: float) -> None: ...

    def update(self, jacobian_point: Annotated[NDArray[numpy.float64], dict(order='F', device='cpu')], distance_point: NDArray[numpy.float64]) -> None:
        """Update constraint with distance vectors."""

    def set_weight(self, arg: float, /) -> None: ...

    def is_active(self) -> bool: ...

    def set_active(self, arg: bool, /) -> None: ...

    def clear(self) -> None: ...

class JointLimitConstraint9(Constraint9):
    def __init__(self, start_idx: int, num_dof: int, q_min: NDArray[numpy.float64], q_max: NDArray[numpy.float64], dt: float = 0.001) -> None: ...

    def is_active(self) -> bool: ...

    def set_active(self, arg: bool, /) -> None: ...

    def update(self, q_curr: NDArray[numpy.float64]) -> None:
        """Update constraint with current joint positions."""

class JointVeclocityLimitConstraint9(Constraint9):
    def __init__(self, start_idx: int, num_dof: int, q_min: NDArray[numpy.float64], q_max: NDArray[numpy.float64], v_limit: NDArray[numpy.float64], dt: float = 0.001) -> None: ...

    def update(self, q_curr: NDArray[numpy.float64]) -> None:
        """Update constraint with current joint positions."""

    def update_joint_limits(self, q_min: NDArray[numpy.float64], q_max: NDArray[numpy.float64]) -> None:
        """Update constraint with current joint positions."""

    def update_velocity_limits(self, v_limits: NDArray[numpy.float64]) -> None:
        """Dynamically update the max velocity limits."""

    def is_active(self) -> bool: ...

    def set_active(self, arg: bool, /) -> None: ...
