"""
Python Whole Body Controller
"""

__all__ = [
    "TaskConfig",
]

from wbc_py import *

# from .wbc_config import TaskConfig as TaskConfig
