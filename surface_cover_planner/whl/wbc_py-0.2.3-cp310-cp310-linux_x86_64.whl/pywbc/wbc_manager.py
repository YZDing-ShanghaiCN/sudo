import numpy as np
import wbc_py  # 您的编译库
from .wbc_config import WBCConfig, TaskConfig, ConstraintConfig


class WBCManager:
    def __init__(self, config_path: str = None):

        self.controller: wbc_py.WBCController9 = None
        self.solver: wbc_py.QPSolver9 = None

        # 运行时对象注册表 (name -> C++ Object)
        self.task_objects: dict[str, wbc_py.Task9] = {}
        self.constraint_objects: dict[str, wbc_py.Constraint9] = {}

        # 配置对象 (DataClass)
        if config_path:
            self.config = WBCConfig.load(config_path)
            self._build_system()
        else:
            self.config = WBCConfig()

    def _build_system(self):
        """根据当前的 self.config 构建 C++ 控制器"""
        print("[WBCManager] Building system from config...")

        self.solver = wbc_py.DAQPSolver9()
        self.controller = wbc_py.WBCController9(self.solver)

        # 1. 构建任务
        for task_cfg in self.config.tasks:
            self._add_task_from_config(task_cfg)

        # 2. 构建约束
        for constr_cfg in self.config.constraints:
            self._add_constraint_from_config(constr_cfg)

    def _add_task_from_config(self, cfg: TaskConfig):
        print(f"  - Adding Task: {cfg.name} ({cfg.type})")
        # print(cfg.weight)
        if cfg.type == "damping":
            if cfg.weights_vec:
                w_vec = np.array(cfg.weights_vec)
            else:
                w_vec = np.full(cfg.dim, cfg.weight)
            obj = wbc_py.DampingTask9(w_vec)
        elif cfg.type == "gravity":
            obj = wbc_py.GravityTask(cfg.weight)
        elif cfg.type == "linear_velocity":
            obj = wbc_py.LinearVelTask9(0, cfg.dim, cfg.weight)
        elif cfg.type == "angular_velocity":
            obj = wbc_py.AngularVelTask9(0, cfg.dim, cfg.weight)
        elif cfg.type == "smoothness":
            obj = wbc_py.SmoothnessTask(cfg.weight)
        elif cfg.type == "jerk":
            # obj = wbc_py.SmoothnessTask(cfg.weight)
            obj = wbc_py.JerkTask(weight=cfg.weight, dt=1.0 / cfg.dt)
        else:
            print(f"    [Warn] Unknown task type: {cfg.type}")
            return

        self.controller.add_task(obj)
        self.task_objects[cfg.name] = obj

    def _add_constraint_from_config(self, cfg: ConstraintConfig):
        print(f"  - Adding Constraint: {cfg.name} ({cfg.type})")
        if cfg.type == "joint_position_limits":
            if not (cfg.q_min and cfg.q_max):
                raise ValueError(f"Constraint {cfg.name} missing limits!")

            q_min = np.array(cfg.q_min)
            q_max = np.array(cfg.q_max)
            obj = wbc_py.JointLimitConstraint9(
                0, len(q_min), q_min, q_max, v_lim, cfg.dt
            )
        elif cfg.type == "joint_position_speed_limits":
            if not (cfg.q_min and cfg.q_max and cfg.v_limit):
                raise ValueError(f"Constraint {cfg.name} missing limits!")

            q_min = np.array(cfg.q_min)
            q_max = np.array(cfg.q_max)
            v_lim = np.array(cfg.v_limit)

            # print(q_max)
            # print(q_min)
            # print(v_lim)

            obj = wbc_py.JointVeclocityLimitConstraint9(
                0, cfg.dim, q_min, q_max, v_lim, cfg.dt
            )
        elif cfg.type == "linear_velocity_exact":
            obj = wbc_py.CartesianVelocityConstraint(cfg.dim)
        elif cfg.type == "collision_barrier":
            # print(cfg.dim, cfg.weight)
            obj = wbc_py.CollisionBarrierConstraint9(cfg.dim, cfg.weight)

        else:
            print(f"    [Warn] Unknown constraint type: {cfg.type}")
            return

        self.controller.add_constraint(obj)
        self.constraint_objects[cfg.name] = obj

    # ============================================================
    # 运行时接口
    # ============================================================

    # def update_task_weight(self, task_name: str, new_weight: float):
    #     """在线调参：修改权重并同步回 Config 对象"""
    #     # 1. 更新 Config (为了保存)
    #     for t in self.config.tasks:
    #         if t.name == task_name:
    #             t.weight = new_weight
    #             # 如果是 DampingTask 这种存向量的，可能需要重新生成 weights_vec
    #             if t.type == "damping":
    #                 t.weights_vec = [new_weight] * t.dim
    #             break

    #     # 2. 更新 C++ 对象 (如果有 set_weight 接口)
    #     # 注意：如果 C++ 没暴露 set_weight，可能需要重新 add_task 或暴露接口
    #     # 这里假设您在 python_bindings.cpp 里暴露了 set_weight
    #     # obj = self.task_objects.get(task_name)
    #     # if obj: obj.set_weight(new_weight)
    #     print(f"[Tuning] Updated {task_name} weight to {new_weight}")

    # def solve(self, state_dict: Dict[str, Any]):
    #     """统一求解接口"""

    #     # 1. 自动根据名字分发数据
    #     for name, obj in self.task_objects.items():
    #         data = state_dict.get(name)
    #         if data is None:
    #             continue  # 某些任务（如 Damping）可能不需要每帧数据

    #         # 根据类型分发 update
    #         # 这里可以用 isinstance 判断，或者 duck typing
    #         if hasattr(obj, "update"):
    #             # 如果 data 是字典，解包参数 (J=..., dir=...)
    #             if isinstance(data, dict):
    #                 obj.update(**data)
    #             # 如果是元组/列表，解包位置参数
    #             elif isinstance(data, (list, tuple)):
    #                 obj.update(*data)
    #             # 否则直接传
    #             else:
    #                 obj.update(data)

    #     # 2. 约束更新
    #     for name, obj in self.constraint_objects.items():
    #         data = state_dict.get(name)
    #         if data is not None:
    #             if isinstance(data, dict):
    #                 obj.update(**data)
    #             else:
    #                 obj.update(data)
    #         elif name == "joint_limits":
    #             # 特殊处理：关节限制通常只需要当前关节状态
    #             q = state_dict.get("q_curr")
    #             if q is not None:
    #                 obj.update(q)

    #     return self.controller.solve()

    def save_config(self, filepath: str):
        self.config.save(filepath)
