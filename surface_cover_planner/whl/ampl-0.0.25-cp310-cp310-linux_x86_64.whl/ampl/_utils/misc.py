import numpy as np


def rpy_to_tf33(rpy_radian: np.ndarray, dtype=np.float64) -> np.ndarray:
    roll, pitch, yaw = rpy_radian.tolist()
    Rx = np.array(
        [[1, 0, 0], [0, np.cos(roll), -np.sin(roll)], [0, np.sin(roll), np.cos(roll)]],
        dtype=dtype,
    )
    Ry = np.array(
        [
            [np.cos(pitch), 0, np.sin(pitch)],
            [0, 1, 0],
            [-np.sin(pitch), 0, np.cos(pitch)],
        ],
        dtype=dtype,
    )
    Rz = np.array(
        [[np.cos(yaw), -np.sin(yaw), 0], [np.sin(yaw), np.cos(yaw), 0], [0, 0, 1]],
        dtype=dtype,
    )
    R = Rz @ Ry @ Rx
    return R


def quatmul(q1: np.ndarray, q2: np.ndarray) -> np.ndarray:
    x1, y1, z1, w1 = q1
    x2, y2, z2, w2 = q2
    w = w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2
    x = w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2
    y = w1 * y2 - x1 * z2 + y1 * w2 + z1 * x1
    z = w1 * z2 + x1 * y2 - y1 * x1 + z1 * w2
    return np.array([x, y, z, w], dtype=q1.dtype)


def xyzrpy_to_tf44(xyz: np.ndarray, rpy: np.ndarray, dtype=np.float64) -> np.ndarray:
    T = np.eye(4, dtype=dtype)
    T[:3, :3] = rpy_to_tf33(rpy, dtype)
    T[:3, 3:] = np.array(xyz).reshape(3, 1)
    return T


def trimesh_grid2mesh(vertices: np.ndarray, rows: int, cols: int):
    """
    Converts a structured 2D grid of points into a triangle mesh.

    Args:
        vertices (np.ndarray): A 3D numpy array of shape (rows, cols, 3)
                               representing the grid points.
        rows (int): The number of rows in the grid.
        cols (int): The number of columns in the grid.

    Returns:
        tuple: A tuple containing:
            - flat_vertices (np.ndarray): A 1D array of vertex coordinates.
            - triangle_indices (np.ndarray): A 1D array of triangle indices.
    """
    # 1. Flatten the vertex list
    # The vertices are already in a flat C-contiguous array if created with np.zeros,
    # but we ensure it here. The index of vertex (i, j) is i * cols + j.
    flat_vertices = vertices.reshape(-1, 3)

    # 2. Generate triangle indices
    triangle_indices = []
    # We iterate through each quad, defined by its top-left corner (i, j)
    for i in range(rows - 1):
        for j in range(cols - 1):
            # Calculate the indices for the four corners of the current quad
            idx_A = i * cols + j
            idx_B = i * cols + (j + 1)
            idx_C = (i + 1) * cols + (j + 1)
            idx_D = (i + 1) * cols + j

            # Create two triangles for the quad (Method 1: A-B-C diagonal)
            # Triangle 1: A, B, C
            triangle_indices.append([idx_C, idx_B, idx_A])
            # Triangle 2: A, C, D
            triangle_indices.append([idx_D, idx_C, idx_A])

    return flat_vertices, np.array(triangle_indices, dtype=np.int32)


# def make_uv_mesh(grid_rows, grid_cols, range_x, range_y):
#     x = np.linspace(range_x[0], range_x[1], grid_cols)
#     y = np.linspace(range_y[0], range_y[1], grid_rows)
#     X, Y = np.meshgrid(x, y)
#     vertices = np.zeros((grid_rows, grid_cols, 3), dtype=np.float32)
#     vertices[:, :, 0] = X
#     vertices[:, :, 1] = Y
#     vertices[:, :, 2] *= 0.0
#     vertices[:, :, 2] = 1.4
#     V, F = trimesh_grid2mesh(vertices, grid_rows, grid_cols)
#     return V, F


def match_obb3(obbA: tuple, obbB: tuple):
    R_180 = [
        np.array([[1, 0, 0], [0, -1, 0], [0, 0, -1]])
        # 180-degree rotation around Y-axis
        ,
        np.array([[-1, 0, 0], [0, 1, 0], [0, 0, -1]]),
        # 180-degree rotation around Z-axis
        np.array([[-1, 0, 0], [0, -1, 0], [0, 0, 1]]),
    ]
    c_A, extents_A, R_A = obbA
    c_B, extents_B, R_B = obbB
    axes_A = [R_A[:, 0], R_A[:, 1], R_A[:, 2]]
    axes_B = [R_B[:, 0], R_B[:, 1], R_B[:, 2]]

    sort_idx_A = np.argsort(extents_A)
    sort_idx_B = np.argsort(extents_B)

    U_A_prime = np.column_stack(
        (axes_A[sort_idx_A[0]], axes_A[sort_idx_A[1]], axes_A[sort_idx_A[2]])
    )

    U_B_prime = np.column_stack(
        (axes_B[sort_idx_B[0]], axes_B[sort_idx_B[1]], axes_B[sort_idx_B[2]])
    )

    R = U_B_prime @ U_A_prime.T

    if np.linalg.det(R) < 0:

        U_B_prime[:, 2] = -U_B_prime[:, 2]

        R = U_B_prime @ U_A_prime.T

    t = c_B - R @ c_A
    tf = np.eye(4)
    tf[:3, :3] = R
    tf[:3, 3] = t.flatten()

    return tf
